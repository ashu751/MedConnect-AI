import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useEffect } from 'react';
import { Pill, Plus, Trash2, Bell, BellOff, Clock, AlertTriangle, CheckCircle } from 'lucide-react';

const STORAGE_KEY = 'mc_medicine_reminders';
const INTERACTIONS = {
  'Warfarin': ['Aspirin','Ibuprofen','Naproxen'],
  'Aspirin': ['Warfarin','Ibuprofen','Clopidogrel'],
  'Ibuprofen': ['Warfarin','Aspirin','Lithium','Methotrexate'],
  'Metformin': ['Alcohol'],
  'Simvastatin': ['Clarithromycin','Erythromycin','Amiodarone'],
  'Lisinopril': ['Potassium','Spironolactone'],
  'Clopidogrel': ['Aspirin','Omeprazole'],
};

function checkInteractions(meds) {
  const names = meds.map(m => m.name);
  const warnings = [];
  names.forEach(n => {
    const known = INTERACTIONS[n] || [];
    known.forEach(conflict => {
      if (names.includes(conflict) && !warnings.find(w => w.includes(n) && w.includes(conflict))) {
        warnings.push(`${n} + ${conflict} may interact — consult your doctor.`);
      }
    });
  });
  return warnings;
}

const FREQ = ['Once daily','Twice daily','Three times daily','Every 8 hours','As needed','Every night','Every morning'];

export default function MedicineReminder() {
  const { lang } = useTheme();
  const [meds, setMeds] = useState(() => JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'));
  const [form, setForm] = useState({ name: '', dose: '', freq: 'Once daily', time: '08:00', notes: '', startDate: new Date().toISOString().split('T')[0], days: 7 });
  const [adding, setAdding] = useState(false);
  const [taken, setTaken] = useState({});

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(meds)); }, [meds]);

  const today = new Date().toDateString();
  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('mc_taken_' + today) || '{}');
    setTaken(stored);
  }, []);

  const markTaken = (id) => {
    const updated = { ...taken, [id]: true };
    setTaken(updated);
    localStorage.setItem('mc_taken_' + today, JSON.stringify(updated));
  };

  const save = () => {
    if (!form.name.trim() || !form.dose.trim()) return;
    setMeds(prev => [{ ...form, id: Date.now(), name: form.name.trim(), dose: form.dose.trim() }, ...prev]);
    setForm({ name: '', dose: '', freq: 'Once daily', time: '08:00', notes: '', startDate: new Date().toISOString().split('T')[0], days: 7 });
    setAdding(false);
  };

  const remove = (id) => setMeds(prev => prev.filter(m => m.id !== id));
  const interactions = checkInteractions(meds);
  const activeMeds = meds.filter(m => { const end = new Date(m.startDate); end.setDate(end.getDate() + Number(m.days)); return end >= new Date(); });

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Daily Care</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('medicineReminderTitle',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('medicineReminderDesc',lang)}</p>
      </div>

      {interactions.length > 0 && (
        <div style={{ padding: '14px 18px', background: 'rgba(240,98,138,0.08)', border: '1px solid rgba(240,98,138,0.25)', borderRadius: 14, marginBottom: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <AlertTriangle size={16} color="var(--accent3)" />
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--accent3)', fontSize: '0.9rem' }}>Interaction Warning</span>
          </div>
          {interactions.map((w, i) => <p key={i} style={{ fontSize: '0.85rem', color: 'var(--text2)', marginBottom: 4 }}>⚠️ {w}</p>)}
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div style={{ fontSize: '0.9rem', color: 'var(--text3)' }}>{activeMeds.length} active medication{activeMeds.length !== 1 ? 's' : ''}</div>
        <button onClick={() => setAdding(!adding)} className="btn btn-primary" style={{ padding: '10px 18px' }}>
          <Plus size={16} /> Add Medicine
        </button>
      </div>

      {adding && (
        <div className="card" style={{ marginBottom: 24, borderColor: 'rgba(124,106,247,0.2)' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 18 }}>New Medication</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
            <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Medicine Name *</label><input value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} placeholder="e.g. Amoxicillin" /></div>
            <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Dosage *</label><input value={form.dose} onChange={e => setForm(f => ({...f, dose: e.target.value}))} placeholder="e.g. 500mg" /></div>
            <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Frequency</label>
              <select value={form.freq} onChange={e => setForm(f => ({...f, freq: e.target.value}))}>
                {FREQ.map(f => <option key={f}>{f}</option>)}
              </select>
            </div>
            <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Reminder Time</label><input type="time" value={form.time} onChange={e => setForm(f => ({...f, time: e.target.value}))} /></div>
            <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Start Date</label><input type="date" value={form.startDate} onChange={e => setForm(f => ({...f, startDate: e.target.value}))} /></div>
            <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Duration (days)</label><input type="number" value={form.days} min={1} max={365} onChange={e => setForm(f => ({...f, days: e.target.value}))} /></div>
          </div>
          <div style={{ marginBottom: 16 }}><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Notes</label><input value={form.notes} onChange={e => setForm(f => ({...f, notes: e.target.value}))} placeholder="e.g. Take with food" /></div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={save} disabled={!form.name.trim() || !form.dose.trim()} className="btn btn-primary">Save Medicine</button>
            <button onClick={() => setAdding(false)} className="btn btn-ghost">Cancel</button>
          </div>
        </div>
      )}

      {meds.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 48 }}>
          <Pill size={36} color="var(--text3)" style={{ margin: '0 auto 12px' }} />
          <p style={{ color: 'var(--text3)' }}>No medicines added yet. Add your first medication above.</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px,1fr))', gap: 16 }}>
          {meds.map(m => {
            const end = new Date(m.startDate); end.setDate(end.getDate() + Number(m.days));
            const active = end >= new Date();
            const isTaken = taken[m.id];
            return (
              <div key={m.id} className="card" style={{ borderColor: active ? 'rgba(91,211,199,0.2)' : 'var(--border)', opacity: active ? 1 : 0.6 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 38, height: 38, borderRadius: 10, background: active ? 'rgba(91,211,199,0.15)' : 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Pill size={18} color={active ? '#5bd3c7' : 'var(--text3)'} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '0.95rem' }}>{m.name}</div>
                      <div style={{ fontSize: '0.78rem', color: 'var(--text3)' }}>{m.dose}</div>
                    </div>
                  </div>
                  <button onClick={() => remove(m.id)} style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', padding: 4 }}><Trash2 size={14} /></button>
                </div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
                  <span className="tag" style={{ background: 'rgba(124,106,247,0.12)', color: 'var(--accent)', fontSize: '0.72rem' }}>{m.freq}</span>
                  <span className="tag" style={{ background: 'var(--surface2)', color: 'var(--text3)', fontSize: '0.72rem' }}><Clock size={10} style={{ marginRight: 3 }} />{m.time}</span>
                  {!active && <span className="tag" style={{ background: 'rgba(240,98,138,0.12)', color: 'var(--accent3)', fontSize: '0.72rem' }}>Completed</span>}
                </div>
                {m.notes && <p style={{ fontSize: '0.8rem', color: 'var(--text3)', marginBottom: 10 }}>{m.notes}</p>}
                {active && (
                  <button onClick={() => isTaken ? null : markTaken(m.id)} className={isTaken ? 'btn' : 'btn btn-secondary'} style={{ width: '100%', justifyContent: 'center', fontSize: '0.85rem', padding: '8px', background: isTaken ? 'rgba(91,211,199,0.12)' : '', color: isTaken ? '#5bd3c7' : '', border: isTaken ? '1px solid rgba(91,211,199,0.2)' : '' }}>
                    {isTaken ? <><CheckCircle size={14} /> Taken today</> : <><Bell size={14} /> Mark as taken</>}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
