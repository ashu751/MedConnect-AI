import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, Brain, MapPin, BarChart3, ArrowRight, Shield, Zap, Clock, Stethoscope } from 'lucide-react';

export default function LandingPage() {
  const [typed, setTyped] = useState('');
  const phrases = ['AI-Powered Diagnosis', 'Mental Wellness Tools', 'Find Hospitals Near You', 'Track Your Health'];
  const phraseIdx = useRef(0);
  const charIdx = useRef(0);
  const deleting = useRef(false);

  useEffect(() => {
    const tick = () => {
      const current = phrases[phraseIdx.current];
      if (!deleting.current) {
        setTyped(current.slice(0, charIdx.current + 1));
        charIdx.current++;
        if (charIdx.current === current.length) {
          deleting.current = true;
          setTimeout(tick, 1800);
          return;
        }
      } else {
        setTyped(current.slice(0, charIdx.current - 1));
        charIdx.current--;
        if (charIdx.current === 0) {
          deleting.current = false;
          phraseIdx.current = (phraseIdx.current + 1) % phrases.length;
        }
      }
      setTimeout(tick, deleting.current ? 45 : 80);
    };
    const t = setTimeout(tick, 600);
    return () => clearTimeout(t);
  }, []);

  const features = [
    { icon: Stethoscope, title: 'AI Medical Assistant', desc: 'Describe your symptoms and get intelligent, evidence-based health insights powered by Gemini AI.', color: '#5bd3c7', tag: 'Gemini AI' },
    { icon: Brain, title: 'Mental Health Companion', desc: 'Daily mood tracking, guided breathing, and AI-powered emotional support whenever you need it.', color: '#f0628a', tag: 'Wellness' },
    { icon: MapPin, title: 'Hospital Finder', desc: 'Locate verified hospitals, clinics, and specialists near you with real-time Google Maps integration.', color: '#f5a623', tag: 'Maps' },
    { icon: BarChart3, title: 'Health Analytics', desc: 'Visual insights into your health trends, symptom patterns, and wellness journey over time.', color: '#7c6af7', tag: 'Insights' },
  ];

  const pillars = [
    { icon: Shield, text: 'Privacy-first by design' },
    { icon: Zap, text: 'Real-time AI responses' },
    { icon: Clock, text: 'Available 24/7' },
  ];

  return (
    <div style={{ background: 'var(--bg)', minHeight: '100vh', position: 'relative', overflow: 'hidden' }}>
      {/* Orbs */}
      <div className="gradient-orb" style={{ width: 600, height: 600, background: 'radial-gradient(circle, rgba(124,106,247,0.12) 0%, transparent 70%)', top: -200, right: -200 }} />
      <div className="gradient-orb" style={{ width: 400, height: 400, background: 'radial-gradient(circle, rgba(91,211,199,0.08) 0%, transparent 70%)', bottom: 200, left: -100 }} />

      {/* Header */}
      <header style={{ padding: '24px 40px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative', zIndex: 1, borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 16px rgba(124,106,247,0.4)' }}>
            <Activity size={17} color="white" />
          </div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.1rem' }}>MedConnect</span>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <Link to="/login" className="btn btn-ghost">Sign in</Link>
          <Link to="/login?tab=signup" className="btn btn-primary">Get started <ArrowRight size={16} /></Link>
        </div>
      </header>

      {/* Hero */}
      <section style={{ padding: '100px 40px 80px', maxWidth: 900, margin: '0 auto', textAlign: 'center', position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', borderRadius: 100, background: 'rgba(124,106,247,0.1)', border: '1px solid rgba(124,106,247,0.2)', marginBottom: 32 }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }} className="pulse" />
          <span style={{ fontSize: '0.8rem', color: 'var(--accent)', fontFamily: 'var(--font-mono)', fontWeight: 500 }}>Powered by Google Gemini AI</span>
        </div>
        <h1 style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'clamp(2.8rem, 7vw, 5rem)',
          fontWeight: 800,
          lineHeight: 1.08,
          letterSpacing: '-0.03em',
          marginBottom: 24,
          color: 'var(--text)'
        }}>
          Your intelligent<br />
          <span style={{ color: 'var(--accent)' }}>health companion</span>
        </h1>
        <div style={{ fontSize: 'clamp(1.1rem, 3vw, 1.5rem)', color: 'var(--text2)', marginBottom: 16, minHeight: '2em', fontWeight: 300 }}>
          <span className="typing">{typed}</span>
        </div>
        <p style={{ fontSize: '1.05rem', color: 'var(--text3)', maxWidth: 500, margin: '0 auto 48px', lineHeight: 1.7 }}>
          Combine AI diagnostics, mental wellness tracking, and real hospital discovery in one seamless platform.
        </p>
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
          <Link to="/login?tab=signup" className="btn btn-primary" style={{ padding: '16px 32px', fontSize: '1rem' }}>
            Start for free <ArrowRight size={18} />
          </Link>
          <Link to="/login" className="btn btn-secondary" style={{ padding: '16px 32px', fontSize: '1rem' }}>
            Sign in
          </Link>
        </div>

        {/* Pillars */}
        <div style={{ display: 'flex', gap: 24, justifyContent: 'center', flexWrap: 'wrap', marginTop: 60 }}>
          {pillars.map((p, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text3)', fontSize: '0.85rem' }}>
              <p.icon size={15} color="var(--accent)" />
              {p.text}
            </div>
          ))}
        </div>
      </section>

      {/* Feature cards */}
      <section style={{ padding: '80px 40px', maxWidth: 1100, margin: '0 auto', position: 'relative', zIndex: 1 }}>
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <p className="prose-label" style={{ marginBottom: 12 }}>Everything you need</p>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.8rem, 4vw, 2.8rem)', fontWeight: 700, letterSpacing: '-0.02em' }}>
            Healthcare reimagined
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 20 }}>
          {features.map((f, i) => (
            <div key={i} className="card" style={{
              borderColor: `${f.color}20`,
              transition: 'transform 0.2s, box-shadow 0.2s, border-color 0.2s',
              cursor: 'default'
            }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = `0 16px 48px ${f.color}20`; e.currentTarget.style.borderColor = `${f.color}40`; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; e.currentTarget.style.borderColor = `${f.color}20`; }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
                <div style={{ width: 48, height: 48, borderRadius: 12, background: `${f.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <f.icon size={22} color={f.color} />
                </div>
                <span className="tag" style={{ background: `${f.color}15`, color: f.color, border: `1px solid ${f.color}30`, fontSize: '0.7rem', padding: '3px 8px' }}>{f.tag}</span>
              </div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.15rem', marginBottom: 10 }}>{f.title}</h3>
              <p style={{ color: 'var(--text3)', fontSize: '0.9rem', lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '80px 40px', position: 'relative', zIndex: 1 }}>
        <div style={{ maxWidth: 600, margin: '0 auto', textAlign: 'center', padding: '60px 40px', background: 'var(--surface)', border: '1px solid var(--border2)', borderRadius: 24, position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 0%, rgba(124,106,247,0.08) 0%, transparent 60%)', pointerEvents: 'none' }} />
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, marginBottom: 16, letterSpacing: '-0.02em' }}>Ready to take control?</h2>
          <p style={{ color: 'var(--text3)', marginBottom: 32, lineHeight: 1.7 }}>Join thousands using MedConnect to make smarter health decisions.</p>
          <Link to="/login?tab=signup" className="btn btn-primary" style={{ padding: '16px 36px', fontSize: '1rem' }}>
            Create free account <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      <footer style={{ padding: '32px 40px', borderTop: '1px solid var(--border)', textAlign: 'center', color: 'var(--text3)', fontSize: '0.85rem', position: 'relative', zIndex: 1 }}>
        © 2025 MedConnect. For informational purposes only — not a substitute for professional medical advice.
      </footer>
    </div>
  );
}
