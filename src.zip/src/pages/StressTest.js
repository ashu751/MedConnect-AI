import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { Brain, RefreshCw, ChevronRight, CheckCircle } from 'lucide-react';

const QUESTIONS = [
  { q: 'How often have you felt unable to control important things in your life?', key: 'q1' },
  { q: 'How often have you felt nervous or stressed?', key: 'q2' },
  { q: 'How often have you been upset because of something unexpected?', key: 'q3' },
  { q: 'How often have you felt difficulties were piling up so high you could not overcome them?', key: 'q4' },
  { q: 'How often have you felt that things were going your way?', key: 'q5', reverse: true },
  { q: 'How often have you been able to control irritations in your life?', key: 'q6', reverse: true },
  { q: 'How often have you felt confident in your ability to handle personal problems?', key: 'q7', reverse: true },
  { q: 'How often have you felt on top of things?', key: 'q8', reverse: true },
  { q: 'How often have you been angered because of things outside your control?', key: 'q9' },
  { q: 'How often have you had trouble sleeping due to stress?', key: 'q10' },
];

const OPTIONS = ['Never','Almost Never','Sometimes','Fairly Often','Very Often'];

function getResult(score) {
  if (score <= 13) return { level: 'Low Stress', color: '#5bd3c7', desc: 'You are managing stress well. Keep up your healthy habits and self-care routines.', tips: ['Maintain your current exercise and sleep routines', 'Practice gratitude journaling to stay positive', 'Continue social connections and hobbies'] };
  if (score <= 26) return { level: 'Moderate Stress', color: '#f5a623', desc: 'You are experiencing moderate stress. This is common but worth addressing with healthy coping strategies.', tips: ['Try 10 minutes of deep breathing or meditation daily', 'Prioritize 7-8 hours of sleep each night', 'Break large tasks into smaller manageable steps', 'Talk to a trusted friend or family member'] };
  return { level: 'High Stress', color: '#f0628a', desc: 'You are experiencing high stress levels. It is important to take action and consider speaking with a professional.', tips: ['Consult a mental health professional or counselor', 'Practice the 4-7-8 breathing technique', 'Reduce caffeine and alcohol intake', 'Take regular breaks and set firm work boundaries', 'Consider yoga or mindfulness meditation'] };
}

export default function StressTest() {
  const { lang } = useTheme();
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [current, setCurrent] = useState(0);

  const answer = (key, value) => {
    setAnswers(prev => ({ ...prev, [key]: value }));
    if (current < QUESTIONS.length - 1) setTimeout(() => setCurrent(c => c + 1), 300);
  };

  const calculate = () => {
    const score = QUESTIONS.reduce((sum, q) => {
      const raw = answers[q.key] ?? 0;
      return sum + (q.reverse ? (4 - raw) : raw);
    }, 0);
    return score;
  };

  const submit = () => {
    if (Object.keys(answers).length < QUESTIONS.length) return;
    setSubmitted(true);
  };

  const reset = () => { setAnswers({}); setSubmitted(false); setCurrent(0); };

  const score = submitted ? calculate() : null;
  const result = score !== null ? getResult(score) : null;
  const progress = (Object.keys(answers).length / QUESTIONS.length) * 100;

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 700, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Mental Wellness</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('stressLevelTest',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('stressTestDesc',lang)}</p>
      </div>

      {!submitted ? (
        <div>
          {/* Progress */}
          <div style={{ marginBottom: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: '0.82rem', color: 'var(--text3)' }}>
              <span>Question {Math.min(current + 1, QUESTIONS.length)} of {QUESTIONS.length}</span>
              <span>{Object.keys(answers).length} answered</span>
            </div>
            <div style={{ height: 4, background: 'var(--surface2)', borderRadius: 2 }}>
              <div style={{ height: '100%', width: `${progress}%`, background: 'var(--accent)', borderRadius: 2, transition: 'width 0.3s' }} />
            </div>
          </div>

          {/* Current question */}
          <div className="card" style={{ marginBottom: 20, borderColor: 'rgba(124,106,247,0.2)' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--accent)', fontFamily: 'var(--font-mono)', marginBottom: 10 }}>Q{current + 1}</div>
            <p style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '1.05rem', lineHeight: 1.5, marginBottom: 20 }}>
              In the last month, {QUESTIONS[current].q.toLowerCase()}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {OPTIONS.map((opt, i) => {
                const selected = answers[QUESTIONS[current].key] === i;
                return (
                  <button key={i} onClick={() => answer(QUESTIONS[current].key, i)} style={{ padding: '12px 16px', borderRadius: 10, border: `1px solid ${selected ? 'var(--accent)' : 'var(--border2)'}`, background: selected ? 'rgba(124,106,247,0.12)' : 'var(--surface2)', color: selected ? 'var(--accent)' : 'var(--text2)', textAlign: 'left', cursor: 'pointer', fontWeight: selected ? 600 : 400, fontSize: '0.9rem', transition: 'all 0.15s', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    {opt} {selected && <CheckCircle size={16} />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Navigation */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 8 }}>
              {QUESTIONS.map((q, i) => (
                <button key={i} onClick={() => setCurrent(i)} style={{ width: 28, height: 28, borderRadius: '50%', border: answers[q.key] !== undefined ? 'none' : '1px solid var(--border2)', background: answers[q.key] !== undefined ? 'var(--accent)' : (i === current ? 'var(--surface2)' : 'transparent'), color: answers[q.key] !== undefined ? 'white' : 'var(--text3)', cursor: 'pointer', fontSize: '0.72rem', fontWeight: 600 }}>{i + 1}</button>
              ))}
            </div>
            {Object.keys(answers).length === QUESTIONS.length && (
              <button onClick={submit} className="btn btn-primary"><CheckCircle size={16} /> See Results</button>
            )}
          </div>
        </div>
      ) : (
        <div>
          {/* Score gauge */}
          <div className="card" style={{ textAlign: 'center', marginBottom: 20, borderColor: `${result.color}30` }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '4rem', fontWeight: 800, color: result.color, lineHeight: 1 }}>{score}</div>
            <div style={{ color: 'var(--text3)', fontSize: '0.82rem', marginBottom: 12 }}>out of 40</div>
            <div style={{ height: 8, background: 'var(--surface2)', borderRadius: 4, margin: '0 auto 16px', maxWidth: 300 }}>
              <div style={{ height: '100%', width: `${(score/40)*100}%`, background: result.color, borderRadius: 4 }} />
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700, color: result.color }}>{result.level}</div>
            <p style={{ color: 'var(--text3)', marginTop: 8, fontSize: '0.88rem', lineHeight: 1.6, maxWidth: 400, margin: '10px auto 0' }}>{result.desc}</p>
          </div>

          <div className="card" style={{ marginBottom: 20 }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 14, fontSize: '0.95rem' }}>Personalized Tips</h3>
            {result.tips.map((tip, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, marginBottom: 10, alignItems: 'flex-start' }}>
                <div style={{ width: 20, height: 20, borderRadius: '50%', background: `${result.color}20`, color: result.color, fontSize: '0.7rem', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>{i+1}</div>
                <p style={{ fontSize: '0.88rem', color: 'var(--text2)', lineHeight: 1.5 }}>{tip}</p>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 12 }}>
            <button onClick={reset} className="btn btn-secondary" style={{ gap: 8 }}><RefreshCw size={15} /> Retake Test</button>
          </div>
          <p style={{ marginTop: 14, fontSize: '0.75rem', color: 'var(--text3)' }}>⚠️ This is a screening tool only. For persistent high stress, please consult a qualified mental health professional.</p>
        </div>
      )}
    </div>
  );
}
