import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { Activity, TrendingUp, Info } from 'lucide-react';

function getBMICategory(bmi) {
  if (bmi < 18.5) return { label: 'Underweight', color: '#5bd3c7', tip: 'Consider eating more nutrient-rich foods and consult a doctor.' };
  if (bmi < 25) return { label: 'Normal weight', color: '#9fe87a', tip: 'Great! Maintain your current lifestyle with balanced diet and exercise.' };
  if (bmi < 30) return { label: 'Overweight', color: '#f5a623', tip: 'Moderate exercise and a balanced diet can help reach a healthier weight.' };
  return { label: 'Obese', color: '#f0628a', tip: 'Consult a healthcare professional for a personalized weight management plan.' };
}

function getBMIAngle(bmi) {
  const clamped = Math.min(Math.max(bmi, 10), 40);
  return ((clamped - 10) / 30) * 180;
}

export default function BMICalculator() {
  const { lang } = useTheme();
  const [unit, setUnit] = useState('metric');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [heightFt, setHeightFt] = useState('');
  const [heightIn, setHeightIn] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  const [result, setResult] = useState(null);

  const calculate = () => {
    let h, w;
    if (unit === 'metric') {
      h = parseFloat(height) / 100;
      w = parseFloat(weight);
    } else {
      const totalIn = parseFloat(heightFt) * 12 + parseFloat(heightIn || 0);
      h = totalIn * 0.0254;
      w = parseFloat(weight) * 0.453592;
    }
    if (!h || !w || h <= 0 || w <= 0) return;
    const bmi = w / (h * h);
    const idealMin = 18.5 * h * h;
    const idealMax = 24.9 * h * h;
    setResult({ bmi, idealMin, idealMax, weight: w, unit });
  };

  const cat = result ? getBMICategory(result.bmi) : null;
  const angle = result ? getBMIAngle(result.bmi) : 0;
  const needleX = 100 + 80 * Math.cos(((angle - 180) * Math.PI) / 180);
  const needleY = 90 - 80 * Math.sin(((angle) * Math.PI) / 180);

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Body Stats</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('bmiCalculatorTitle',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('bmiDesc',lang)}</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: result ? '1fr 1fr' : '1fr', gap: 24 }}>
        <div className="card">
          <div style={{ display: 'flex', gap: 4, background: 'var(--surface2)', borderRadius: 8, padding: 4, marginBottom: 20 }}>
            {['metric','imperial'].map(u => (
              <button key={u} onClick={() => { setUnit(u); setResult(null); }} style={{ flex: 1, padding: '8px', borderRadius: 6, border: 'none', background: unit === u ? 'var(--accent)' : 'transparent', color: unit === u ? 'white' : 'var(--text3)', fontWeight: unit === u ? 600 : 400, cursor: 'pointer', fontSize: '0.85rem', textTransform: 'capitalize', transition: 'all 0.2s' }}>
                {u}
              </button>
            ))}
          </div>

          {unit === 'metric' ? (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
              <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Height (cm)</label><input type="number" value={height} onChange={e => setHeight(e.target.value)} placeholder="e.g. 170" /></div>
              <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Weight (kg)</label><input type="number" value={weight} onChange={e => setWeight(e.target.value)} placeholder="e.g. 70" /></div>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, marginBottom: 14 }}>
              <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Feet</label><input type="number" value={heightFt} onChange={e => setHeightFt(e.target.value)} placeholder="5" /></div>
              <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Inches</label><input type="number" value={heightIn} onChange={e => setHeightIn(e.target.value)} placeholder="7" /></div>
              <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Weight (lbs)</label><input type="number" value={weight} onChange={e => setWeight(e.target.value)} placeholder="154" /></div>
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 20 }}>
            <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Age (optional)</label><input type="number" value={age} onChange={e => setAge(e.target.value)} placeholder="25" /></div>
            <div><label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Gender (optional)</label>
              <select value={gender} onChange={e => setGender(e.target.value)}>
                <option value="">Prefer not to say</option>
                <option>Male</option><option>Female</option><option>Other</option>
              </select>
            </div>
          </div>
          <button onClick={calculate} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
            <Activity size={16} /> Calculate BMI
          </button>

          {/* Reference table */}
          <div style={{ marginTop: 24, borderTop: '1px solid var(--border)', paddingTop: 20 }}>
            <p style={{ fontSize: '0.78rem', color: 'var(--text3)', marginBottom: 10, fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>BMI Reference</p>
            {[['< 18.5','Underweight','#5bd3c7'],['18.5–24.9','Normal','#9fe87a'],['25–29.9','Overweight','#f5a623'],['≥ 30','Obese','#f0628a']].map(([r,l,c]) => (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--border)', fontSize: '0.83rem' }}>
                <span style={{ color: 'var(--text3)' }}>{r}</span>
                <span style={{ color: c, fontWeight: 600 }}>{l}</span>
              </div>
            ))}
          </div>
        </div>

        {result && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Gauge */}
            <div className="card" style={{ textAlign: 'center', borderColor: `${cat.color}30` }}>
              <svg viewBox="0 0 200 110" style={{ width: '100%', maxWidth: 260, margin: '0 auto', display: 'block' }}>
                {/* Background arc segments */}
                {[['#5bd3c7',180,225],['#9fe87a',225,270],['#f5a623',270,315],['#f0628a',315,360]].map(([c,s,e]) => {
                  const r = 80, cx = 100, cy = 90;
                  const s1 = ((s-180)*Math.PI)/180, e1 = ((e-180)*Math.PI)/180;
                  const x1 = cx+r*Math.cos(s1), y1 = cy-r*Math.sin(-s1);
                  const x2 = cx+r*Math.cos(e1), y2 = cy-r*Math.sin(-e1);
                  return <path key={c} d={`M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 0 1 ${x2} ${y2} Z`} fill={c} opacity="0.25" />;
                })}
                {/* Arc border */}
                <path d="M 20 90 A 80 80 0 0 1 180 90" fill="none" stroke="var(--border2)" strokeWidth="8" strokeLinecap="round"/>
                <path d="M 20 90 A 80 80 0 0 1 180 90" fill="none" stroke={cat.color} strokeWidth="8" strokeLinecap="round" strokeDasharray={`${(angle/180)*251} 251`} opacity="0.8"/>
                {/* Needle */}
                <line x1="100" y1="90" x2={needleX} y2={needleY} stroke={cat.color} strokeWidth="3" strokeLinecap="round"/>
                <circle cx="100" cy="90" r="6" fill={cat.color}/>
                {/* Labels */}
                <text x="100" y="74" textAnchor="middle" fill={cat.color} fontSize="20" fontWeight="bold">{result.bmi.toFixed(1)}</text>
                <text x="100" y="86" textAnchor="middle" fill="var(--text3)" fontSize="9">BMI</text>
              </svg>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.1rem', color: cat.color, marginTop: 4 }}>{cat.label}</div>
            </div>

            {/* Stats */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div className="card" style={{ padding: 16, textAlign: 'center' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>Your BMI</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800, color: cat.color }}>{result.bmi.toFixed(1)}</div>
              </div>
              <div className="card" style={{ padding: 16, textAlign: 'center' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>Ideal Weight Range</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700 }}>
                  {result.idealMin.toFixed(0)}–{result.idealMax.toFixed(0)} kg
                </div>
              </div>
            </div>

            <div className="card" style={{ borderColor: `${cat.color}20` }}>
              <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                <Info size={15} color={cat.color} style={{ flexShrink: 0, marginTop: 1 }} />
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: cat.color, fontSize: '0.88rem' }}>Health Insight</span>
              </div>
              <p style={{ fontSize: '0.85rem', color: 'var(--text2)', lineHeight: 1.6 }}>{cat.tip}</p>
            </div>

            <div style={{ padding: '10px 14px', background: 'rgba(240,98,138,0.06)', border: '1px solid rgba(240,98,138,0.15)', borderRadius: 8, fontSize: '0.78rem', color: 'var(--text3)' }}>
              ⚠️ BMI is a general screening tool and doesn't account for muscle mass, age, or ethnicity. Consult a doctor for a full health assessment.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
