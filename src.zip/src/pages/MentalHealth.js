import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { Brain, Send, Bot, User, Wind, Smile, TrendingUp, Calendar } from 'lucide-react';

const GEMINI_API_KEY = process.env.REACT_APP_GEMINI_API_KEY || '';

const MENTAL_PROMPT = `You are a compassionate mental health companion. Your role is to:
- Provide empathetic, non-judgmental support
- Offer evidence-based coping strategies (CBT techniques, mindfulness, etc.)
- Help users identify and process emotions
- Suggest professional help when appropriate
- Never diagnose or prescribe medication
- Be warm, supportive, and validating

Keep responses concise and actionable. Use a gentle, encouraging tone.`;

const moods = [
  { emoji: '😰', label: 'Very Low', value: 1, color: '#f0628a' },
  { emoji: '😔', label: 'Low', value: 2, color: '#f5836a' },
  { emoji: '😐', label: 'Neutral', value: 3, color: '#f5a623' },
  { emoji: '🙂', label: 'Good', value: 4, color: '#9fe87a' },
  { emoji: '😄', label: 'Great', value: 5, color: '#5bd3c7' },
];

async function askMentalAI(messages) {
  if (!GEMINI_API_KEY) {
    await new Promise(r => setTimeout(r, 1200));
    const last = messages[messages.length - 1].content.toLowerCase();
    if (last.includes('anxious') || last.includes('anxiety') || last.includes('stress')) {
      return `I hear you, and I want you to know that what you're feeling is valid. Anxiety is one of the most common experiences humans have.

**A quick technique that can help right now:** Try the 4-7-8 breathing method — breathe in for 4 counts, hold for 7, exhale for 8. This activates your parasympathetic nervous system and can reduce anxiety within minutes.

**Also consider:**
• Grounding yourself — name 5 things you can see, 4 you can touch, 3 you can hear
• Writing down what's worrying you — it helps externalize the thoughts
• Gentle movement, even a 5-minute walk

Would you like to talk more about what's been triggering these feelings?`;
    }
    return `Thank you for sharing that with me. It takes courage to acknowledge how we're feeling.

I'm here to listen and support you. Could you tell me a bit more about what's been going on? Understanding your situation better will help me offer more meaningful support.

Remember — your feelings are valid, and you don't have to navigate them alone. 💙`;
  }

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: MENTAL_PROMPT }] },
      contents: messages.map(m => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.content }] })),
      generationConfig: { temperature: 0.75, maxOutputTokens: 800 }
    })
  });
  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || 'I\'m here for you. Please try again.';
}

// Breathing exercise component
function BreathingExercise() {
  const [phase, setPhase] = useState('idle'); // idle, inhale, hold, exhale
  const [count, setCount] = useState(0);
  const [cycles, setCycles] = useState(0);
  const intervalRef = useRef(null);

  const phases = { inhale: { dur: 4, next: 'hold', label: 'Breathe In', scale: 1.3 }, hold: { dur: 7, next: 'exhale', label: 'Hold', scale: 1.3 }, exhale: { dur: 8, next: 'inhale', label: 'Breathe Out', scale: 1 } };

  const start = () => { setPhase('inhale'); setCount(4); setCycles(0); };
  const stop = () => { setPhase('idle'); setCount(0); clearInterval(intervalRef.current); };

  useEffect(() => {
    if (phase === 'idle') return;
    const p = phases[phase];
    setCount(p.dur);
    intervalRef.current = setInterval(() => {
      setCount(prev => {
        if (prev <= 1) {
          clearInterval(intervalRef.current);
          const next = phases[phase].next;
          if (phase === 'exhale') setCycles(c => c + 1);
          setPhase(next);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(intervalRef.current);
  }, [phase]);

  const circleScale = phase === 'idle' ? 1 : (phase === 'inhale' ? 1 + (1 - count / 4) * 0.3 : phase === 'hold' ? 1.3 : 1 + (count / 8) * 0.3);

  return (
    <div style={{ textAlign: 'center', padding: '32px 24px' }}>
      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', fontWeight: 700, marginBottom: 8 }}>4-7-8 Breathing</h3>
      <p style={{ color: 'var(--text3)', fontSize: '0.85rem', marginBottom: 32 }}>A clinically proven technique to reduce anxiety and stress</p>
      
      <div style={{ position: 'relative', width: 160, height: 160, margin: '0 auto 32px' }}>
        <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: 'rgba(124,106,247,0.08)', border: '2px solid rgba(124,106,247,0.15)', transition: 'transform 1s ease', transform: `scale(${circleScale})` }} />
        <div style={{ position: 'absolute', inset: 16, borderRadius: '50%', background: 'rgba(124,106,247,0.12)', border: '2px solid rgba(124,106,247,0.2)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', transition: 'transform 1s ease', transform: `scale(${phase !== 'idle' ? circleScale * 0.95 : 1})` }}>
          <Wind size={28} color="var(--accent)" />
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 800, lineHeight: 1, marginTop: 4 }}>{phase !== 'idle' ? count : ''}</div>
        </div>
      </div>

      <div style={{ height: 32, marginBottom: 24 }}>
        {phase !== 'idle' && (
          <p style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600, color: 'var(--accent)' }}>
            {phases[phase]?.label} {count > 0 ? `(${count}s)` : ''}
          </p>
        )}
        {cycles > 0 && <p style={{ color: 'var(--text3)', fontSize: '0.8rem', marginTop: 4 }}>{cycles} cycle{cycles !== 1 ? 's' : ''} completed</p>}
      </div>

      <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
        {phase === 'idle' ? (
          <button onClick={start} className="btn btn-primary">Start Exercise</button>
        ) : (
          <button onClick={stop} className="btn btn-secondary">Stop</button>
        )}
      </div>
    </div>
  );
}

export default function MentalHealth() {
  const { lang } = useTheme();
  const { user, updateUser } = useAuth();
  const [tab, setTab] = useState('mood'); // mood, chat, breathe
  const [selectedMood, setSelectedMood] = useState(null);
  const [moodNote, setMoodNote] = useState('');
  const [moodSaved, setMoodSaved] = useState(false);
  const [messages, setMessages] = useState([
    { role: 'assistant', content: `Hi ${user?.name?.split(' ')[0] || 'there'} 💙 I'm your mental wellness companion. I'm here to listen, support, and help you develop healthy coping strategies.\n\nHow are you feeling today? You can talk to me about anything — stress, anxiety, emotions, or just how your day is going.` }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  const moodHistory = user?.moodHistory || [];

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const saveMood = () => {
    if (!selectedMood) return;
    const entry = { mood: selectedMood, note: moodNote, date: new Date().toISOString() };
    const history = [...moodHistory, entry];
    updateUser({ moodHistory: history.slice(-30) }); // keep last 30
    setMoodSaved(true);
    setTimeout(() => { setMoodSaved(false); setSelectedMood(null); setMoodNote(''); }, 2000);
  };

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: 'user', content: input.trim() };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);
    try {
      const reply = await askMentalAI(newMessages);
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'I apologize — I had trouble responding. Please try again. I\'m here for you.' }]);
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'mood', label: 'Mood Tracker', icon: Smile },
    { id: 'chat', label: 'AI Support', icon: Bot },
    { id: 'breathe', label: 'Breathing', icon: Wind },
  ];

  return (
    <div style={{ padding: '32px', maxWidth: 800, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
          <div style={{ width: 42, height: 42, borderRadius: 11, background: 'rgba(240,98,138,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Brain size={20} color="#f0628a" />
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 700 }}>Mental Health</h1>
        </div>
        <p style={{ color: 'var(--text3)', fontSize: '0.9rem' }}>Track your mood, get AI support, and practice mindfulness</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, background: 'var(--surface)', borderRadius: 12, padding: 4, marginBottom: 28, border: '1px solid var(--border)' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            padding: '10px 12px', borderRadius: 9, border: 'none',
            background: tab === t.id ? 'var(--surface2)' : 'transparent',
            color: tab === t.id ? 'var(--text)' : 'var(--text3)',
            fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.85rem',
            cursor: 'pointer', transition: 'all 0.2s'
          }}>
            <t.icon size={15} />
            <span className="tab-label">{t.label}</span>
          </button>
        ))}
      </div>

      {/* Mood Tracker */}
      {tab === 'mood' && (
        <div>
          <div className="card" style={{ marginBottom: 20 }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 4 }}>How are you feeling right now?</h3>
            <p style={{ color: 'var(--text3)', fontSize: '0.85rem', marginBottom: 24 }}>Tracking your mood daily helps identify patterns and triggers.</p>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 24 }}>
              {moods.map(m => (
                <button key={m.value} onClick={() => setSelectedMood(m)} style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
                  padding: '16px 20px', borderRadius: 12, border: `2px solid ${selectedMood?.value === m.value ? m.color : 'var(--border)'}`,
                  background: selectedMood?.value === m.value ? `${m.color}15` : 'var(--surface2)',
                  cursor: 'pointer', transition: 'all 0.2s', minWidth: 80
                }}>
                  <span style={{ fontSize: '2rem' }}>{m.emoji}</span>
                  <span style={{ fontSize: '0.75rem', color: selectedMood?.value === m.value ? m.color : 'var(--text3)', fontWeight: 600, fontFamily: 'var(--font-mono)' }}>{m.label}</span>
                </button>
              ))}
            </div>
            {selectedMood && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                <textarea value={moodNote} onChange={e => setMoodNote(e.target.value)} placeholder={`What's contributing to feeling ${selectedMood.label.toLowerCase()}? (optional)`} style={{ resize: 'vertical', minHeight: 80 }} />
                <button onClick={saveMood} className="btn btn-primary" style={{ alignSelf: 'flex-start' }}>
                  {moodSaved ? '✓ Saved!' : 'Log Mood'}
                </button>
              </div>
            )}
          </div>

          {/* History */}
          {moodHistory.length > 0 && (
            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
                <Calendar size={16} color="var(--text3)" />
                <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem' }}>Recent Mood Log</h3>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {moodHistory.slice(-7).reverse().map((entry, i) => {
                  const m = moods.find(x => x.value === entry.mood?.value) || entry.mood;
                  return (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', background: 'var(--surface2)', borderRadius: 10 }}>
                      <span style={{ fontSize: '1.4rem' }}>{m?.emoji}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '0.85rem', fontWeight: 600, color: m?.color }}>{m?.label}</div>
                        {entry.note && <div style={{ fontSize: '0.78rem', color: 'var(--text3)', marginTop: 2 }}>{entry.note}</div>}
                      </div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>
                        {new Date(entry.date).toLocaleDateString('en', { month: 'short', day: 'numeric' })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Chat */}
      {tab === 'chat' && (
        <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 280px)', minHeight: 400 }}>
          <div style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column', gap: 14, paddingBottom: 8 }}>
            {messages.map((msg, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                {msg.role === 'assistant' && (
                  <div style={{ width: 30, height: 30, borderRadius: 8, background: 'rgba(240,98,138,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Bot size={14} color="#f0628a" />
                  </div>
                )}
                <div className={msg.role === 'user' ? 'chat-user' : 'chat-ai'} style={{ maxWidth: '82%', padding: '12px 16px', fontSize: '0.88rem', lineHeight: 1.65, whiteSpace: 'pre-wrap' }}>
                  {msg.content}
                </div>
                {msg.role === 'user' && (
                  <div style={{ width: 30, height: 30, borderRadius: 8, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <User size={14} color="white" />
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div style={{ display: 'flex', gap: 10 }}>
                <div style={{ width: 30, height: 30, borderRadius: 8, background: 'rgba(240,98,138,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Bot size={14} color="#f0628a" />
                </div>
                <div className="chat-ai" style={{ padding: '14px 18px' }}>
                  <div style={{ display: 'flex', gap: 4 }}>
                    {[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--text3)', animation: 'bounce 1.2s ease infinite', animationDelay: `${i * 0.15}s` }} />)}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 12, padding: '12px', background: 'var(--surface)', borderRadius: 14, border: '1px solid var(--border2)' }}>
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()} placeholder="Share how you're feeling..." style={{ border: 'none', background: 'transparent', padding: '4px 8px', flex: 1, fontSize: '0.9rem', outline: 'none', boxShadow: 'none' }} disabled={loading} />
            <button onClick={send} disabled={loading || !input.trim()} className="btn btn-primary" style={{ padding: '10px 16px', flexShrink: 0, opacity: (!input.trim() || loading) ? 0.5 : 1, background: '#f0628a', boxShadow: '0 4px 16px rgba(240,98,138,0.3)' }}>
              <Send size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Breathing */}
      {tab === 'breathe' && (
        <div className="card">
          <BreathingExercise />
          <div style={{ borderTop: '1px solid var(--border)', paddingTop: 24, marginTop: 16 }}>
            <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 12, fontSize: '0.95rem' }}>Why 4-7-8 breathing?</h4>
            <p style={{ color: 'var(--text3)', fontSize: '0.85rem', lineHeight: 1.7 }}>
              This technique, developed by Dr. Andrew Weil, activates the parasympathetic nervous system. The extended exhale stimulates the vagus nerve, naturally reducing heart rate and cortisol levels. Regular practice can reduce anxiety, improve sleep, and build stress resilience.
            </p>
          </div>
        </div>
      )}

      <style>{`@keyframes bounce { 0%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-5px); } } @media(max-width:500px) { .tab-label { display: none; } }`}</style>
    </div>
  );
}
