import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useEffect } from 'react';
import { Target, Plus, Trash2, CheckCircle, Droplets, Moon, Footprints, Apple, Dumbbell, Heart } from 'lucide-react';

const STORAGE_KEY = 'mc_health_goals';
const TEMPLATES = [
  { icon: '💧', label: 'Drink 8 glasses of water', unit: 'glasses', target: 8, color: '#5bd3c7', category: 'Hydration' },
  { icon: '😴', label: 'Sleep 8 hours', unit: 'hours', target: 8, color: '#7c6af7', category: 'Sleep' },
  { icon: '🚶', label: 'Walk 10,000 steps', unit: 'steps', target: 10000, color: '#f5a623', category: 'Fitness' },
  { icon: '🍎', label: 'Eat 5 fruits/vegetables', unit: 'servings', target: 5, color: '#9fe87a', category: 'Nutrition' },
  { icon: '🏋️', label: 'Exercise 30 minutes', unit: 'minutes', target: 30, color: '#f0628a', category: 'Fitness' },
  { icon: '🧘', label: 'Meditate 10 minutes', unit: 'minutes', target: 10, color: '#5bd3c7', category: 'Mental' },
];

export default function HealthGoals() {
  const { lang } = useTheme();
  const [goals, setGoals] = useState(() => JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'));
  const [progress, setProgress] = useState(() => JSON.parse(localStorage.getItem('mc_goals_progress_' + new Date().toDateString()) || '{}'));
  const [adding, setAdding] = useState(false);
  const [custom, setCustom] = useState({ label: '', unit: 'times', target: 1, icon: '🎯', color: '#7c6af7', category: 'Custom' });

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(goals)); }, [goals]);
  useEffect(() => { localStorage.setItem('mc_goals_progress_' + new Date().toDateString(), JSON.stringify(progress)); }, [progress]);

  const addTemplate = (t) => {
    if (goals.find(g => g.label === t.label)) return;
    setGoals(prev => [...prev, { ...t, id: Date.now() }]);
  };

  const addCustom = () => {
    if (!custom.label.trim()) return;
    setGoals(prev => [...prev, { ...custom, id: Date.now(), label: custom.label.trim() }]);
    setCustom({ label: '', unit: 'times', target: 1, icon: '🎯', color: '#7c6af7', category: 'Custom' });
    setAdding(false);
  };

  const remove = (id) => setGoals(prev => prev.filter(g => g.id !== id));

  const increment = (id, target) => {
    setProgress(prev => ({ ...prev, [id]: Math.min((prev[id] || 0) + 1, target) }));
  };
  const decrement = (id) => {
    setProgress(prev => ({ ...prev, [id]: Math.max((prev[id] || 0) - 1, 0) }));
  };

  const completedToday = goals.filter(g => (progress[g.id] || 0) >= g.target).length;
  const streak = parseInt(localStorage.getItem('mc_goal_streak') || '0');

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Daily Progress</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('healthGoalsTitle',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('healthGoalsDesc',lang)}</p>
      </div>

      {goals.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 28 }}>
          <div className="card" style={{ padding: 16, textAlign: 'center' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>Today</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent)' }}>{completedToday}/{goals.length}</div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text3)' }}>goals done</div>
          </div>
          <div className="card" style={{ padding: 16, textAlign: 'center' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>Completion</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800, color: '#5bd3c7' }}>{goals.length ? Math.round((completedToday/goals.length)*100) : 0}%</div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text3)' }}>today</div>
          </div>
          <div className="card" style={{ padding: 16, textAlign: 'center' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>Active Goals</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800, color: '#f5a623' }}>{goals.length}</div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text3)' }}>tracking</div>
          </div>
        </div>
      )}

      {/* Quick add templates */}
      <div className="card" style={{ marginBottom: 24 }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 14 }}>Quick Add</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {TEMPLATES.map(t => {
            const added = goals.find(g => g.label === t.label);
            return (
              <button key={t.label} onClick={() => addTemplate(t)} disabled={!!added} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', borderRadius: 100, border: `1px solid ${added ? t.color + '40' : 'var(--border2)'}`, background: added ? t.color + '15' : 'var(--surface2)', color: added ? t.color : 'var(--text2)', fontSize: '0.82rem', cursor: added ? 'default' : 'pointer', transition: 'all 0.15s' }}>
                <span style={{ fontSize: '0.9rem' }}>{t.icon}</span> {t.label} {added && '✓'}
              </button>
            );
          })}
          <button onClick={() => setAdding(!adding)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', borderRadius: 100, border: '1px dashed var(--border2)', background: 'transparent', color: 'var(--accent)', fontSize: '0.82rem', cursor: 'pointer' }}>
            <Plus size={13} /> Custom
          </button>
        </div>
        {adding && (
          <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--border)', display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 10 }}>
            <input value={custom.label} onChange={e => setCustom(c => ({...c, label: e.target.value}))} placeholder="Goal name..." />
            <input type="number" value={custom.target} min={1} onChange={e => setCustom(c => ({...c, target: parseInt(e.target.value)}))} placeholder="Target" />
            <input value={custom.unit} onChange={e => setCustom(c => ({...c, unit: e.target.value}))} placeholder="unit (e.g. cups)" />
            <button onClick={addCustom} className="btn btn-primary" style={{ gridColumn: '1/-1', justifyContent: 'center', padding: '10px' }}>Add Custom Goal</button>
          </div>
        )}
      </div>

      {/* Goals list */}
      {goals.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 48 }}>
          <Target size={36} color="var(--text3)" style={{ margin: '0 auto 12px' }} />
          <p style={{ color: 'var(--text3)' }}>No goals yet. Add some from the quick-add options above!</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {goals.map(g => {
            const cur = progress[g.id] || 0;
            const pct = Math.min((cur / g.target) * 100, 100);
            const done = cur >= g.target;
            return (
              <div key={g.id} className="card" style={{ padding: '16px 20px', borderColor: done ? `${g.color}30` : 'var(--border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ fontSize: '1.3rem' }}>{g.icon}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                      <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>{g.label}</span>
                      {done && <CheckCircle size={14} color={g.color} />}
                    </div>
                    <div style={{ height: 6, background: 'var(--surface2)', borderRadius: 3, overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${pct}%`, background: g.color, borderRadius: 3, transition: 'width 0.3s' }} />
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginTop: 4 }}>{cur} / {g.target} {g.unit}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexShrink: 0 }}>
                    <button onClick={() => decrement(g.id)} style={{ width: 28, height: 28, borderRadius: '50%', border: '1px solid var(--border2)', background: 'var(--surface2)', color: 'var(--text2)', cursor: 'pointer', fontSize: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>−</button>
                    <button onClick={() => increment(g.id, g.target)} disabled={done} style={{ width: 28, height: 28, borderRadius: '50%', border: 'none', background: done ? `${g.color}20` : g.color, color: done ? g.color : 'white', cursor: done ? 'default' : 'pointer', fontSize: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
                    <button onClick={() => remove(g.id)} style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', padding: 4 }}><Trash2 size={14} /></button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
