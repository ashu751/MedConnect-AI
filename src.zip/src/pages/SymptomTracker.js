import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Plus, TrendingUp, AlertCircle, Calendar, Trash2, Activity } from 'lucide-react';

const SYMPTOM_LIST = ['Headache','Fever','Fatigue','Nausea','Cough','Back Pain','Joint Pain','Dizziness','Chest Pain','Shortness of Breath','Stomach Ache','Sore Throat','Runny Nose','Insomnia','Anxiety','Loss of Appetite'];
const SEVERITY = [{label:'Mild',value:1,color:'#5bd3c7'},{label:'Moderate',value:2,color:'#f5a623'},{label:'Severe',value:3,color:'#f0628a'}];

export default function SymptomTracker() {
  const { lang } = useTheme();
  const { user, updateUser } = useAuth();
  const symptoms = user.symptoms || [];
  const [selected, setSelected] = useState('');
  const [custom, setCustom] = useState('');
  const [severity, setSeverity] = useState(1);
  const [notes, setNotes] = useState('');
  const [saved, setSaved] = useState(false);

  const add = () => {
    const name = custom.trim() || selected;
    if (!name) return;
    const entry = { id: Date.now(), name, severity, notes: notes.trim(), date: new Date().toISOString() };
    updateUser({ symptoms: [entry, ...symptoms] });
    setSelected(''); setCustom(''); setSeverity(1); setNotes('');
    setSaved(true); setTimeout(() => setSaved(false), 2000);
  };

  const remove = (id) => updateUser({ symptoms: symptoms.filter(s => s.id !== id) });

  // Pattern detection
  const patterns = Object.entries(
    symptoms.reduce((acc, s) => { acc[s.name] = (acc[s.name] || 0) + 1; return acc; }, {})
  ).filter(([,c]) => c >= 2).sort((a,b) => b[1]-a[1]);

  const sevColor = (v) => SEVERITY.find(s => s.value === v)?.color || '#5bd3c7';
  const sevLabel = (v) => SEVERITY.find(s => s.value === v)?.label || '';

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Health Tracking</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('symptomPatternTracker',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('symptomTrackerDesc',lang)}</p>
      </div>

      {patterns.length > 0 && (
        <div style={{ padding: '16px 20px', background: 'rgba(124,106,247,0.08)', border: '1px solid rgba(124,106,247,0.2)', borderRadius: 14, marginBottom: 28 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <TrendingUp size={16} color="var(--accent)" />
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.9rem', color: 'var(--accent)' }}>Recurring Patterns Detected</span>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {patterns.map(([name, count]) => (
              <div key={name} style={{ padding: '6px 14px', borderRadius: 100, background: 'rgba(124,106,247,0.15)', border: '1px solid rgba(124,106,247,0.25)', fontSize: '0.82rem' }}>
                <span style={{ color: 'var(--text)' }}>{name}</span>
                <span style={{ color: 'var(--accent)', fontWeight: 700, marginLeft: 6 }}>×{count}</span>
              </div>
            ))}
          </div>
          <p style={{ marginTop: 10, fontSize: '0.8rem', color: 'var(--text3)' }}>These symptoms appear frequently. Consider discussing with a doctor if they persist.</p>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* Log form */}
        <div className="card">
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem', marginBottom: 20 }}>Log a Symptom</h2>
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Choose symptom</label>
            <select value={selected} onChange={e => { setSelected(e.target.value); setCustom(''); }} style={{ marginBottom: 8 }}>
              <option value="">— Select from list —</option>
              {SYMPTOM_LIST.map(s => <option key={s}>{s}</option>)}
            </select>
            <input value={custom} onChange={e => { setCustom(e.target.value); setSelected(''); }} placeholder="Or type a custom symptom..." />
          </div>
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 8 }}>Severity</label>
            <div style={{ display: 'flex', gap: 8 }}>
              {SEVERITY.map(s => (
                <button key={s.value} onClick={() => setSeverity(s.value)} style={{ flex: 1, padding: '8px', borderRadius: 8, border: `1px solid ${severity === s.value ? s.color : 'var(--border2)'}`, background: severity === s.value ? `${s.color}20` : 'var(--surface)', color: severity === s.value ? s.color : 'var(--text3)', fontWeight: severity === s.value ? 600 : 400, cursor: 'pointer', fontSize: '0.85rem', transition: 'all 0.15s' }}>
                  {s.label}
                </button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: '0.8rem', color: 'var(--text3)', display: 'block', marginBottom: 6 }}>Notes (optional)</label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Any additional context..." rows={3} style={{ resize: 'vertical' }} />
          </div>
          <button onClick={add} disabled={!selected && !custom.trim()} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', opacity: (!selected && !custom.trim()) ? 0.5 : 1 }}>
            {saved ? '✓ Saved!' : <><Plus size={16} /> Log Symptom</>}
          </button>
        </div>

        {/* History */}
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem', marginBottom: 16 }}>
            History <span style={{ color: 'var(--text3)', fontWeight: 400, fontSize: '0.85rem' }}>({symptoms.length} entries)</span>
          </h2>
          {symptoms.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: 40 }}>
              <Activity size={32} color="var(--text3)" style={{ margin: '0 auto 12px' }} />
              <p style={{ color: 'var(--text3)', fontSize: '0.9rem' }}>No symptoms logged yet.<br />Add your first entry to start tracking.</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 500, overflowY: 'auto', paddingRight: 4 }}>
              {symptoms.map(s => (
                <div key={s.id} className="card" style={{ padding: '14px 16px', borderColor: `${sevColor(s.severity)}20` }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                        <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>{s.name}</span>
                        <span style={{ fontSize: '0.72rem', padding: '2px 8px', borderRadius: 100, background: `${sevColor(s.severity)}20`, color: sevColor(s.severity), fontWeight: 600 }}>{sevLabel(s.severity)}</span>
                      </div>
                      {s.notes && <p style={{ fontSize: '0.8rem', color: 'var(--text3)', marginBottom: 4 }}>{s.notes}</p>}
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: '0.75rem', color: 'var(--text3)' }}>
                        <Calendar size={11} />
                        {new Date(s.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    <button onClick={() => remove(s.id)} style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', padding: 4, flexShrink: 0 }}>
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {symptoms.length > 0 && (
        <div style={{ marginTop: 16, padding: '10px 14px', background: 'rgba(240,98,138,0.06)', border: '1px solid rgba(240,98,138,0.15)', borderRadius: 8, display: 'flex', gap: 8 }}>
          <AlertCircle size={14} color="var(--accent3)" style={{ flexShrink: 0, marginTop: 2 }} />
          <span style={{ fontSize: '0.78rem', color: 'var(--text3)' }}>Symptom tracking is for personal awareness only. Always consult a doctor for diagnosis and treatment.</span>
        </div>
      )}
    </div>
  );
}
