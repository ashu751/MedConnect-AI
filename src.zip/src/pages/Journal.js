import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { BookOpen, Plus, Trash2, Bot, Calendar, ChevronDown, ChevronUp } from 'lucide-react';

const GEMINI_API_KEY = process.env.REACT_APP_GEMINI_API_KEY || '';
const STORAGE_KEY = 'mc_journal_entries';

const SENTIMENT_PROMPT = `You are a compassionate journal analyzer. Given a journal entry, respond with ONLY a JSON object in this exact format (no markdown, no extra text):
{"sentiment":"Positive","score":80,"summary":"Brief 1-sentence summary of the entry","insight":"A warm, supportive 1-2 sentence insight or reflection","keywords":["word1","word2","word3"]}
Sentiment must be one of: Positive, Neutral, Negative. Score is 0-100 (100 = most positive).`;

async function analyzeSentiment(text) {
  if (!GEMINI_API_KEY) {
    await new Promise(r => setTimeout(r, 800));
    const words = text.toLowerCase();
    const positive = ['happy','great','good','wonderful','excited','grateful','love','joy','amazing'].filter(w => words.includes(w)).length;
    const negative = ['sad','bad','terrible','awful','stressed','anxious','tired','worried','hate'].filter(w => words.includes(w)).length;
    const score = Math.min(Math.max(50 + (positive - negative) * 10, 0), 100);
    const sentiment = score >= 65 ? 'Positive' : score >= 40 ? 'Neutral' : 'Negative';
    return { sentiment, score, summary: 'A personal reflection on your day.', insight: 'Thank you for taking the time to journal. Writing regularly helps process emotions and build self-awareness.', keywords: ['reflection', 'personal', 'growth'] };
  }
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ system_instruction: { parts: [{ text: SENTIMENT_PROMPT }] }, contents: [{ role: 'user', parts: [{ text }] }], generationConfig: { temperature: 0.3, maxOutputTokens: 256 } })
  });
  const data = await res.json();
  const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
  try { return JSON.parse(raw.replace(/```json|```/g, '').trim()); } catch { return { sentiment: 'Neutral', score: 50, summary: 'Entry analyzed.', insight: 'Keep journaling!', keywords: [] }; }
}

const sentimentColor = { Positive: '#5bd3c7', Neutral: '#f5a623', Negative: '#f0628a' };

export default function Journal() {
  const { lang } = useTheme();
  const [entries, setEntries] = useState(() => JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'));
  const [text, setText] = useState('');
  const [title, setTitle] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [expanded, setExpanded] = useState(null);

  const save = localStorage.setItem.bind(localStorage, STORAGE_KEY);

  const submit = async () => {
    if (!text.trim()) return;
    setAnalyzing(true);
    const analysis = await analyzeSentiment(text);
    const entry = { id: Date.now(), title: title.trim() || 'Untitled Entry', text: text.trim(), date: new Date().toISOString(), analysis };
    const updated = [entry, ...entries];
    setEntries(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setText(''); setTitle(''); setAnalyzing(false);
  };

  const remove = (id) => {
    const updated = entries.filter(e => e.id !== id);
    setEntries(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Mental Wellness</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('dailyJournal',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('journalDesc',lang)}</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* Write */}
        <div className="card">
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 16 }}>Today's Entry</h3>
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Entry title (optional)..." style={{ marginBottom: 10 }} />
          <textarea value={text} onChange={e => setText(e.target.value)} placeholder="How are you feeling today? Write anything on your mind — your thoughts, experiences, emotions..." rows={10} style={{ resize: 'vertical', marginBottom: 14 }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text3)' }}>{text.length} characters</span>
            <button onClick={submit} disabled={!text.trim() || analyzing} className="btn btn-primary" style={{ opacity: (!text.trim() || analyzing) ? 0.6 : 1 }}>
              {analyzing ? <><div className="spinner" style={{ width: 14, height: 14, borderWidth: 2 }} /> Analyzing...</> : <><Bot size={15} /> Save & Analyze</>}
            </button>
          </div>
        </div>

        {/* Entries */}
        <div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 16 }}>
            Past Entries <span style={{ color: 'var(--text3)', fontWeight: 400 }}>({entries.length})</span>
          </h3>
          {entries.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: 40 }}>
              <BookOpen size={32} color="var(--text3)" style={{ margin: '0 auto 12px' }} />
              <p style={{ color: 'var(--text3)', fontSize: '0.88rem' }}>No entries yet. Write your first journal entry!</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 540, overflowY: 'auto', paddingRight: 4 }}>
              {entries.map(e => {
                const color = sentimentColor[e.analysis?.sentiment] || '#7c6af7';
                const isOpen = expanded === e.id;
                return (
                  <div key={e.id} className="card" style={{ padding: '14px 16px', borderColor: `${color}20` }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                          <span style={{ fontWeight: 600, fontSize: '0.88rem' }}>{e.title}</span>
                          {e.analysis && <span style={{ fontSize: '0.7rem', padding: '2px 8px', borderRadius: 100, background: `${color}20`, color }}>{e.analysis.sentiment}</span>}
                        </div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text3)', display: 'flex', alignItems: 'center', gap: 4 }}>
                          <Calendar size={11} />
                          {new Date(e.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </div>
                        {isOpen && (
                          <div style={{ marginTop: 10 }}>
                            <p style={{ fontSize: '0.83rem', color: 'var(--text2)', lineHeight: 1.6, marginBottom: 10, borderTop: '1px solid var(--border)', paddingTop: 10 }}>{e.text}</p>
                            {e.analysis && (
                              <div style={{ padding: '10px 12px', background: `${color}08`, borderRadius: 8, border: `1px solid ${color}20` }}>
                                <div style={{ fontSize: '0.75rem', color, fontWeight: 600, marginBottom: 4 }}>AI Insight</div>
                                <p style={{ fontSize: '0.8rem', color: 'var(--text2)', lineHeight: 1.5 }}>{e.analysis.insight}</p>
                                {e.analysis.keywords?.length > 0 && (
                                  <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginTop: 8 }}>
                                    {e.analysis.keywords.map(k => <span key={k} style={{ fontSize: '0.7rem', padding: '2px 8px', borderRadius: 100, background: 'var(--surface2)', color: 'var(--text3)' }}>{k}</span>)}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
                        <button onClick={() => setExpanded(isOpen ? null : e.id)} style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', padding: 4 }}>
                          {isOpen ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                        </button>
                        <button onClick={() => remove(e.id)} style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', padding: 4 }}><Trash2 size={13} /></button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
