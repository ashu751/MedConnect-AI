import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Eye, EyeOff, Activity, ArrowLeft, CheckCircle, XCircle } from 'lucide-react';

function PasswordStrength({ password }) {
  if (!password) return null;
  const checks = [
    { label: 'At least 8 characters', pass: password.length >= 8 },
    { label: 'Contains a number', pass: /\d/.test(password) },
    { label: 'Contains a letter', pass: /[a-zA-Z]/.test(password) },
  ];
  return (
    <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
      {checks.map((c, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: '0.78rem', color: c.pass ? '#5bd3c7' : 'var(--text3)' }}>
          {c.pass ? <CheckCircle size={12} /> : <XCircle size={12} />}
          {c.label}
        </div>
      ))}
    </div>
  );
}

export default function AuthPage() {
  const [params] = useSearchParams();
  const [isSignup, setIsSignup] = useState(params.get('tab') === 'signup');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, signup } = useAuth();
  const navigate = useNavigate();

  useEffect(() => { setIsSignup(params.get('tab') === 'signup'); }, [params]);

  const handle = async (e) => {
    e.preventDefault();
    setError(''); setLoading(true);
    const result = isSignup
      ? await signup(form.name, form.email, form.password)
      : await login(form.email, form.password);
    setLoading(false);
    if (result.error) setError(result.error);
    else navigate('/dashboard');
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, position: 'relative', overflow: 'hidden' }}>
      <div className="gradient-orb" style={{ width: 500, height: 500, background: 'radial-gradient(circle, rgba(124,106,247,0.12) 0%, transparent 70%)', top: -150, right: -100 }} />
      <div className="gradient-orb" style={{ width: 400, height: 400, background: 'radial-gradient(circle, rgba(91,211,199,0.07) 0%, transparent 70%)', bottom: -100, left: -100 }} />

      <div style={{ width: '100%', maxWidth: 420, position: 'relative', zIndex: 1 }}>
        <Link to="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, color: 'var(--text3)', fontSize: '0.85rem', marginBottom: 32, transition: 'color 0.2s' }}
          onMouseEnter={e => e.currentTarget.style.color = 'var(--text)'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--text3)'}>
          <ArrowLeft size={15} /> Back to home
        </Link>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 40 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 16px rgba(124,106,247,0.4)' }}>
            <Activity size={18} color="white" />
          </div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.1rem' }}>MedConnect</span>
        </div>

        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, marginBottom: 8, letterSpacing: '-0.02em' }}>
          {isSignup ? 'Create account' : 'Welcome back'}
        </h1>
        <p style={{ color: 'var(--text3)', marginBottom: 36, fontSize: '0.95rem' }}>
          {isSignup ? 'Start your health journey today' : 'Sign in to your account'}
        </p>

        {/* Toggle */}
        <div style={{ display: 'flex', background: 'var(--surface)', borderRadius: 10, padding: 4, marginBottom: 28, border: '1px solid var(--border)' }}>
          {['Sign in', 'Sign up'].map((t, i) => (
            <button key={i} onClick={() => { setIsSignup(i === 1); setError(''); setForm({ name: '', email: '', password: '' }); }} style={{
              flex: 1, padding: '10px', borderRadius: 8, border: 'none',
              background: isSignup === (i === 1) ? 'var(--accent)' : 'transparent',
              color: isSignup === (i === 1) ? 'white' : 'var(--text3)',
              fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.88rem',
              cursor: 'pointer', transition: 'all 0.2s'
            }}>{t}</button>
          ))}
        </div>

        <form onSubmit={handle} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {isSignup && (
            <div>
              <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 600, marginBottom: 6, color: 'var(--text2)' }}>Full Name</label>
              <input
                type="text" placeholder="Kunal Sharma" value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                autoComplete="name" required
              />
            </div>
          )}

          <div>
            <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 600, marginBottom: 6, color: 'var(--text2)' }}>Email</label>
            <input
              type="email" placeholder="you@example.com" value={form.email}
              onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              autoComplete="email" required
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 600, marginBottom: 6, color: 'var(--text2)' }}>Password</label>
            <div style={{ position: 'relative' }}>
              <input
                type={showPass ? 'text' : 'password'}
                placeholder={isSignup ? 'Min 8 characters' : 'Your password'}
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                autoComplete={isSignup ? 'new-password' : 'current-password'}
                required style={{ paddingRight: 44 }}
              />
              <button type="button" onClick={() => setShowPass(!showPass)} style={{
                position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', padding: 4
              }}>
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            {/* #11 Password strength indicator on signup */}
            {isSignup && <PasswordStrength password={form.password} />}
          </div>

          {error && (
            <div style={{ padding: '10px 14px', background: 'rgba(240,98,138,0.08)', border: '1px solid rgba(240,98,138,0.2)', borderRadius: 8, fontSize: '0.85rem', color: 'var(--accent3)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <XCircle size={14} style={{ flexShrink: 0 }} /> {error}
            </div>
          )}

          <button type="submit" disabled={loading} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 8, opacity: loading ? 0.7 : 1 }}>
            {loading ? <><div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Processing...</> : isSignup ? 'Create account' : 'Sign in'}
          </button>
        </form>

        {/* #2 - API key security notice */}
        <div style={{ marginTop: 24, padding: '12px 14px', background: 'rgba(91,211,199,0.06)', border: '1px solid rgba(91,211,199,0.12)', borderRadius: 10 }}>
          <p style={{ fontSize: '0.75rem', color: 'var(--text3)', lineHeight: 1.6 }}>
            🔒 Your data is stored locally on your device. Passwords are hashed before storage. This app never sends your personal data to external servers.
          </p>
        </div>
      </div>
    </div>
  );
}
