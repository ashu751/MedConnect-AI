import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import { Stethoscope, Brain, MapPin, BarChart3, ArrowRight, TrendingUp, Calendar, Activity, Heart, Star, ScanLine, Pill, Target, Shield, Phone, Flame, Apple, Wind, BookOpen, BarChart, FileText } from 'lucide-react';

const TIPS = {
  en: ['Drink at least 8 glasses of water daily.','Aim for 7–9 hours of quality sleep.','Take a 5-minute break every hour at your desk.','30 minutes of walking daily improves your mood.','Deep breathing for 5 minutes reduces cortisol.','Fiber-rich foods support gut health and immunity.','Limit screen time 1 hour before bed.','Social connection is as important as exercise.','Morning sunlight regulates your circadian rhythm.','Stretching 10 minutes daily reduces injury risk.','Chewing slowly improves digestion and satiety.','A 20-minute nap boosts alertness without grogginess.','Washing hands for 20 seconds prevents infection.','Eating a rainbow of vegetables provides key nutrients.','Time in nature reduces blood pressure and stress.','Magnesium-rich foods (nuts, greens) improve sleep.','Laughter genuinely boosts immunity and mood.','Sitting less than 6 hours reduces cardiovascular risk.','Cold water on your face can quickly reduce stress.','Journaling 5 minutes daily improves mental clarity.'],
  hi: ['रोज़ कम से कम 8 गिलास पानी पिएं।','7–9 घंटे की गुणवत्तापूर्ण नींद लें।','डेस्क पर हर घंटे 5 मिनट का ब्रेक लें।','30 मिनट पैदल चलने से मूड बेहतर होता है।','5 मिनट गहरी सांस लेने से तनाव कम होता है।','फाइबर युक्त भोजन पेट और रोग प्रतिरोधक क्षमता के लिए अच्छा है।','सोने से 1 घंटे पहले स्क्रीन का उपयोग कम करें।','सामाजिक जुड़ाव व्यायाम जितना ज़रूरी है।','सुबह की धूप आपकी नींद की लय ठीक करती है।','रोज़ 10 मिनट स्ट्रेचिंग से चोट का खतरा कम होता है।','धीरे-धीरे खाने से पाचन बेहतर होता है।','20 मिनट की झपकी बिना थकान के सतर्कता बढ़ाती है।','20 सेकंड हाथ धोने से संक्रमण से बचाव होता है।','रंग-बिरंगी सब्ज़ियाँ खाने से पोषण मिलता है।','प्रकृति में समय बिताने से रक्तचाप कम होता है।','मैग्नीशियम युक्त खाद्य पदार्थ नींद बेहतर करते हैं।','हँसी सच में रोग प्रतिरोधक क्षमता बढ़ाती है।','6 घंटे से कम बैठने से हृदय रोग का खतरा कम होता है।','चेहरे पर ठंडा पानी तुरंत तनाव कम करता है।','5 मिनट जर्नलिंग से मानसिक स्पष्टता आती है।']
};

const FEATURE_SECTIONS = (lang) => [
  { label: t('aiTools', lang), color: '#5bd3c7', features: [
    { path: '/medical-ai', icon: Stethoscope, title: t('aiDoctor', lang), desc: lang==='hi'?'लक्षण बताएं, AI सुझाव पाएं':'Describe symptoms, get insights', tag: 'Gemini AI' },
    { path: '/prescription', icon: ScanLine, title: t('rxScanner', lang), desc: lang==='hi'?'प्रिस्क्रिप्शन अपलोड और समझें':'Upload & understand prescriptions', tag: lang==='hi'?'नया':'New' },
    { path: '/symptoms', icon: TrendingUp, title: t('symptomTracker', lang), desc: lang==='hi'?'लक्षण लॉग करें और पैटर्न देखें':'Log and detect recurring patterns', tag: lang==='hi'?'पैटर्न':'Patterns' },
  ]},
  { label: t('myHealth', lang), color: '#7c6af7', features: [
    { path: '/medicines', icon: Pill, title: t('medicineReminder', lang), desc: lang==='hi'?'खुराक ट्रैकिंग और इंटरेक्शन':'Dosage tracking & interactions', tag: lang==='hi'?'रोज़':'Daily' },
    { path: '/bmi', icon: Activity, title: t('bmiCalculator', lang), desc: lang==='hi'?'विज़ुअल गेज के साथ स्वास्थ्य सुझाव':'Visual gauge with health insights', tag: lang==='hi'?'आँकड़े':'Stats' },
    { path: '/goals', icon: Target, title: t('healthGoals', lang), desc: lang==='hi'?'रोज़ के लक्ष्य और प्रगति':'Daily targets with progress', tag: lang==='hi'?'लक्ष्य':'Goals' },
    { path: '/vaccines', icon: Shield, title: t('vaccination', lang), desc: lang==='hi'?'टीकाकरण रिकॉर्ड और रिमाइंडर':'Immunization records & reminders', tag: lang==='hi'?'रोकथाम':'Prevention' },
    { path: '/streaks', icon: Flame, title: t('streakTracker', lang), desc: lang==='hi'?'रोज़ की स्ट्रीक से आदतें बनाएं':'Build habits with daily streaks', tag: lang==='hi'?'आदतें':'Habits' },
    { path: '/calories', icon: Apple, title: t('calorieWater', lang), desc: lang==='hi'?'खाना और पानी लॉग करें':'Log meals and hydration', tag: lang==='hi'?'पोषण':'Nutrition' },
  ]},
  { label: t('mentalWellnessNav', lang), color: '#f0628a', features: [
    { path: '/mental-health', icon: Brain, title: t('mentalHealth', lang), desc: lang==='hi'?'मूड ट्रैकिंग और AI सहायता':'Mood tracking & AI support', tag: lang==='hi'?'स्वास्थ्य':'Wellness' },
    { path: '/meditation', icon: Wind, title: t('meditation', lang), desc: lang==='hi'?'साँस व्यायाम के साथ निर्देशित ध्यान':'Guided sessions with breathing', tag: lang==='hi'?'शांति':'Calm' },
    { path: '/journal', icon: BookOpen, title: t('journal', lang), desc: lang==='hi'?'स्वतंत्र लिखें, AI मूड विश्लेषण करे':'Write freely, AI analyses mood', tag: 'AI' },
    { path: '/stress-test', icon: BarChart, title: t('stressTest', lang), desc: lang==='hi'?'PSS-10 परीक्षण और सुझाव':'PSS-10 test with tips', tag: lang==='hi'?'मूल्यांकन':'Assessment' },
  ]},
  { label: t('hospitalsNav', lang), color: '#f5a623', features: [
    { path: '/hospitals', icon: MapPin, title: t('hospitals', lang), desc: lang==='hi'?'नज़दीकी अस्पताल और क्लीनिक':'Nearby hospitals & clinics', tag: 'Maps' },
    { path: '/appointment', icon: Calendar, title: t('appointment', lang), desc: lang==='hi'?'डॉक्टर खोजें और अपॉइंटमेंट लें':'Find doctors & book slots', tag: lang==='hi'?'बुकिंग':'Booking' },
    { path: '/ambulance', icon: Phone, title: t('emergency', lang), desc: lang==='hi'?'एम्बुलेंस और प्राथमिक चिकित्सा':'Quick ambulance & first aid', tag: lang==='hi'?'आपातकाल':'Emergency' },
  ]},
  { label: t('analyticsNav', lang), color: '#7c6af7', features: [
    { path: '/analytics', icon: BarChart3, title: t('analytics', lang), desc: lang==='hi'?'चार्ट और ट्रेंड विश्लेषण':'Charts & trend analysis', tag: lang==='hi'?'डेटा':'Insights' },
    { path: '/report', icon: FileText, title: t('healthReport', lang), desc: lang==='hi'?'डॉक्टर के लिए PDF रिपोर्ट':'Export PDF report for doctor', tag: lang==='hi'?'निर्यात':'Export' },
  ]},
];

export default function Dashboard() {
  const { user } = useAuth();
  const { lang } = useTheme();

  const moodAvg = user.moodHistory?.length ? Math.round((user.moodHistory.reduce((a,m)=>a+m.mood,0)/user.moodHistory.length)*10) : null;
  const healthScore = user.healthScore || 0;
  const mentalScore = moodAvg || user.mentalScore || 0;
  const consultations = user.consultations || 0;
  const joinDays = user.joinDate ? Math.floor((Date.now()-new Date(user.joinDate).getTime())/86400000) : 0;

  const cards = [
    { label:t('healthScore',lang), value:healthScore||'—', unit:healthScore?'/100':'', icon:Heart, color:'#5bd3c7', trend:healthScore?t('goodShape',lang):t('logDataToStart',lang) },
    { label:t('mentalWellness',lang), value:mentalScore||'—', unit:mentalScore?'/100':'', icon:Brain, color:'#f0628a', trend:mentalScore?t('stable',lang):t('trackFirstMood',lang) },
    { label:t('consultations',lang), value:consultations, unit:` ${consultations===1?t('session',lang):t('sessions',lang)}`, icon:Activity, color:'#7c6af7', trend:consultations===0?t('askFirstQuestion',lang):t('keepGoing',lang) },
    { label:t('memberSince',lang), value:joinDays, unit:` ${joinDays===1?t('day',lang):t('days',lang)}`, icon:Calendar, color:'#f5a623', trend:joinDays===0?t('welcome',lang):`${t('joinedOn',lang)} ${new Date(user.joinDate).toLocaleDateString(lang==='hi'?'hi-IN':'en-IN',{month:'short',day:'numeric'})}` },
  ];

  const tips = TIPS[lang] || TIPS.en;
  const tip = tips[new Date().getDate() % tips.length];
  const isNewUser = consultations===0 && !user.moodHistory?.length && !user.healthLogs?.length;
  const sections = FEATURE_SECTIONS(lang);

  return (
    <div style={{ padding:'clamp(20px,4vw,40px)', maxWidth:1200, margin:'0 auto' }}>
      <div style={{ marginBottom:32 }}>
        <p className="prose-label" style={{ marginBottom:6 }}>{t('welcomeBack',lang)}</p>
        <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.6rem,4vw,2.4rem)', fontWeight:700, letterSpacing:'-0.02em' }}>{user.name.split(' ')[0]} 👋</h1>
        <p style={{ color:'var(--text3)', marginTop:6 }}>{t('healthOverview',lang)}</p>
      </div>

      {isNewUser && (
        <div style={{ padding:'18px 22px', background:'linear-gradient(135deg,rgba(124,106,247,0.12),rgba(91,211,199,0.08))', border:'1px solid rgba(124,106,247,0.2)', borderRadius:16, marginBottom:28, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
          <div style={{ width:42,height:42,borderRadius:11,background:'rgba(124,106,247,0.2)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0 }}><Star size={20} color="var(--accent)" /></div>
          <div style={{ flex:1, minWidth:200 }}>
            <div style={{ fontFamily:'var(--font-display)', fontWeight:700, marginBottom:4 }}>{t('getStarted',lang)}</div>
            <p style={{ fontSize:'0.88rem', color:'var(--text3)', lineHeight:1.5 }}>{t('getStartedDesc',lang)}</p>
          </div>
          <Link to="/medical-ai" className="btn btn-primary" style={{ fontSize:'0.85rem', padding:'10px 18px' }}>{t('start',lang)} <ArrowRight size={14}/></Link>
        </div>
      )}

      <div style={{ padding:'14px 18px', background:'rgba(124,106,247,0.08)', border:'1px solid rgba(124,106,247,0.15)', borderRadius:12, marginBottom:32, display:'flex', alignItems:'flex-start', gap:12 }}>
        <TrendingUp size={16} color="var(--accent)" style={{ marginTop:2, flexShrink:0 }} />
        <div>
          <span style={{ fontSize:'0.72rem', fontFamily:'var(--font-mono)', color:'var(--accent)', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.08em' }}>{t('tipOfDay',lang)}</span>
          <p style={{ fontSize:'0.88rem', color:'var(--text2)', marginTop:3, lineHeight:1.5 }}>{tip}</p>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:14, marginBottom:40 }}>
        {cards.map((c,i)=>(
          <div key={i} className="card" style={{ borderColor:`${c.color}20` }}>
            <div style={{ marginBottom:12 }}><div style={{ width:38,height:38,borderRadius:9,background:`${c.color}18`,display:'flex',alignItems:'center',justifyContent:'center' }}><c.icon size={17} color={c.color} /></div></div>
            <div style={{ fontFamily:'var(--font-display)', fontSize:'1.9rem', fontWeight:800, lineHeight:1 }}>{c.value}<span style={{ fontSize:'0.88rem', color:'var(--text3)', fontWeight:400 }}>{c.unit}</span></div>
            <div style={{ color:'var(--text3)', fontSize:'0.78rem', marginTop:3 }}>{c.label}</div>
            <div style={{ color:c.color, fontSize:'0.73rem', marginTop:6, fontWeight:500 }}>{c.trend}</div>
          </div>
        ))}
      </div>

      {sections.map(section=>(
        <div key={section.label} style={{ marginBottom:36 }}>
          <h2 style={{ fontFamily:'var(--font-display)', fontSize:'1.1rem', fontWeight:700, marginBottom:16, display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:6,height:20,borderRadius:3,background:section.color }} />{section.label}
          </h2>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:12 }}>
            {section.features.map((f,i)=>(
              <Link key={i} to={f.path} style={{ textDecoration:'none' }}>
                <div className="card" style={{ borderColor:`${section.color}12`, cursor:'pointer', padding:18, transition:'transform 0.2s,box-shadow 0.2s,border-color 0.2s' }}
                  onMouseEnter={e=>{e.currentTarget.style.transform='translateY(-2px)';e.currentTarget.style.boxShadow=`0 8px 28px ${section.color}12`;e.currentTarget.style.borderColor=`${section.color}30`;}}
                  onMouseLeave={e=>{e.currentTarget.style.transform='';e.currentTarget.style.boxShadow='';e.currentTarget.style.borderColor=`${section.color}12`;}}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
                    <div style={{ width:38,height:38,borderRadius:9,background:`${section.color}18`,display:'flex',alignItems:'center',justifyContent:'center' }}><f.icon size={18} color={section.color} /></div>
                    <span className="tag" style={{ background:`${section.color}10`,color:section.color,border:`1px solid ${section.color}20`,fontSize:'0.65rem',padding:'2px 7px' }}>{f.tag}</span>
                  </div>
                  <h3 style={{ fontFamily:'var(--font-display)', fontWeight:700, fontSize:'0.92rem', marginBottom:4 }}>{f.title}</h3>
                  <p style={{ color:'var(--text3)', fontSize:'0.8rem', lineHeight:1.5 }}>{f.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
