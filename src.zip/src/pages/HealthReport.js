import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { FileDown, Activity, Brain, Pill, Target, Shield, TrendingUp } from 'lucide-react';

function generateHTML(user, data) {
  const date = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
  const moodAvg = user.moodHistory?.length ? (user.moodHistory.reduce((a,m)=>a+m.mood,0)/user.moodHistory.length).toFixed(1) : 'N/A';
  const medicines = JSON.parse(localStorage.getItem('mc_medicine_reminders')||'[]');
  const symptoms = user.symptoms || [];
  const vaccines = user.vaccinationRecords || [];

  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"/><title>MedConnect Health Report</title>
<style>
  body{font-family:'Segoe UI',sans-serif;max-width:800px;margin:40px auto;color:#1a1a2e;padding:0 20px;background:#fff}
  h1{color:#7c6af7;font-size:2rem;margin-bottom:4px}
  .subtitle{color:#666;margin-bottom:32px}
  .section{margin-bottom:32px;padding:24px;border-radius:12px;background:#f8f8ff;border:1px solid #e8e8f8}
  .section h2{color:#7c6af7;margin-top:0;font-size:1.1rem;border-bottom:1px solid #e0e0f5;padding-bottom:8px}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  .stat{background:white;padding:16px;border-radius:8px;border:1px solid #e8e8f8;text-align:center}
  .stat .val{font-size:2rem;font-weight:800;color:#7c6af7}
  .stat .lbl{font-size:0.78rem;color:#888;margin-top:4px}
  .pill{display:inline-block;padding:2px 10px;border-radius:100px;background:#ede9fe;color:#7c6af7;font-size:0.78rem;margin:2px}
  table{width:100%;border-collapse:collapse;font-size:0.88rem}
  td,th{padding:8px 12px;border-bottom:1px solid #eee;text-align:left}
  th{background:#f0eeff;color:#7c6af7;font-weight:600}
  .footer{text-align:center;padding:20px;color:#999;font-size:0.8rem;border-top:1px solid #eee;margin-top:40px}
  @media print{body{margin:0}.footer{position:fixed;bottom:0;width:100%}}
</style>
</head>
<body>
<div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
  <div style="width:40px;height:40px;border-radius:10px;background:#7c6af7;display:flex;align-items:center;justify-content:center;color:white;font-weight:bold">M</div>
  <h1 style="margin:0">MedConnect Health Report</h1>
</div>
<div class="subtitle">Generated for <strong>${user.name}</strong> · ${date}</div>

<div class="section">
  <h2>📊 Health Overview</h2>
  <div class="grid">
    <div class="stat"><div class="val">${user.healthScore||'—'}</div><div class="lbl">Health Score /100</div></div>
    <div class="stat"><div class="val">${moodAvg}</div><div class="lbl">Avg Mood /5</div></div>
    <div class="stat"><div class="val">${user.consultations||0}</div><div class="lbl">AI Consultations</div></div>
    <div class="stat"><div class="val">${symptoms.length}</div><div class="lbl">Symptoms Logged</div></div>
  </div>
</div>

<div class="section">
  <h2>💊 Active Medications</h2>
  ${medicines.length===0?'<p>No medications recorded.</p>':`<table><tr><th>Medicine</th><th>Dosage</th><th>Frequency</th><th>Time</th></tr>${medicines.map(m=>`<tr><td>${m.name}</td><td>${m.dose}</td><td>${m.freq}</td><td>${m.time}</td></tr>`).join('')}</table>`}
</div>

<div class="section">
  <h2>🩺 Recent Symptoms</h2>
  ${symptoms.length===0?'<p>No symptoms logged.</p>':symptoms.slice(0,10).map(s=>`<span class="pill">${s.name} (${['','Mild','Moderate','Severe'][s.severity]})</span>`).join('')}
</div>

<div class="section">
  <h2>💉 Vaccination Records</h2>
  ${vaccines.length===0?'<p>No vaccination records.</p>':`<table><tr><th>Vaccine</th><th>Date</th><th>Dose</th><th>Next Due</th></tr>${vaccines.map(v=>`<tr><td>${v.name}</td><td>${new Date(v.date).toLocaleDateString('en-IN')}</td><td>${v.dose}</td><td>${v.nextDue?new Date(v.nextDue).toLocaleDateString('en-IN'):'—'}</td></tr>`).join('')}</table>`}
</div>

${user.moodHistory?.length?`<div class="section">
  <h2>🧠 Mood History (Last 10)</h2>
  <div style="display:flex;gap:6px;flex-wrap:wrap">
    ${user.moodHistory.slice(0,10).map(m=>`<div style="text-align:center;padding:8px;background:white;border-radius:8px;border:1px solid #eee;min-width:60px"><div style="font-size:1.2rem">${['','😰','😔','😐','🙂','😄'][m.mood]}</div><div style="font-size:0.7rem;color:#888">${new Date(m.date).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}</div></div>`).join('')}
  </div>
</div>`:''}

<div class="footer">
  <p>⚠️ This report is for informational purposes only and does not constitute medical advice.</p>
  <p>Always consult a qualified healthcare professional for diagnosis and treatment.</p>
  <p>MedConnect · ${date}</p>
</div>
</body></html>`;
}

export default function HealthReport() {
  const { lang } = useTheme();
  const { user } = useAuth();
  const [generating, setGenerating] = useState(false);
  const [preview, setPreview] = useState(false);

  const download = () => {
    setGenerating(true);
    setTimeout(() => {
      const html = generateHTML(user, {});
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `MedConnect_Report_${user.name.replace(/\s/g,'_')}_${new Date().toISOString().split('T')[0]}.html`;
      a.click(); URL.revokeObjectURL(url);
      setGenerating(false);
    }, 800);
  };

  const medicines = JSON.parse(localStorage.getItem('mc_medicine_reminders')||'[]');
  const symptoms = user.symptoms || [];
  const vaccines = user.vaccinationRecords || [];
  const moodAvg = user.moodHistory?.length ? (user.moodHistory.reduce((a,m)=>a+m.mood,0)/user.moodHistory.length).toFixed(1) : null;

  return (
    <div style={{ padding:'clamp(20px,4vw,40px)',maxWidth:800,margin:'0 auto' }}>
      <div style={{ marginBottom:32 }}>
        <p className="prose-label" style={{ marginBottom:8 }}>Export</p>
        <h1 style={{ fontFamily:'var(--font-display)',fontSize:'clamp(1.6rem,4vw,2.2rem)',fontWeight:700,letterSpacing:'-0.02em',marginBottom:8 }}>{t('healthReportTitle',lang)}</h1>
        <p style={{ color:'var(--text3)' }}>{t('healthReportDesc',lang)}</p>
      </div>

      <div style={{ display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(140px,1fr))',gap:12,marginBottom:28 }}>
        {[
          { label:'Health Score', value: user.healthScore||'—', icon: Activity, color:'#5bd3c7' },
          { label:'Mood Average', value: moodAvg||'—', icon: Brain, color:'#f0628a' },
          { label:'Medicines', value: medicines.length, icon: Pill, color:'#7c6af7' },
          { label:'Symptoms', value: symptoms.length, icon: TrendingUp, color:'#f5a623' },
          { label:'Vaccines', value: vaccines.length, icon: Shield, color:'#5bd3c7' },
        ].map(s=>(
          <div key={s.label} className="card" style={{ padding:16,textAlign:'center' }}>
            <s.icon size={18} color={s.color} style={{ margin:'0 auto 8px' }} />
            <div style={{ fontFamily:'var(--font-display)',fontSize:'1.6rem',fontWeight:800,color:s.color }}>{s.value}</div>
            <div style={{ fontSize:'0.75rem',color:'var(--text3)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ marginBottom:24 }}>
        <h3 style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'0.95rem',marginBottom:14 }}>Report Contents</h3>
        {[
          ['📊 Health Overview', 'Health score, mood average, consultation count'],
          ['💊 Active Medications', `${medicines.length} medicine${medicines.length!==1?'s':''} with dosage and schedule`],
          ['🩺 Recent Symptoms', `${symptoms.length} symptom${symptoms.length!==1?'s':''} logged with severity`],
          ['💉 Vaccination Records', `${vaccines.length} vaccine record${vaccines.length!==1?'s':''}`],
          ['🧠 Mood History', `${user.moodHistory?.length||0} mood entries`],
        ].map(([title,desc])=>(
          <div key={title} style={{ display:'flex',gap:10,marginBottom:10,alignItems:'flex-start' }}>
            <div style={{ width:6,height:6,borderRadius:'50%',background:'var(--accent)',marginTop:6,flexShrink:0 }} />
            <div>
              <div style={{ fontWeight:600,fontSize:'0.88rem' }}>{title}</div>
              <div style={{ fontSize:'0.8rem',color:'var(--text3)' }}>{desc}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display:'flex',gap:12,flexWrap:'wrap' }}>
        <button onClick={download} disabled={generating} className="btn btn-primary" style={{ gap:8 }}>
          {generating?<><div className="spinner" style={{ width:16,height:16,borderWidth:2 }} /> Generating...</>:<><FileDown size={16}/> Download HTML Report</>}
        </button>
        <button onClick={()=>window.print()} className="btn btn-secondary" style={{ gap:8 }}>🖨️ Print</button>
      </div>

      <p style={{ marginTop:20,fontSize:'0.78rem',color:'var(--text3)' }}>
        The report downloads as an HTML file that opens in any browser. You can print it as a PDF from there using your browser's print function (Ctrl+P → Save as PDF).
      </p>

      <div style={{ marginTop:14,padding:'10px 14px',background:'rgba(240,98,138,0.06)',border:'1px solid rgba(240,98,138,0.15)',borderRadius:8,fontSize:'0.78rem',color:'var(--text3)' }}>
        ⚠️ This report is for informational purposes only. Data is pulled from your local device. Always consult a healthcare professional.
      </div>
    </div>
  );
}
