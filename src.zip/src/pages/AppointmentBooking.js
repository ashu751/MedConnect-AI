import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { Calendar, Clock, User, CheckCircle, MapPin, Stethoscope, ChevronRight, X } from 'lucide-react';

const SPECIALTIES = ['General Physician','Cardiologist','Dermatologist','Orthopedist','Neurologist','Pediatrician','Gynecologist','Ophthalmologist','ENT Specialist','Psychiatrist','Dentist','Physiotherapist'];

const DEMO_DOCTORS = {
  'General Physician': [
    { id: 1, name: 'Dr. Priya Sharma', exp: '12 years', rating: 4.8, slots: ['09:00','09:30','10:30','11:00','14:00','15:30'], fee: 500 },
    { id: 2, name: 'Dr. Rajesh Kumar', exp: '8 years', rating: 4.5, slots: ['10:00','11:30','14:30','16:00'], fee: 400 },
  ],
  'Cardiologist': [
    { id: 3, name: 'Dr. Anita Verma', exp: '18 years', rating: 4.9, slots: ['09:30','11:00','14:00'], fee: 1200 },
    { id: 4, name: 'Dr. Sanjay Mehta', exp: '22 years', rating: 4.7, slots: ['10:30','15:00','16:30'], fee: 1500 },
  ],
  'Dermatologist': [
    { id: 5, name: 'Dr. Neha Gupta', exp: '10 years', rating: 4.6, slots: ['09:00','10:00','11:30','14:00','15:00'], fee: 800 },
  ],
};

function getDoctors(specialty) {
  return DEMO_DOCTORS[specialty] || [
    { id: 99, name: `Dr. Specialist (${specialty})`, exp: '15 years', rating: 4.6, slots: ['10:00','11:00','14:00','15:30'], fee: 900 },
  ];
}

const DATES = Array.from({length:7},(_,i)=>{
  const d = new Date(); d.setDate(d.getDate()+i+1);
  return { date: d, label: d.toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short'}) };
});

export default function AppointmentBooking() {
  const { lang } = useTheme();
  const [step, setStep] = useState(1);
  const [specialty, setSpecialty] = useState('');
  const [doctor, setDoctor] = useState(null);
  const [dateIdx, setDateIdx] = useState(null);
  const [slot, setSlot] = useState('');
  const [patient, setPatient] = useState({ name: '', age: '', phone: '', reason: '' });
  const [booked, setBooked] = useState(null);
  const [appointments, setAppointments] = useState(() => JSON.parse(localStorage.getItem('mc_appointments')||'[]'));

  const confirm = () => {
    const appt = { id: Date.now(), specialty, doctor: doctor.name, date: DATES[dateIdx].label, slot, patient, fee: doctor.fee, status: 'Confirmed' };
    const updated = [appt, ...appointments];
    setAppointments(updated);
    localStorage.setItem('mc_appointments', JSON.stringify(updated));
    setBooked(appt);
  };

  const cancelAppt = (id) => {
    const updated = appointments.filter(a => a.id !== id);
    setAppointments(updated);
    localStorage.setItem('mc_appointments', JSON.stringify(updated));
  };

  const reset = () => { setStep(1); setSpecialty(''); setDoctor(null); setDateIdx(null); setSlot(''); setPatient({name:'',age:'',phone:'',reason:''}); setBooked(null); };

  if (booked) return (
    <div style={{ padding:'clamp(20px,4vw,40px)',maxWidth:600,margin:'0 auto',textAlign:'center' }}>
      <div className="card" style={{ borderColor:'rgba(91,211,199,0.3)',padding:40 }}>
        <CheckCircle size={48} color="#5bd3c7" style={{ margin:'0 auto 16px' }} />
        <h2 style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'1.4rem',marginBottom:8 }}>Appointment Confirmed!</h2>
        <p style={{ color:'var(--text3)',marginBottom:24 }}>Your appointment has been booked successfully.</p>
        <div style={{ background:'var(--surface2)',borderRadius:12,padding:20,textAlign:'left',marginBottom:24 }}>
          {[['Doctor',booked.doctor],['Specialty',booked.specialty],['Date',booked.date],['Time',booked.slot],['Patient',booked.patient.name],['Consultation Fee',`₹${booked.fee}`]].map(([k,v])=>(
            <div key={k} style={{ display:'flex',justifyContent:'space-between',padding:'6px 0',borderBottom:'1px solid var(--border)',fontSize:'0.88rem' }}>
              <span style={{ color:'var(--text3)' }}>{k}</span><span style={{ fontWeight:600 }}>{v}</span>
            </div>
          ))}
        </div>
        <p style={{ fontSize:'0.8rem',color:'var(--text3)',marginBottom:20 }}>⚠️ This is a demo booking. In a real app, you would receive an SMS/email confirmation.</p>
        <button onClick={reset} className="btn btn-primary" style={{ justifyContent:'center' }}>Book Another</button>
      </div>
    </div>
  );

  return (
    <div style={{ padding:'clamp(20px,4vw,40px)',maxWidth:900,margin:'0 auto' }}>
      <div style={{ marginBottom:32 }}>
        <p className="prose-label" style={{ marginBottom:8 }}>Healthcare Access</p>
        <h1 style={{ fontFamily:'var(--font-display)',fontSize:'clamp(1.6rem,4vw,2.2rem)',fontWeight:700,letterSpacing:'-0.02em',marginBottom:8 }}>{t('bookAppointment',lang)}</h1>
        <p style={{ color:'var(--text3)' }}>{t('bookAppointmentDesc',lang)}</p>
      </div>

      {/* Steps indicator */}
      <div style={{ display:'flex',alignItems:'center',gap:4,marginBottom:32 }}>
        {['Specialty','Doctor','Schedule','Details'].map((s,i)=>(
          <React.Fragment key={s}>
            <div style={{ display:'flex',alignItems:'center',gap:6 }}>
              <div style={{ width:28,height:28,borderRadius:'50%',background:step>i+1?'#5bd3c7':step===i+1?'var(--accent)':'var(--surface2)',color:step>=i+1?'white':'var(--text3)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'0.78rem',fontWeight:700 }}>{step>i+1?'✓':i+1}</div>
              <span style={{ fontSize:'0.78rem',color:step===i+1?'var(--text)':'var(--text3)',fontWeight:step===i+1?600:400 }}>{s}</span>
            </div>
            {i<3&&<div style={{ flex:1,height:1,background:'var(--border2)' }} />}
          </React.Fragment>
        ))}
      </div>

      {step===1 && (
        <div>
          <h3 style={{ fontFamily:'var(--font-display)',fontWeight:700,marginBottom:16 }}>Choose Specialty</h3>
          <div style={{ display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(180px,1fr))',gap:10 }}>
            {SPECIALTIES.map(s=>(
              <button key={s} onClick={()=>{setSpecialty(s);setStep(2);}} style={{ padding:'14px',borderRadius:12,border:`1px solid ${specialty===s?'var(--accent)':'var(--border2)'}`,background:specialty===s?'rgba(124,106,247,0.1)':'var(--surface)',color:'var(--text)',textAlign:'left',cursor:'pointer',fontSize:'0.88rem',transition:'all 0.15s' }}>
                <Stethoscope size={16} color="var(--accent)" style={{ marginBottom:6 }} />
                <div style={{ fontWeight:500 }}>{s}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {step===2 && (
        <div>
          <button onClick={()=>setStep(1)} className="btn btn-ghost" style={{ marginBottom:16,fontSize:'0.85rem' }}>← Back</button>
          <h3 style={{ fontFamily:'var(--font-display)',fontWeight:700,marginBottom:16 }}>Choose Doctor</h3>
          <div style={{ display:'flex',flexDirection:'column',gap:14 }}>
            {getDoctors(specialty).map(d=>(
              <div key={d.id} className="card" style={{ cursor:'pointer',borderColor:doctor?.id===d.id?'var(--accent)':'var(--border)',transition:'all 0.15s' }} onClick={()=>{setDoctor(d);setStep(3);}}>
                <div style={{ display:'flex',alignItems:'center',gap:14 }}>
                  <div style={{ width:52,height:52,borderRadius:'50%',background:'linear-gradient(135deg,var(--accent),var(--accent2))',display:'flex',alignItems:'center',justifyContent:'center',color:'white',fontFamily:'var(--font-display)',fontWeight:700,fontSize:'1.2rem',flexShrink:0 }}>
                    {d.name.split(' ')[1]?.[0]}
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:'var(--font-display)',fontWeight:700 }}>{d.name}</div>
                    <div style={{ fontSize:'0.82rem',color:'var(--text3)' }}>{specialty} · {d.exp} experience</div>
                    <div style={{ display:'flex',alignItems:'center',gap:12,marginTop:4 }}>
                      <span style={{ fontSize:'0.78rem',color:'#f5a623',fontWeight:600 }}>★ {d.rating}</span>
                      <span style={{ fontSize:'0.78rem',color:'var(--text3)' }}>{d.slots.length} slots available</span>
                    </div>
                  </div>
                  <div style={{ textAlign:'right',flexShrink:0 }}>
                    <div style={{ fontFamily:'var(--font-display)',fontWeight:700,color:'#5bd3c7' }}>₹{d.fee}</div>
                    <div style={{ fontSize:'0.72rem',color:'var(--text3)' }}>consultation</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {step===3 && doctor && (
        <div>
          <button onClick={()=>setStep(2)} className="btn btn-ghost" style={{ marginBottom:16,fontSize:'0.85rem' }}>← Back</button>
          <h3 style={{ fontFamily:'var(--font-display)',fontWeight:700,marginBottom:16 }}>Choose Date & Time</h3>
          <div style={{ display:'flex',gap:8,overflowX:'auto',marginBottom:20,paddingBottom:4 }}>
            {DATES.map((d,i)=>(
              <button key={i} onClick={()=>{setDateIdx(i);setSlot('');}} style={{ flexShrink:0,padding:'10px 16px',borderRadius:10,border:`1px solid ${dateIdx===i?'var(--accent)':'var(--border2)'}`,background:dateIdx===i?'rgba(124,106,247,0.12)':'var(--surface2)',color:dateIdx===i?'var(--accent)':'var(--text2)',cursor:'pointer',fontSize:'0.82rem',fontWeight:dateIdx===i?600:400,transition:'all 0.15s' }}>
                {d.label}
              </button>
            ))}
          </div>
          {dateIdx!==null && (
            <>
              <h4 style={{ fontSize:'0.88rem',color:'var(--text3)',marginBottom:12 }}>Available slots</h4>
              <div style={{ display:'flex',flexWrap:'wrap',gap:8,marginBottom:20 }}>
                {doctor.slots.map(s=>(
                  <button key={s} onClick={()=>setSlot(s)} style={{ padding:'8px 16px',borderRadius:8,border:`1px solid ${slot===s?'var(--accent)':'var(--border2)'}`,background:slot===s?'rgba(124,106,247,0.12)':'var(--surface2)',color:slot===s?'var(--accent)':'var(--text2)',cursor:'pointer',fontSize:'0.85rem',fontWeight:slot===s?600:400,transition:'all 0.15s' }}>
                    {s}
                  </button>
                ))}
              </div>
              {slot && <button onClick={()=>setStep(4)} className="btn btn-primary">Continue <ChevronRight size={15}/></button>}
            </>
          )}
        </div>
      )}

      {step===4 && (
        <div>
          <button onClick={()=>setStep(3)} className="btn btn-ghost" style={{ marginBottom:16,fontSize:'0.85rem' }}>← Back</button>
          <h3 style={{ fontFamily:'var(--font-display)',fontWeight:700,marginBottom:16 }}>Patient Details</h3>
          <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginBottom:14 }}>
            <div><label style={{ fontSize:'0.8rem',color:'var(--text3)',display:'block',marginBottom:6 }}>Full Name *</label><input value={patient.name} onChange={e=>setPatient(p=>({...p,name:e.target.value}))} placeholder="Patient name" /></div>
            <div><label style={{ fontSize:'0.8rem',color:'var(--text3)',display:'block',marginBottom:6 }}>Age *</label><input type="number" value={patient.age} onChange={e=>setPatient(p=>({...p,age:e.target.value}))} placeholder="Age" /></div>
            <div><label style={{ fontSize:'0.8rem',color:'var(--text3)',display:'block',marginBottom:6 }}>Phone *</label><input value={patient.phone} onChange={e=>setPatient(p=>({...p,phone:e.target.value}))} placeholder="+91 98765 43210" /></div>
          </div>
          <div style={{ marginBottom:20 }}><label style={{ fontSize:'0.8rem',color:'var(--text3)',display:'block',marginBottom:6 }}>Reason for visit</label><textarea value={patient.reason} onChange={e=>setPatient(p=>({...p,reason:e.target.value}))} placeholder="Brief description of symptoms or reason..." rows={3} /></div>
          {/* Summary */}
          <div className="card" style={{ marginBottom:20,background:'var(--surface2)' }}>
            <h4 style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'0.88rem',marginBottom:12 }}>Booking Summary</h4>
            {[['Doctor',doctor.name],['Date',DATES[dateIdx].label],['Time',slot],['Fee',`₹${doctor.fee}`]].map(([k,v])=>(
              <div key={k} style={{ display:'flex',justifyContent:'space-between',fontSize:'0.85rem',padding:'5px 0' }}>
                <span style={{ color:'var(--text3)' }}>{k}</span><span style={{ fontWeight:600 }}>{v}</span>
              </div>
            ))}
          </div>
          <button onClick={confirm} disabled={!patient.name||!patient.age||!patient.phone} className="btn btn-primary" style={{ width:'100%',justifyContent:'center',opacity:(!patient.name||!patient.age||!patient.phone)?0.5:1 }}>
            <CheckCircle size={16}/> Confirm Appointment
          </button>
        </div>
      )}

      {/* Upcoming appointments */}
      {appointments.length > 0 && !booked && (
        <div style={{ marginTop:40 }}>
          <h3 style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'1rem',marginBottom:16 }}>Your Appointments</h3>
          <div style={{ display:'flex',flexDirection:'column',gap:10 }}>
            {appointments.map(a=>(
              <div key={a.id} className="card" style={{ padding:'14px 16px',display:'flex',justifyContent:'space-between',alignItems:'center' }}>
                <div>
                  <div style={{ fontWeight:600,fontSize:'0.9rem',marginBottom:2 }}>{a.doctor} — {a.specialty}</div>
                  <div style={{ fontSize:'0.78rem',color:'var(--text3)' }}>{a.date} at {a.slot} · {a.patient.name}</div>
                </div>
                <div style={{ display:'flex',alignItems:'center',gap:10 }}>
                  <span style={{ fontSize:'0.72rem',padding:'3px 10px',borderRadius:100,background:'rgba(91,211,199,0.15)',color:'#5bd3c7',fontWeight:600 }}>Confirmed</span>
                  <button onClick={()=>cancelAppt(a.id)} style={{ background:'none',border:'none',color:'var(--text3)',cursor:'pointer',padding:4 }}><X size={14}/></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
