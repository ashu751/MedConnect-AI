import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { MapPin, Phone, Clock, Star, Navigation, Search, AlertCircle, Loader, ExternalLink } from 'lucide-react';

const GOOGLE_MAPS_API_KEY = process.env.REACT_APP_GOOGLE_MAPS_API_KEY || '';

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
    const script = document.createElement('script');
    script.src = src; script.async = true;
    script.onload = resolve; script.onerror = reject;
    document.head.appendChild(script);
  });
}

// Demo hospitals for when no API key is set
function getDemoHospitals(lat, lng) {
  return [
    { place_id: '1', name: 'City General Hospital', vicinity: '15 Health Street, Central District', rating: 4.3, user_ratings_total: 1420, geometry: { location: { lat: lat + 0.005, lng: lng + 0.003 } }, types: ['hospital'], opening_hours: { open_now: true }, phone: '+91 11 2345 6789', distance: '0.6 km' },
    { place_id: '2', name: 'Apollo Medical Center', vicinity: '42 Wellness Avenue, East Side', rating: 4.6, user_ratings_total: 2310, geometry: { location: { lat: lat - 0.008, lng: lng + 0.007 } }, types: ['hospital'], opening_hours: { open_now: true }, phone: '+91 11 9876 5432', distance: '1.2 km' },
    { place_id: '3', name: 'Sunrise Clinic & Diagnostics', vicinity: '8 Care Lane, West Block', rating: 4.1, user_ratings_total: 680, geometry: { location: { lat: lat + 0.012, lng: lng - 0.005 } }, types: ['doctor'], opening_hours: { open_now: false }, phone: '+91 11 5544 3322', distance: '1.8 km' },
    { place_id: '4', name: 'National Healthcare Institute', vicinity: '200 Medical Road, North Campus', rating: 4.7, user_ratings_total: 3100, geometry: { location: { lat: lat - 0.015, lng: lng - 0.009 } }, types: ['hospital'], opening_hours: { open_now: true }, phone: '+91 11 7788 9900', distance: '2.1 km' },
    { place_id: '5', name: 'Urgent Care Express', vicinity: '5 Quick Street, Market Area', rating: 3.9, user_ratings_total: 450, geometry: { location: { lat: lat + 0.018, lng: lng + 0.012 } }, types: ['health'], opening_hours: { open_now: true }, phone: '+91 11 1122 3344', distance: '2.6 km' },
    { place_id: '6', name: 'Medanta Super Speciality', vicinity: '77 Sector 12, Highway Zone', rating: 4.8, user_ratings_total: 4200, geometry: { location: { lat: lat - 0.022, lng: lng + 0.016 } }, types: ['hospital'], opening_hours: { open_now: true }, phone: '+91 11 6677 8899', distance: '3.2 km' },
  ];
}

export default function HospitalFinder() {
  const { lang } = useTheme();
  const [location, setLocation] = useState(null);
  const [hospitals, setHospitals] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [specialty, setSpecialty] = useState('All');
  const SPECIALTIES = ['All','General','Cardiology','Dermatology','Orthopedics','Neurology','Pediatrics','Dentist','Eye Care','ENT'];
  const SPECIALTY_KEYWORDS = { Cardiology:['cardiac','heart','cardio'], Dermatology:['skin','derm'], Orthopedics:['ortho','bone','joint'], Neurology:['neuro','brain'], Pediatrics:['child','paediat','pediatric'], Dentist:['dental','dentist','teeth'], 'Eye Care':['eye','ophthal','vision'], ENT:['ent','ear','nose','throat'] };
  const [demoMode, setDemoMode] = useState(!GOOGLE_MAPS_API_KEY);
  const [mapLoaded, setMapLoaded] = useState(false);
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);

  const getLocation = () => {
    setLoading(true); setError('');
    navigator.geolocation.getCurrentPosition(
      pos => {
        const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setLocation(coords);
        if (demoMode) {
          setHospitals(getDemoHospitals(coords.lat, coords.lng));
          setLoading(false);
        } else {
          loadNearbyHospitals(coords);
        }
      },
      err => {
        setError('Location access denied. Using demo data for Gurugram, India.');
        const coords = { lat: 28.4595, lng: 77.0266 }; // Gurugram
        setLocation(coords);
        setHospitals(getDemoHospitals(coords.lat, coords.lng));
        setLoading(false);
        setDemoMode(true);
      }
    );
  };

  const loadNearbyHospitals = useCallback(async (coords) => {
    try {
      await loadScript(`https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`);
      const map = new window.google.maps.Map(mapRef.current, { center: coords, zoom: 14, styles: darkMapStyle });
      mapInstanceRef.current = map;

      const service = new window.google.maps.places.PlacesService(map);
      service.nearbySearch({ location: coords, radius: 5000, type: 'hospital' }, (results, status) => {
        setLoading(false);
        if (status === window.google.maps.places.PlacesServiceStatus.OK && results) {
          const withDist = results.map(r => {
            const dlat = r.geometry.location.lat() - coords.lat;
            const dlng = r.geometry.location.lng() - coords.lng;
            const km = Math.sqrt(dlat * dlat + dlng * dlng) * 111;
            return { ...r, distance: `${km.toFixed(1)} km`, geometry: { location: { lat: r.geometry.location.lat(), lng: r.geometry.location.lng() } } };
          }).sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance));
          setHospitals(withDist);
          setMapLoaded(true);
          addMarkers(map, withDist, coords);
        } else {
          setHospitals(getDemoHospitals(coords.lat, coords.lng));
          setDemoMode(true);
        }
      });
    } catch (e) {
      setLoading(false);
      setHospitals(getDemoHospitals(coords.lat, coords.lng));
      setDemoMode(true);
    }
  }, []);

  const addMarkers = (map, hospitals, userCoords) => {
    markersRef.current.forEach(m => m.setMap(null));
    markersRef.current = [];
    // User marker
    new window.google.maps.Marker({ position: userCoords, map, icon: { path: window.google.maps.SymbolPath.CIRCLE, scale: 10, fillColor: '#7c6af7', fillOpacity: 1, strokeColor: 'white', strokeWeight: 2 }, title: 'Your Location' });
    hospitals.forEach((h, i) => {
      const m = new window.google.maps.Marker({
        position: { lat: h.geometry.location.lat, lng: h.geometry.location.lng },
        map, title: h.name,
        label: { text: String(i + 1), color: 'white', fontSize: '12px', fontWeight: 'bold' },
        icon: { path: window.google.maps.SymbolPath.BACKWARD_CLOSED_ARROW, scale: 8, fillColor: '#f5a623', fillOpacity: 1, strokeColor: 'white', strokeWeight: 1 }
      });
      markersRef.current.push(m);
    });
  };

  const filtered = hospitals.filter(h => { const matchSearch = h.name.toLowerCase().includes(searchQuery.toLowerCase()) || (h.vicinity||"").toLowerCase().includes(searchQuery.toLowerCase()); if (!matchSearch) return false; if (specialty === "All" || specialty === "General") return true; const keywords = SPECIALTY_KEYWORDS[specialty] || [specialty.toLowerCase()]; return keywords.some(k => h.name.toLowerCase().includes(k) || (h.vicinity||"").toLowerCase().includes(k)); });

  const openInMaps = (h) => {
    const lat = h.geometry.location.lat; const lng = h.geometry.location.lng;
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&destination_place_id=${h.place_id}`, '_blank');
  };

  const callHospital = (h) => { if (h.phone) window.open(`tel:${h.phone}`); };

  return (
    <div style={{ padding: '32px', maxWidth: 1000, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
          <div style={{ width: 42, height: 42, borderRadius: 11, background: 'rgba(245,166,35,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <MapPin size={20} color="#f5a623" />
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 700 }}>Hospital Finder</h1>
        </div>
        <p style={{ color: 'var(--text3)', fontSize: '0.9rem' }}>Find hospitals and clinics near your current location</p>
      </div>

      {/* API notice */}
      {demoMode && (
        <div style={{ padding: '12px 16px', background: 'rgba(245,166,35,0.08)', border: '1px solid rgba(245,166,35,0.2)', borderRadius: 10, marginBottom: 20, display: 'flex', gap: 10 }}>
          <AlertCircle size={16} color="#f5a623" style={{ flexShrink: 0, marginTop: 2 }} />
          <p style={{ fontSize: '0.82rem', color: 'var(--text2)', lineHeight: 1.5 }}>
            <strong>Demo mode</strong> — Set <code style={{ background: 'var(--surface2)', padding: '1px 5px', borderRadius: 4, fontFamily: 'var(--font-mono)' }}>REACT_APP_GOOGLE_MAPS_API_KEY</code> in .env for real hospital data. The map and directions still work with real hospital links.
          </p>
        </div>
      )}

      {!location ? (
        <div style={{ textAlign: 'center', padding: '80px 40px' }}>
          <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'rgba(245,166,35,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px' }}>
            <Navigation size={36} color="#f5a623" />
          </div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 700, marginBottom: 12 }}>Find hospitals near you</h2>
          <p style={{ color: 'var(--text3)', marginBottom: 32, maxWidth: 360, margin: '0 auto 32px', lineHeight: 1.6 }}>
            Allow location access to discover nearby hospitals, clinics, and emergency care centers.
          </p>
          <button onClick={getLocation} className="btn btn-primary" style={{ padding: '14px 32px', fontSize: '1rem' }} disabled={loading}>
            {loading ? <><Loader size={18} style={{ animation: 'spin 0.8s linear infinite' }} /> Locating...</> : <><Navigation size={18} /> Use My Location</>}
          </button>
          {error && <p style={{ color: 'var(--accent3)', marginTop: 16, fontSize: '0.85rem' }}>{error}</p>}
        </div>
      ) : (
        <div>
          {/* Search & Re-locate */}
          <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <Search size={16} color="var(--text3)" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }} />
              <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search hospitals by name..." style={{ paddingLeft: 42 }} />
              <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginTop:10 }}>
                {SPECIALTIES.map(s => <button key={s} onClick={()=>setSpecialty(s)} style={{ padding:"5px 12px", borderRadius:100, border:`1px solid ${specialty===s?"var(--accent)":"var(--border2)"}`, background:specialty===s?"rgba(124,106,247,0.15)":"var(--surface2)", color:specialty===s?"var(--accent)":"var(--text3)", fontSize:"0.78rem", cursor:"pointer", fontWeight:specialty===s?600:400, transition:"all 0.15s" }}>{s}</button>)}
              </div>
            </div>
            <button onClick={getLocation} className="btn btn-secondary" style={{ flexShrink: 0 }}>
              <Navigation size={16} /> Refresh
            </button>
          </div>

          {/* Map */}
          {mapLoaded && (
            <div ref={mapRef} style={{ height: 280, borderRadius: 16, marginBottom: 24, overflow: 'hidden', border: '1px solid var(--border)' }} />
          )}
          {!mapLoaded && location && (
            <div style={{ height: 200, borderRadius: 16, marginBottom: 24, background: 'var(--surface)', border: '1px solid var(--border)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
              <MapPin size={32} color="#f5a623" />
              <p style={{ color: 'var(--text3)', fontSize: '0.85rem' }}>Map view available with Google Maps API key</p>
              <a href={`https://www.google.com/maps/search/hospitals/@${location.lat},${location.lng},14z`} target="_blank" rel="noreferrer" className="btn btn-secondary" style={{ fontSize: '0.82rem' }}>
                <ExternalLink size={14} /> Open in Google Maps
              </a>
            </div>
          )}

          {/* Hospitals list */}
          <div>
            <p style={{ fontSize: '0.8rem', color: 'var(--text3)', marginBottom: 16, fontFamily: 'var(--font-mono)' }}>
              {filtered.length} {filtered.length === 1 ? 'facility' : 'facilities'} found nearby
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {filtered.map((h, i) => (
                <div key={h.place_id} className="card" style={{ cursor: 'pointer', borderColor: selected?.place_id === h.place_id ? 'rgba(245,166,35,0.4)' : 'var(--border)', background: selected?.place_id === h.place_id ? 'rgba(245,166,35,0.05)' : 'var(--surface)' }}
                  onClick={() => setSelected(selected?.place_id === h.place_id ? null : h)}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16 }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: 'rgba(245,166,35,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontFamily: 'var(--font-display)', fontWeight: 700, color: '#f5a623', fontSize: '0.9rem' }}>
                      {i + 1}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 4 }}>
                        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem' }}>{h.name}</h3>
                        {h.opening_hours?.open_now !== undefined && (
                          <span style={{ fontSize: '0.7rem', fontWeight: 600, padding: '2px 7px', borderRadius: 100, background: h.opening_hours.open_now ? 'rgba(91,211,199,0.15)' : 'rgba(240,98,138,0.15)', color: h.opening_hours.open_now ? '#5bd3c7' : '#f0628a' }}>
                            {h.opening_hours.open_now ? '● Open' : '● Closed'}
                          </span>
                        )}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: 'var(--text3)', fontSize: '0.82rem', marginBottom: 8 }}>
                        <MapPin size={12} /> {h.vicinity}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
                        {h.rating && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: '0.8rem' }}>
                            <Star size={12} color="#f5a623" fill="#f5a623" />
                            <span style={{ color: '#f5a623', fontWeight: 600 }}>{h.rating}</span>
                            <span style={{ color: 'var(--text3)' }}>({h.user_ratings_total?.toLocaleString()})</span>
                          </div>
                        )}
                        <div style={{ fontSize: '0.8rem', color: 'var(--accent2)', fontWeight: 600 }}>{h.distance}</div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flexShrink: 0 }}>
                      <button onClick={e => { e.stopPropagation(); openInMaps(h); }} className="btn btn-secondary" style={{ padding: '8px 14px', fontSize: '0.8rem', gap: 5 }}>
                        <Navigation size={13} /> Directions
                      </button>
                      {h.phone && (
                        <button onClick={e => { e.stopPropagation(); callHospital(h); }} className="btn btn-ghost" style={{ padding: '8px 14px', fontSize: '0.8rem', gap: 5, color: '#5bd3c7' }}>
                          <Phone size={13} /> Call
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#0e0e1f' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0e0e1f' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#1a1a30' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#212133' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#080812' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#0d1117' }] },
];
