import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { BarChart3, TrendingUp, Activity, Heart, Brain, Calendar, Plus } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, AreaChart, Area } from 'recharts';

function generateHealthData() {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return days.map((day, i) => ({
    day,
    healthScore: 65 + Math.floor(Math.random() * 25),
    sleep: 5.5 + Math.random() * 3,
    steps: 3000 + Math.floor(Math.random() * 7000),
    water: 4 + Math.floor(Math.random() * 5),
    stress: Math.floor(Math.random() * 7) + 2,
  }));
}

function generateMonthData() {
  return Array.from({ length: 30 }, (_, i) => ({
    day: i + 1,
    score: 60 + Math.floor(Math.sin(i / 5) * 15 + Math.random() * 10),
    mood: 2 + Math.floor(Math.sin(i / 4) * 1.5 + Math.random() * 1),
  }));
}

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div style={{ background: 'var(--surface2)', border: '1px solid var(--border2)', borderRadius: 10, padding: '10px 14px', fontSize: '0.82rem' }}>
        <p style={{ color: 'var(--text3)', marginBottom: 4, fontFamily: 'var(--font-mono)' }}>{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color, fontWeight: 600 }}>{p.name}: {typeof p.value === 'number' ? p.value.toFixed(1) : p.value}</p>
        ))}
      </div>
    );
  }
  return null;
};

export default function HealthAnalytics() {
  const { lang } = useTheme();
  const { user, updateUser } = useAuth();
  const [weekData] = useState(generateHealthData);
  const [monthData] = useState(generateMonthData);
  const [logForm, setLogForm] = useState({ weight: '', bloodPressure: '', heartRate: '', notes: '' });
  const [logSaved, setLogSaved] = useState(false);

  const logs = user?.healthLogs || [];

  const radarData = [
    { metric: 'Sleep', value: 72 },
    { metric: 'Nutrition', value: 58 },
    { metric: 'Exercise', value: 64 },
    { metric: 'Hydration', value: 81 },
    { metric: 'Mental', value: user.mentalScore || 70 },
    { metric: 'Stress', value: 55 },
  ];

  const saveLog = () => {
    if (!logForm.weight && !logForm.heartRate && !logForm.notes) return;
    const newLog = { ...logForm, date: new Date().toISOString() };
    updateUser({ healthLogs: [...logs, newLog].slice(-20) });
    setLogForm({ weight: '', bloodPressure: '', heartRate: '', notes: '' });
    setLogSaved(true);
    setTimeout(() => setLogSaved(false), 2000);
  };

  const statCards = [
    { label: 'Avg Health Score', value: Math.round(weekData.reduce((s, d) => s + d.healthScore, 0) / weekData.length), unit: '/100', color: '#5bd3c7', icon: Heart },
    { label: 'Avg Sleep', value: (weekData.reduce((s, d) => s + d.sleep, 0) / weekData.length).toFixed(1), unit: 'hrs', color: '#7c6af7', icon: Activity },
    { label: 'Avg Steps', value: Math.round(weekData.reduce((s, d) => s + d.steps, 0) / weekData.length).toLocaleString(), unit: '/day', color: '#f5a623', icon: TrendingUp },
    { label: 'Wellness Score', value: user.healthScore, unit: '/100', color: '#f0628a', icon: Brain },
  ];

  return (
    <div style={{ padding: '32px', maxWidth: 1100, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
          <div style={{ width: 42, height: 42, borderRadius: 11, background: 'rgba(124,106,247,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <BarChart3 size={20} color="#7c6af7" />
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 700 }}>Health Analytics</h1>
        </div>
        <p style={{ color: 'var(--text3)', fontSize: '0.9rem' }}>Visualize your health trends and track progress over time</p>
      </div>

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14, marginBottom: 32 }}>
        {statCards.map((c, i) => (
          <div key={i} className="card" style={{ borderColor: `${c.color}20` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <c.icon size={16} color={c.color} />
              <span style={{ fontSize: '0.7rem', color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>7-day avg</span>
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 800, lineHeight: 1 }}>
              {c.value}<span style={{ fontSize: '0.9rem', color: 'var(--text3)', fontWeight: 400 }}>{c.unit}</span>
            </div>
            <div style={{ color: 'var(--text3)', fontSize: '0.78rem', marginTop: 4 }}>{c.label}</div>
          </div>
        ))}
      </div>

      {/* Charts grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
        {/* Health score trend */}
        <div className="card">
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 20 }}>Health Score — This Week</h3>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={weekData}>
              <defs>
                <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#5bd3c7" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#5bd3c7" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="day" tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} domain={[50, 100]} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="healthScore" name="Score" stroke="#5bd3c7" strokeWidth={2.5} fill="url(#scoreGrad)" dot={{ fill: '#5bd3c7', strokeWidth: 0, r: 4 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Sleep chart */}
        <div className="card">
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 20 }}>Sleep Hours — This Week</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={weekData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="day" tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} domain={[0, 10]} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="sleep" name="Hours" fill="#7c6af7" radius={[5, 5, 0, 0]} fillOpacity={0.85} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
        {/* Monthly trend */}
        <div className="card">
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 20 }}>30-Day Health Trend</h3>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={monthData}>
              <defs>
                <linearGradient id="grad2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#7c6af7" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#7c6af7" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="day" tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} interval={6} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} domain={[50, 90]} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="score" name="Score" stroke="#7c6af7" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Wellness radar */}
        <div className="card">
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 8 }}>Wellness Overview</h3>
          <ResponsiveContainer width="100%" height={200}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="rgba(255,255,255,0.06)" />
              <PolarAngleAxis dataKey="metric" tick={{ fill: 'var(--text3)', fontSize: 11 }} />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
              <Radar name="Wellness" dataKey="value" stroke="#f0628a" fill="#f0628a" fillOpacity={0.15} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Log health data */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
          <Plus size={18} color="var(--accent)" />
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem' }}>Log Health Data</h3>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12, marginBottom: 12 }}>
          <div>
            <label style={{ display: 'block', marginBottom: 6, fontSize: '0.8rem', color: 'var(--text3)', fontWeight: 500 }}>Weight (kg)</label>
            <input value={logForm.weight} onChange={e => setLogForm({...logForm, weight: e.target.value})} placeholder="70.5" type="number" />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: 6, fontSize: '0.8rem', color: 'var(--text3)', fontWeight: 500 }}>Blood Pressure</label>
            <input value={logForm.bloodPressure} onChange={e => setLogForm({...logForm, bloodPressure: e.target.value})} placeholder="120/80" />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: 6, fontSize: '0.8rem', color: 'var(--text3)', fontWeight: 500 }}>Heart Rate (bpm)</label>
            <input value={logForm.heartRate} onChange={e => setLogForm({...logForm, heartRate: e.target.value})} placeholder="72" type="number" />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: 6, fontSize: '0.8rem', color: 'var(--text3)', fontWeight: 500 }}>Notes</label>
            <input value={logForm.notes} onChange={e => setLogForm({...logForm, notes: e.target.value})} placeholder="How are you feeling?" />
          </div>
        </div>
        <button onClick={saveLog} className="btn btn-primary" style={{ fontSize: '0.88rem' }}>
          {logSaved ? '✓ Logged!' : <><Plus size={16} /> Add Entry</>}
        </button>
      </div>

      {/* Log history */}
      {logs.length > 0 && (
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <Calendar size={16} color="var(--text3)" />
            <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem' }}>Recent Logs</h3>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {logs.slice(-5).reverse().map((log, i) => (
              <div key={i} style={{ display: 'flex', gap: 16, padding: '10px 14px', background: 'var(--surface2)', borderRadius: 10, flexWrap: 'wrap', alignItems: 'center', fontSize: '0.82rem' }}>
                <span style={{ color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>{new Date(log.date).toLocaleDateString('en', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                {log.weight && <span><span style={{ color: 'var(--text3)' }}>Weight:</span> <strong>{log.weight} kg</strong></span>}
                {log.bloodPressure && <span><span style={{ color: 'var(--text3)' }}>BP:</span> <strong>{log.bloodPressure}</strong></span>}
                {log.heartRate && <span><span style={{ color: 'var(--text3)' }}>HR:</span> <strong>{log.heartRate} bpm</strong></span>}
                {log.notes && <span style={{ color: 'var(--text2)' }}>{log.notes}</span>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
