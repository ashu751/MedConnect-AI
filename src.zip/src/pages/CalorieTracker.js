import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Droplets, Apple, Flame } from 'lucide-react';

const FOOD_DB = [
  { name: 'Rice (1 cup cooked)', cal: 206, protein: 4, carbs: 45, fat: 0 },
  { name: 'Roti (1 piece)', cal: 71, protein: 3, carbs: 15, fat: 1 },
  { name: 'Dal (1 cup)', cal: 230, protein: 18, carbs: 40, fat: 1 },
  { name: 'Paneer (100g)', cal: 265, protein: 18, carbs: 1, fat: 20 },
  { name: 'Chicken Breast (100g)', cal: 165, protein: 31, carbs: 0, fat: 4 },
  { name: 'Egg (1 whole)', cal: 78, protein: 6, carbs: 1, fat: 5 },
  { name: 'Milk (1 cup)', cal: 149, protein: 8, carbs: 12, fat: 8 },
  { name: 'Banana (1 medium)', cal: 89, protein: 1, carbs: 23, fat: 0 },
  { name: 'Apple (1 medium)', cal: 95, protein: 0, carbs: 25, fat: 0 },
  { name: 'Curd / Yogurt (1 cup)', cal: 150, protein: 8, carbs: 17, fat: 4 },
  { name: 'Almonds (10 pieces)', cal: 70, protein: 3, carbs: 2, fat: 6 },
  { name: 'Samosa (1 piece)', cal: 262, protein: 4, carbs: 28, fat: 14 },
  { name: 'Idli (1 piece)', cal: 39, protein: 2, carbs: 8, fat: 0 },
  { name: 'Dosa (1 piece)', cal: 133, protein: 4, carbs: 22, fat: 4 },
  { name: 'Tea/Coffee with milk', cal: 45, protein: 1, carbs: 6, fat: 2 },
];

const MEALS = ['Breakfast', 'Lunch', 'Dinner', 'Snack'];
const TODAY = new Date().toDateString();

export default function CalorieTracker() {
  const { lang } = useTheme();
  const [entries, setEntries] = useState(() => JSON.parse(localStorage.getItem('mc_calories_' + TODAY) || '[]'));
  const [water, setWater] = useState(() => parseInt(localStorage.getItem('mc_water_' + TODAY) || '0'));
  const [search, setSearch] = useState('');
  const [meal, setMeal] = useState('Breakfast');
  const [custom, setCustom] = useState({ name: '', cal: '', protein: '', carbs: '', fat: '' });
  const [goal, setGoal] = useState(() => parseInt(localStorage.getItem('mc_cal_goal') || '2000'));

  useEffect(() => { localStorage.setItem('mc_calories_' + TODAY, JSON.stringify(entries)); }, [entries]);
  useEffect(() => { localStorage.setItem('mc_water_' + TODAY, water.toString()); }, [water]);
  useEffect(() => { localStorage.setItem('mc_cal_goal', goal.toString()); }, [goal]);

  const filtered = FOOD_DB.filter(f => f.name.toLowerCase().includes(search.toLowerCase()));
  const addFood = (food) => {
    setEntries(prev => [...prev, { ...food, meal, id: Date.now() }]);
    setSearch('');
  };
  const addCustom = () => {
    if (!custom.name || !custom.cal) return;
    addFood({ name: custom.name, cal: parseInt(custom.cal), protein: parseInt(custom.protein)||0, carbs: parseInt(custom.carbs)||0, fat: parseInt(custom.fat)||0 });
    setCustom({ name: '', cal: '', protein: '', carbs: '', fat: '' });
  };
  const remove = (id) => setEntries(prev => prev.filter(e => e.id !== id));

  const totals = entries.reduce((a, e) => ({ cal: a.cal + e.cal, protein: a.protein + (e.protein||0), carbs: a.carbs + (e.carbs||0), fat: a.fat + (e.fat||0) }), { cal: 0, protein: 0, carbs: 0, fat: 0 });
  const calPct = Math.min((totals.cal / goal) * 100, 100);

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Nutrition</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('calorieTrackerTitle',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('calorieTrackerDesc',lang)}</p>
      </div>

      {/* Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: 12, marginBottom: 28 }}>
        {[
          { label: 'Calories', value: totals.cal, unit: `/ ${goal}`, color: calPct > 100 ? '#f0628a' : '#5bd3c7' },
          { label: 'Protein', value: totals.protein, unit: 'g', color: '#7c6af7' },
          { label: 'Carbs', value: totals.carbs, unit: 'g', color: '#f5a623' },
          { label: 'Fat', value: totals.fat, unit: 'g', color: '#f0628a' },
          { label: 'Water', value: water, unit: '/ 8 glasses', color: '#5bd3c7' },
        ].map(s => (
          <div key={s.label} className="card" style={{ padding: 16, textAlign: 'center' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>{s.label}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 800, color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text3)' }}>{s.unit}</div>
          </div>
        ))}
      </div>

      {/* Calorie bar */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: '0.82rem', color: 'var(--text3)' }}>
          <span>Daily calorie goal</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ color: calPct > 100 ? 'var(--accent3)' : 'var(--text)' }}>{totals.cal} / </span>
            <input type="number" value={goal} onChange={e => setGoal(parseInt(e.target.value)||2000)} style={{ width: 70, padding: '2px 6px', fontSize: '0.82rem' }} />
            <span>kcal</span>
          </div>
        </div>
        <div style={{ height: 8, background: 'var(--surface2)', borderRadius: 4, overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${calPct}%`, background: calPct > 100 ? 'var(--accent3)' : '#5bd3c7', borderRadius: 4, transition: 'width 0.3s' }} />
        </div>
        {calPct > 100 && <p style={{ fontSize: '0.78rem', color: 'var(--accent3)', marginTop: 6 }}>⚠️ Over goal by {totals.cal - goal} kcal</p>}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* Log food */}
        <div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 14 }}>Log Food</h3>
          <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
            {MEALS.map(m => (
              <button key={m} onClick={() => setMeal(m)} style={{ flex: 1, padding: '6px', borderRadius: 8, border: `1px solid ${meal===m?'var(--accent)':'var(--border2)'}`, background: meal===m?'rgba(124,106,247,0.12)':'var(--surface2)', color: meal===m?'var(--accent)':'var(--text3)', cursor: 'pointer', fontSize: '0.75rem', fontWeight: meal===m?600:400 }}>{m}</button>
            ))}
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search Indian foods..." style={{ marginBottom: 8 }} />
          {search && (
            <div style={{ maxHeight: 200, overflowY: 'auto', border: '1px solid var(--border2)', borderRadius: 8, marginBottom: 10 }}>
              {filtered.slice(0,8).map(f => (
                <div key={f.name} onClick={() => addFood(f)} style={{ padding: '10px 14px', cursor: 'pointer', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}
                  onMouseEnter={e => e.currentTarget.style.background='var(--surface2)'}
                  onMouseLeave={e => e.currentTarget.style.background='transparent'}>
                  <span>{f.name}</span>
                  <span style={{ color: '#5bd3c7', fontWeight: 600 }}>{f.cal} kcal</span>
                </div>
              ))}
              {filtered.length === 0 && <div style={{ padding: '10px 14px', color: 'var(--text3)', fontSize: '0.85rem' }}>No match — use custom below</div>}
            </div>
          )}
          {/* Custom */}
          <div style={{ padding: 14, background: 'var(--surface2)', borderRadius: 10 }}>
            <div style={{ fontSize: '0.78rem', color: 'var(--text3)', marginBottom: 8 }}>Custom food</div>
            <input value={custom.name} onChange={e => setCustom(c=>({...c,name:e.target.value}))} placeholder="Food name" style={{ marginBottom: 6 }} />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 8 }}>
              <input type="number" value={custom.cal} onChange={e => setCustom(c=>({...c,cal:e.target.value}))} placeholder="Calories *" />
              <input type="number" value={custom.protein} onChange={e => setCustom(c=>({...c,protein:e.target.value}))} placeholder="Protein g" />
              <input type="number" value={custom.carbs} onChange={e => setCustom(c=>({...c,carbs:e.target.value}))} placeholder="Carbs g" />
              <input type="number" value={custom.fat} onChange={e => setCustom(c=>({...c,fat:e.target.value}))} placeholder="Fat g" />
            </div>
            <button onClick={addCustom} disabled={!custom.name||!custom.cal} className="btn btn-secondary" style={{ width:'100%', justifyContent:'center', fontSize:'0.82rem' }}><Plus size={14}/> Add custom</button>
          </div>

          {/* Water */}
          <div className="card" style={{ marginTop: 16, padding: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Droplets size={16} color="#5bd3c7" /><span style={{ fontWeight: 600, fontSize: '0.88rem' }}>Water intake</span></div>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: '#5bd3c7' }}>{water}/8 glasses</span>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
              {Array.from({length:8},(_,i)=>(
                <div key={i} onClick={() => setWater(i<water?i:i+1)} style={{ width:32,height:40,borderRadius:6,background:i<water?'rgba(91,211,199,0.3)':'var(--surface2)',border:`1px solid ${i<water?'rgba(91,211,199,0.4)':'var(--border2)'}`,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',transition:'all 0.15s' }}>
                  <Droplets size={14} color={i<water?'#5bd3c7':'var(--text3)'} />
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => setWater(w=>Math.min(w+1,8))} className="btn btn-secondary" style={{ flex:1,justifyContent:'center',fontSize:'0.82rem' }}>+ Glass</button>
              <button onClick={() => setWater(0)} className="btn btn-ghost" style={{ fontSize:'0.82rem' }}>Reset</button>
            </div>
          </div>
        </div>

        {/* Today's log */}
        <div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 14 }}>Today's Log</h3>
          {entries.length === 0 ? (
            <div className="card" style={{ textAlign:'center',padding:40 }}>
              <Apple size={32} color="var(--text3)" style={{ margin:'0 auto 12px' }} />
              <p style={{ color:'var(--text3)',fontSize:'0.88rem' }}>No food logged yet today.</p>
            </div>
          ) : (
            <div style={{ display:'flex',flexDirection:'column',gap:8,maxHeight:580,overflowY:'auto',paddingRight:4 }}>
              {MEALS.map(m => {
                const mealEntries = entries.filter(e => e.meal === m);
                if (!mealEntries.length) return null;
                const mealCal = mealEntries.reduce((a,e)=>a+e.cal,0);
                return (
                  <div key={m}>
                    <div style={{ fontSize:'0.75rem',fontWeight:700,color:'var(--text3)',marginBottom:6,textTransform:'uppercase',letterSpacing:'0.06em' }}>{m} · {mealCal} kcal</div>
                    {mealEntries.map(e => (
                      <div key={e.id} style={{ display:'flex',justifyContent:'space-between',alignItems:'center',padding:'8px 12px',background:'var(--surface)',borderRadius:8,marginBottom:4,border:'1px solid var(--border)' }}>
                        <div>
                          <div style={{ fontSize:'0.83rem',fontWeight:500 }}>{e.name}</div>
                          <div style={{ fontSize:'0.72rem',color:'var(--text3)' }}>P:{e.protein}g · C:{e.carbs}g · F:{e.fat}g</div>
                        </div>
                        <div style={{ display:'flex',alignItems:'center',gap:8 }}>
                          <span style={{ fontWeight:700,color:'#5bd3c7',fontSize:'0.85rem' }}>{e.cal}</span>
                          <button onClick={()=>remove(e.id)} style={{ background:'none',border:'none',color:'var(--text3)',cursor:'pointer',padding:3 }}><Trash2 size={12}/></button>
                        </div>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
