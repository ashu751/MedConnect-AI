import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Send, Stethoscope, AlertTriangle, RefreshCw, User, Bot, Info, Lock } from 'lucide-react';

// #2 - Note about API key security added in UI; key still used client-side for demo
// For production: proxy this through /api/chat endpoint on your backend
const GEMINI_API_KEY = process.env.REACT_APP_GEMINI_API_KEY || '';

const SYSTEM_PROMPT = `You are MedConnect's AI Medical Assistant — a knowledgeable, empathetic, and safety-conscious health companion.

Your role:
- Help users understand their symptoms in plain, reassuring language
- Provide general health information and possible explanations for symptoms
- Suggest when to seek professional medical care
- Give practical, evidence-based wellness advice

Rules:
- Always remind users you are an AI, not a real doctor
- Never diagnose definitively — use phrases like "this could indicate", "common causes include", "it may be worth checking"
- If symptoms are severe (chest pain, difficulty breathing, stroke signs), immediately urge emergency services
- Be warm, clear, and non-alarmist
- Keep responses concise but thorough — use bullet points for readability
- Ask follow-up questions when needed to better understand the situation`;

async function askGemini(messages) {
  if (!GEMINI_API_KEY) {
    await new Promise(r => setTimeout(r, 1500));
    const lastMsg = messages[messages.length - 1].content.toLowerCase();
    if (lastMsg.includes('headache')) {
      return `**Based on your description**, headaches are extremely common and usually not serious. Here are some common causes:\n\n• **Tension headaches** — caused by stress, poor posture, or eye strain (most common)\n• **Dehydration** — even mild dehydration can trigger headaches\n• **Lack of sleep** — disrupted sleep patterns frequently cause headaches\n\n**What you can do:**\n1. Drink 1-2 glasses of water now\n2. Take a break from screens\n3. Try gentle neck stretches\n\n**Seek care if** your headache is sudden and severe, accompanied by fever/stiff neck, or doesn't improve with rest.\n\n⚠️ *I'm an AI assistant — not a doctor. Please consult a healthcare professional for persistent symptoms.*`;
    }
    return `Thank you for sharing that. To better understand your situation, could you tell me:\n\n1. **How long** have you been experiencing this?\n2. **Severity** on a scale of 1–10?\n3. **Any other symptoms** accompanying this?\n\n⚠️ *I'm an AI assistant — not a substitute for professional medical advice.*`;
  }

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents: messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      })),
      generationConfig: { temperature: 0.7, maxOutputTokens: 1024 }
    })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'API error');
  }
  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || 'I couldn\'t generate a response. Please try again.';
}

function formatMessage(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/^• /gm, '&bull; ')
    .replace(/\n\n/g, '<br/><br/>')
    .replace(/\n/g, '<br/>');
}

export default function MedicalAI() {
  const { lang } = useTheme();
  const { user, updateUser } = useAuth();
  const initialMsg = {
    role: 'assistant',
    content: `Hello ${user?.name?.split(' ')[0] || 'there'}! I'm your AI Medical Assistant.\n\nI can help you:\n• Understand your symptoms\n• Learn about health conditions\n• Get wellness advice\n• Know when to see a doctor\n\nWhat health concern can I help you with today?`
  };
  const [messages, setMessages] = useState([initialMsg]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [apiMode] = useState(!GEMINI_API_KEY);
  const bottomRef = useRef(null);
  const consultationTracked = useRef(false);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: 'user', content: input.trim() };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    // #3 - Track consultation count on first real message sent
    if (!consultationTracked.current) {
      consultationTracked.current = true;
      updateUser({ consultations: (user.consultations || 0) + 1 });
    }

    try {
      const reply = await askGemini(newMessages);
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', content: `⚠️ Error: ${e.message}. Please check your API key or try again.` }]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    'I have a headache and feel tired',
    'What are signs of vitamin deficiency?',
    'I\'ve been feeling anxious lately',
    'How do I know if I need to see a doctor?'
  ];

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', padding: 'clamp(16px, 3vw, 24px)', maxWidth: 800, margin: '0 auto', width: '100%' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 42, height: 42, borderRadius: 11, background: 'rgba(91,211,199,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Stethoscope size={20} color="#5bd3c7" />
          </div>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700 }}>{t('aiMedicalAssistant',lang)}</h1>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#5bd3c7' }} className="pulse" />
              <span style={{ fontSize: '0.75rem', color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>
                {apiMode ? 'Demo Mode' : 'Gemini 1.5 Flash'}
              </span>
            </div>
          </div>
        </div>
        <button onClick={() => { setMessages([initialMsg]); consultationTracked.current = false; }} className="btn btn-ghost" style={{ gap: 6, fontSize: '0.85rem' }}>
          <RefreshCw size={14} /> New chat
        </button>
      </div>

      {/* #2 - API key security notice */}
      {!apiMode && (
        <div style={{ padding: '10px 14px', background: 'rgba(91,211,199,0.06)', border: '1px solid rgba(91,211,199,0.12)', borderRadius: 8, marginBottom: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
          <Lock size={13} color="#5bd3c7" style={{ flexShrink: 0 }} />
          <span style={{ fontSize: '0.75rem', color: 'var(--text3)' }}>
            For production use, proxy API calls through your backend to keep keys secure. See README for details.
          </span>
        </div>
      )}

      {apiMode && (
        <div style={{ padding: '12px 16px', background: 'rgba(245,166,35,0.08)', border: '1px solid rgba(245,166,35,0.2)', borderRadius: 10, marginBottom: 12, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <Info size={16} color="#f5a623" style={{ marginTop: 2, flexShrink: 0 }} />
          <p style={{ fontSize: '0.82rem', color: 'var(--text2)', lineHeight: 1.5 }}>
            <strong>Demo mode</strong> — Set <code style={{ background: 'var(--surface2)', padding: '1px 5px', borderRadius: 4, fontFamily: 'var(--font-mono)' }}>REACT_APP_GEMINI_API_KEY</code> in your <code style={{ background: 'var(--surface2)', padding: '1px 5px', borderRadius: 4, fontFamily: 'var(--font-mono)' }}>.env</code> for real AI. Free key at <a href="https://aistudio.google.com" target="_blank" rel="noreferrer" style={{ color: '#f5a623' }}>aistudio.google.com</a>
          </p>
        </div>
      )}

      {/* Disclaimer */}
      <div style={{ padding: '10px 14px', background: 'rgba(240,98,138,0.06)', border: '1px solid rgba(240,98,138,0.15)', borderRadius: 8, marginBottom: 16, display: 'flex', gap: 8, alignItems: 'center' }}>
        <AlertTriangle size={14} color="var(--accent3)" style={{ flexShrink: 0 }} />
        <span style={{ fontSize: '0.78rem', color: 'var(--text3)' }}>{t('disclaimer',lang)}</span>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column', gap: 16, paddingRight: 4, paddingBottom: 8 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
            {msg.role === 'assistant' && (
              <div style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(91,211,199,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Bot size={16} color="#5bd3c7" />
              </div>
            )}
            <div
              className={msg.role === 'user' ? 'chat-user' : 'chat-ai'}
              style={{ maxWidth: '80%', padding: '12px 16px', fontSize: '0.9rem', lineHeight: 1.6 }}
              dangerouslySetInnerHTML={{ __html: formatMessage(msg.content) }}
            />
            {msg.role === 'user' && (
              <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <User size={16} color="white" />
              </div>
            )}
          </div>
        ))}
        {loading && (
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(91,211,199,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Bot size={16} color="#5bd3c7" />
            </div>
            <div className="chat-ai" style={{ padding: '14px 18px' }}>
              <div style={{ display: 'flex', gap: 4 }}>
                {[0,1,2].map(i => (
                  <div key={i} style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--text3)', animation: 'bounce 1.2s ease infinite', animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Quick prompts */}
      {messages.length === 1 && (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12, marginBottom: 8 }}>
          {quickPrompts.map((p, i) => (
            <button key={i} onClick={() => setInput(p)} className="btn btn-secondary" style={{ fontSize: '0.8rem', padding: '8px 14px' }}>
              {p}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div style={{ display: 'flex', gap: 10, marginTop: 8, padding: '12px', background: 'var(--surface)', borderRadius: 14, border: '1px solid var(--border2)' }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
          placeholder={t('describeSymptoms',lang)}
          style={{ border: 'none', background: 'transparent', padding: '4px 8px', flex: 1, fontSize: '0.9rem', outline: 'none', boxShadow: 'none' }}
          disabled={loading}
        />
        <button onClick={send} disabled={loading || !input.trim()} className="btn btn-primary" style={{ padding: '10px 16px', flexShrink: 0, opacity: (!input.trim() || loading) ? 0.5 : 1 }}>
          <Send size={16} />
        </button>
      </div>

      <style>{`@keyframes bounce { 0%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-6px); } }`}</style>
    </div>
  );
}
