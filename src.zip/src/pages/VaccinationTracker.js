import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Shield, Plus, Check, Calendar, AlertCircle, Trash2 } from 'lucide-react';

const STANDARD_VACCINES = [
  { name: 'COVID-19', doses: 2, booster: true, schedule: 'As per government guidelines' },
  { name: 'Influenza (Flu)', doses: 1, booster: true, schedule: 'Annually' },
  { name: 'Hepatitis B', doses: 3, booster: false, schedule: '0, 1, 6 months' },
  { name: 'Hepatitis A', doses: 2, booster: false, schedule: '0, 6–12 months' },
  { name: 'Tetanus (Td/Tdap)', doses: 1, booster: true, schedule: 'Every 10 years' },
  { name: 'MMR (Measles, Mumps, Rubella)', doses: 2, booster: false, schedule: 'Childhood' },
  { name: 'Varicella (Chickenpox)', doses: 2, booster: false, schedule: 'Childhood' },
  { name: 'HPV', doses: 2, booster: false, schedule: '9–14 years: 2 doses; 15+: 3 doses' },
  { name: 'Pneumococcal', doses: 1, booster: false, schedule: 'Age 65+ or high risk' },
  { name: 'Typhoid', doses: 1, booster: true, schedule: 'Every 2–3 years if at risk' },
];

export default function VaccinationTracker() {
  const { lang } = useTheme();
  const { user, updateUser } = useAuth();
  const records = user.vaccinationRecords || [];
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: '', date: new Date().toISOString().split('T')[0], dose: '1', nextDue: '', notes: '', provider: '' });
  const [customName, setCustomName] = useState('');

  const save = () => {
    const name = customName.trim() || form.name;
    if (!name) return;
    const entry = { ...form, name, id: Date.now() };
    updateUser({ vaccinationRecords: [entry, ...records] });
    setForm({ name: '', date: new Date().toISOString().split('T')[0], dose: '1', nextDue: '', notes: '', provider: '' });
    setCustomName(''); setAdding(false);
  };

  const remove = (id) => updateUser({ vaccinationRecords: records.filter(r => r.id !== id) });

  const upcoming = records.filter(r => r.nextDue && new Date(r.nextDue) <= new Date(Date.now() + 30*24*60*60*1000) && new Date(r.nextDue) >= new Date());
  const overdueList = records.filter(r => r.nextDue && new Date(r.nextDue) < new Date());

  const coveredVaccines = new Set(records.map(r => r.name));

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Prevention</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('vaccinationRecords',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('vaccinationDesc',lang)}</p>
      </div>

      {(upcoming.length > 0 || overdueList.length > 0) && (
        <div style={{ display: 'grid', gap: 12, marginBottom: 24 }}>
          {overdueList.map(r => (
            <div key={r.id} style={{ padding: '12px 16px', background: 'rgba(240,98,138,0.08)', border: '1px solid rgba(240,98,138,0.2)', borderRadius: 12, display: 'flex', gap: 10, alignItems: 'center' }}>
              <AlertCircle size={16} color="var(--accent3)" style={{ flexShrink: 0 }} />
              <span style={{ fontSize: '0.85rem' }}><strong>{r.name}</strong> booster was due on {new Date(r.nextDue).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
            </div>
          ))}
          {upcoming.map(r => (
            <div key={r.id} style={{ padding: '12px 16px', background: 'rgba(245,166,35,0.08)', border: '1px solid rgba(245,166,35,0.2)', borderRadius: 12, display: 'flex', gap: 10, alignItems: 'center' }}>
              <Calendar size={16} color="#f5a623" style={{ flexShrink: 0 }} />
              <span style={{ fontSize: '0.85rem' }}><strong>{r.name}</strong> due on {new Date(r.nextDue).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
            </div>
          ))}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* Standard schedule */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem' }}>Standard Schedule</h2>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {STANDARD_VACCINES.map(v => {
              const done = coveredVaccines.has(v.name);
              return (
                <div key={v.name} className="card" style={{ padding: '12px 16px', borderColor: done ? 'rgba(91,211,199,0.2)' : 'var(--border)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 28, height: 28, borderRadius: '50%', background: done ? 'rgba(91,211,199,0.15)' : 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      {done ? <Check size={14} color="#5bd3c7" /> : <Shield size={12} color="var(--text3)" />}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '0.85rem', fontWeight: done ? 600 : 400, color: done ? 'var(--text)' : 'var(--text2)' }}>{v.name}</div>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text3)' }}>{v.schedule}</div>
                    </div>
                    {!done && (
                      <button onClick={() => { setAdding(true); setForm(f => ({...f, name: v.name})); }} style={{ fontSize: '0.72rem', padding: '4px 10px', borderRadius: 100, border: '1px solid var(--border2)', background: 'var(--surface2)', color: 'var(--text3)', cursor: 'pointer' }}>+ Log</button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* My records */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem' }}>My Records</h2>
            <button onClick={() => setAdding(!adding)} className="btn btn-primary" style={{ padding: '8px 14px', fontSize: '0.82rem' }}><Plus size={14} /> Add</button>
          </div>

          {adding && (
            <div className="card" style={{ marginBottom: 16, borderColor: 'rgba(124,106,247,0.2)' }}>
              <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 14, fontSize: '0.9rem' }}>Log Vaccination</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <select value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))}>
                  <option value="">— Select vaccine —</option>
                  {STANDARD_VACCINES.map(v => <option key={v.name}>{v.name}</option>)}
                </select>
                <input value={customName} onChange={e => setCustomName(e.target.value)} placeholder="Or type custom vaccine name..." />
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                  <div><label style={{ fontSize: '0.75rem', color: 'var(--text3)', display: 'block', marginBottom: 4 }}>Date received</label><input type="date" value={form.date} onChange={e => setForm(f => ({...f, date: e.target.value}))} /></div>
                  <div><label style={{ fontSize: '0.75rem', color: 'var(--text3)', display: 'block', marginBottom: 4 }}>Dose #</label><input value={form.dose} onChange={e => setForm(f => ({...f, dose: e.target.value}))} placeholder="1" /></div>
                  <div><label style={{ fontSize: '0.75rem', color: 'var(--text3)', display: 'block', marginBottom: 4 }}>Next due (opt.)</label><input type="date" value={form.nextDue} onChange={e => setForm(f => ({...f, nextDue: e.target.value}))} /></div>
                  <div><label style={{ fontSize: '0.75rem', color: 'var(--text3)', display: 'block', marginBottom: 4 }}>Provider</label><input value={form.provider} onChange={e => setForm(f => ({...f, provider: e.target.value}))} placeholder="Hospital / clinic" /></div>
                </div>
                <input value={form.notes} onChange={e => setForm(f => ({...f, notes: e.target.value}))} placeholder="Notes (batch no., reactions...)" />
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={save} className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }}>Save Record</button>
                  <button onClick={() => setAdding(false)} className="btn btn-ghost">Cancel</button>
                </div>
              </div>
            </div>
          )}

          {records.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: 32 }}>
              <Shield size={32} color="var(--text3)" style={{ margin: '0 auto 12px' }} />
              <p style={{ color: 'var(--text3)', fontSize: '0.88rem' }}>No records yet. Log your vaccinations from the standard schedule on the left.</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 520, overflowY: 'auto' }}>
              {records.map(r => (
                <div key={r.id} className="card" style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: '0.88rem', marginBottom: 2 }}>{r.name} — Dose {r.dose}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text3)' }}>
                        {new Date(r.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                        {r.provider && ` · ${r.provider}`}
                      </div>
                      {r.nextDue && <div style={{ fontSize: '0.72rem', color: '#f5a623', marginTop: 4 }}>Next: {new Date(r.nextDue).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</div>}
                    </div>
                    <button onClick={() => remove(r.id)} style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', padding: 4 }}><Trash2 size={13} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
