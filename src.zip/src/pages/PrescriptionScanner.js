import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useRef } from 'react';
import { Upload, FileImage, AlertTriangle, RefreshCw, Bot, Pill, Info, Lock, CheckCircle, X } from 'lucide-react';

const GEMINI_API_KEY = process.env.REACT_APP_GEMINI_API_KEY || '';

const SYSTEM_PROMPT = `You are MedConnect's Prescription Analyzer. When given an image of a prescription or medicine label, extract and explain all information clearly.

Structure your response EXACTLY as follows (use these exact headers):

**MEDICINES PRESCRIBED**
List each medicine with: name, dosage, frequency, duration (if visible)

**WHAT EACH MEDICINE IS FOR**
Brief plain-language explanation of each medicine's purpose

**HOW TO TAKE THEM**
Instructions: with/without food, timing, special precautions

**POSSIBLE INTERACTIONS & WARNINGS**
Any known interactions between the prescribed medicines, or important warnings. If none, say "No major interactions identified."

**IMPORTANT REMINDERS**
- Always complete the full course
- Do not self-adjust dosages
- Consult your doctor if side effects occur

Keep language simple and reassuring. If the image is not a prescription, politely say so.
⚠️ Always end with: "This analysis is for informational purposes only. Always follow your doctor's exact instructions."`;

async function analyzePrescription(base64Image, mimeType) {
  if (!GEMINI_API_KEY) {
    await new Promise(r => setTimeout(r, 2000));
    return `**MEDICINES PRESCRIBED**
• Amoxicillin 500mg — 3 times daily for 7 days
• Paracetamol 650mg — twice daily as needed
• Pantoprazole 40mg — once daily before breakfast

**WHAT EACH MEDICINE IS FOR**
• **Amoxicillin** — An antibiotic to treat bacterial infections (commonly throat, chest, or ear infections)
• **Paracetamol** — A pain reliever and fever reducer for comfort during illness
• **Pantoprazole** — Protects the stomach lining from acidity caused by the antibiotic

**HOW TO TAKE THEM**
• Amoxicillin: Take with food to reduce stomach upset. Space doses evenly — every 8 hours.
• Paracetamol: Take only when needed for pain or fever. Do not exceed 4 doses in 24 hours.
• Pantoprazole: Take 30 minutes before breakfast on an empty stomach.

**POSSIBLE INTERACTIONS & WARNINGS**
• No major interactions identified between these three medicines.
• Amoxicillin may reduce effectiveness of oral contraceptive pills — consult your doctor if applicable.
• Avoid alcohol while on this course.

**IMPORTANT REMINDERS**
• Always complete the full 7-day antibiotic course even if you feel better
• Do not self-adjust dosages
• Consult your doctor if you develop a rash, difficulty breathing, or worsening symptoms

⚠️ This analysis is for informational purposes only. Always follow your doctor's exact instructions.`;
  }

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents: [{
          role: 'user',
          parts: [
            { inline_data: { mime_type: mimeType, data: base64Image } },
            { text: 'Please analyze this prescription and explain all medicines, their purposes, how to take them, and any warnings.' }
          ]
        }],
        generationConfig: { temperature: 0.3, maxOutputTokens: 1500 }
      })
    }
  );

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'API error');
  }
  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || 'Could not analyze the prescription. Please try a clearer image.';
}

function formatResult(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/^• /gm, '&bull; ')
    .replace(/\n\n/g, '<br/><br/>')
    .replace(/\n/g, '<br/>');
}

// Parse sections for structured card display
function parseSections(text) {
  const sections = [];
  const sectionDefs = [
    { key: 'medicines', title: 'Medicines Prescribed', color: '#5bd3c7', icon: '💊' },
    { key: 'purpose', title: 'What Each Medicine Is For', color: '#7c6af7', icon: '🩺' },
    { key: 'how', title: 'How to Take Them', color: '#f5a623', icon: '⏰' },
    { key: 'warnings', title: 'Interactions & Warnings', color: '#f0628a', icon: '⚠️' },
    { key: 'reminders', title: 'Important Reminders', color: '#5bd3c7', icon: '✅' },
  ];

  const markers = [
    'MEDICINES PRESCRIBED',
    'WHAT EACH MEDICINE IS FOR',
    'HOW TO TAKE THEM',
    'POSSIBLE INTERACTIONS & WARNINGS',
    'IMPORTANT REMINDERS',
  ];

  let remaining = text;
  markers.forEach((marker, i) => {
    const nextMarker = markers[i + 1];
    const start = remaining.indexOf(marker);
    if (start === -1) return;
    const end = nextMarker ? remaining.indexOf(nextMarker) : remaining.length;
    const content = remaining.slice(start + marker.length, end !== -1 ? end : undefined).trim();
    sections.push({ ...sectionDefs[i], content });
  });

  // fallback: just show raw text
  if (sections.length === 0) return null;
  return sections;
}

export default function PrescriptionScanner() {
  const { lang } = useTheme();
  const [image, setImage] = useState(null); // { url, base64, mimeType }
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [dragging, setDragging] = useState(false);
  const fileRef = useRef();
  const apiMode = !GEMINI_API_KEY;

  const handleFile = (file) => {
    if (!file || !file.type.startsWith('image/')) {
      setError('Please upload an image file (JPG, PNG, WEBP)');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('Image must be under 10MB');
      return;
    }
    setError('');
    setResult(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target.result;
      const base64 = dataUrl.split(',')[1];
      setImage({ url: dataUrl, base64, mimeType: file.type });
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const analyze = async () => {
    if (!image) return;
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const text = await analyzePrescription(image.base64, image.mimeType);
      setResult(text);
    } catch (e) {
      setError(`Analysis failed: ${e.message}`);
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setImage(null);
    setResult(null);
    setError('');
  };

  const sections = result ? parseSections(result) : null;

  return (
    <div style={{ padding: 'clamp(20px, 4vw, 40px)', maxWidth: 900, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>AI-Powered</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem, 4vw, 2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>
          Prescription Scanner
        </h1>
        <p style={{ color: 'var(--text3)', fontSize: '0.95rem' }}>
          Upload a photo of your prescription — AI will explain every medicine, dosage, and warning in plain language.
        </p>
      </div>

      {/* Notices */}
      {apiMode && (
        <div style={{ padding: '12px 16px', background: 'rgba(245,166,35,0.08)', border: '1px solid rgba(245,166,35,0.2)', borderRadius: 10, marginBottom: 16, display: 'flex', gap: 10 }}>
          <Info size={16} color="#f5a623" style={{ flexShrink: 0, marginTop: 2 }} />
          <p style={{ fontSize: '0.82rem', color: 'var(--text2)', lineHeight: 1.5 }}>
            <strong>Demo mode</strong> — Add your Gemini API key to analyze real prescriptions. A sample analysis will be shown.
          </p>
        </div>
      )}
      {!apiMode && (
        <div style={{ padding: '10px 14px', background: 'rgba(91,211,199,0.06)', border: '1px solid rgba(91,211,199,0.12)', borderRadius: 8, marginBottom: 16, display: 'flex', gap: 8, alignItems: 'center' }}>
          <Lock size={13} color="#5bd3c7" style={{ flexShrink: 0 }} />
          <span style={{ fontSize: '0.75rem', color: 'var(--text3)' }}>Images are sent to Gemini for analysis and are not stored. For sensitive prescriptions, use demo mode.</span>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: result ? '1fr 1fr' : '1fr', gap: 24 }}>
        {/* Upload panel */}
        <div>
          {!image ? (
            <div
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileRef.current.click()}
              style={{
                border: `2px dashed ${dragging ? 'var(--accent)' : 'var(--border2)'}`,
                borderRadius: 16, padding: '48px 24px', textAlign: 'center', cursor: 'pointer',
                background: dragging ? 'rgba(124,106,247,0.05)' : 'var(--surface)',
                transition: 'all 0.2s', minHeight: 260, display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'center', gap: 16
              }}>
              <div style={{ width: 56, height: 56, borderRadius: 14, background: 'rgba(124,106,247,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Upload size={24} color="var(--accent)" />
              </div>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, marginBottom: 6 }}>Drop prescription image here</div>
                <div style={{ color: 'var(--text3)', fontSize: '0.85rem' }}>or click to browse — JPG, PNG, WEBP up to 10MB</div>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
                {['Doctor prescription', 'Medicine label', 'Discharge summary'].map(t => (
                  <span key={t} className="tag" style={{ background: 'var(--surface2)', color: 'var(--text3)', fontSize: '0.72rem' }}>{t}</span>
                ))}
              </div>
              <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => handleFile(e.target.files[0])} />
            </div>
          ) : (
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ position: 'relative' }}>
                <img src={image.url} alt="Prescription" style={{ width: '100%', maxHeight: 340, objectFit: 'contain', background: '#111', display: 'block' }} />
                <button onClick={reset} style={{ position: 'absolute', top: 12, right: 12, width: 32, height: 32, borderRadius: '50%', background: 'rgba(0,0,0,0.6)', border: 'none', color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <X size={16} />
                </button>
              </div>
              <div style={{ padding: 20 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                  <FileImage size={16} color="var(--accent2)" />
                  <span style={{ fontSize: '0.85rem', color: 'var(--text2)' }}>Image ready for analysis</span>
                  <CheckCircle size={14} color="#5bd3c7" style={{ marginLeft: 'auto' }} />
                </div>
                <button onClick={analyze} disabled={loading} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', opacity: loading ? 0.7 : 1 }}>
                  {loading ? (
                    <><div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Analyzing prescription...</>
                  ) : (
                    <><Bot size={16} /> Analyze with AI</>
                  )}
                </button>
                <button onClick={reset} className="btn btn-ghost" style={{ width: '100%', justifyContent: 'center', marginTop: 8, fontSize: '0.85rem' }}>
                  Upload different image
                </button>
              </div>
            </div>
          )}

          {error && (
            <div style={{ marginTop: 12, padding: '10px 14px', background: 'rgba(240,98,138,0.08)', border: '1px solid rgba(240,98,138,0.2)', borderRadius: 8, fontSize: '0.85rem', color: 'var(--accent3)', display: 'flex', gap: 8 }}>
              <AlertTriangle size={14} style={{ flexShrink: 0, marginTop: 2 }} /> {error}
            </div>
          )}

          {/* Tips */}
          <div className="card" style={{ marginTop: 20, padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.9rem', marginBottom: 12 }}>Tips for best results</div>
            {[
              'Ensure the text is clearly visible and in focus',
              'Good lighting — avoid glare or shadows on the paper',
              'Include the full prescription in the frame',
              'Handwritten prescriptions work too, but typed is clearer',
            ].map((tip, i) => (
              <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 8 }}>
                <div style={{ width: 18, height: 18, borderRadius: '50%', background: 'rgba(124,106,247,0.15)', color: 'var(--accent)', fontSize: '0.7rem', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>{i + 1}</div>
                <span style={{ fontSize: '0.83rem', color: 'var(--text3)', lineHeight: 1.5 }}>{tip}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Results panel */}
        {result && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Pill size={18} color="#5bd3c7" />
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>Analysis Result</span>
              </div>
              <button onClick={reset} className="btn btn-ghost" style={{ fontSize: '0.8rem', gap: 6 }}>
                <RefreshCw size={13} /> New scan
              </button>
            </div>

            {sections ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {sections.map((s, i) => (
                  <div key={i} className="card" style={{ padding: 18, borderColor: `${s.color}20` }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                      <span style={{ fontSize: '1rem' }}>{s.icon}</span>
                      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.88rem', color: s.color }}>{s.title}</span>
                    </div>
                    <div style={{ fontSize: '0.85rem', color: 'var(--text2)', lineHeight: 1.7 }}
                      dangerouslySetInnerHTML={{ __html: formatResult(s.content) }} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="card">
                <div style={{ fontSize: '0.88rem', color: 'var(--text2)', lineHeight: 1.7 }}
                  dangerouslySetInnerHTML={{ __html: formatResult(result) }} />
              </div>
            )}

            <div style={{ marginTop: 14, padding: '10px 14px', background: 'rgba(240,98,138,0.06)', border: '1px solid rgba(240,98,138,0.15)', borderRadius: 8, display: 'flex', gap: 8 }}>
              <AlertTriangle size={14} color="var(--accent3)" style={{ flexShrink: 0, marginTop: 2 }} />
              <span style={{ fontSize: '0.78rem', color: 'var(--text3)', lineHeight: 1.5 }}>This analysis is AI-generated and for informational purposes only. Always follow your doctor's exact instructions.</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
