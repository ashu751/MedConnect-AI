import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState } from 'react';
import { Phone, MapPin, AlertCircle, Navigation, Clock, Ambulance } from 'lucide-react';

const EMERGENCY_NUMBERS = [
  { name: 'National Ambulance', number: '108', desc: 'Free government ambulance service — available 24/7 across India', priority: true },
  { name: 'Police Emergency', number: '100', desc: 'Police — can also coordinate emergency medical response', priority: true },
  { name: 'Fire & Emergency', number: '101', desc: 'Fire brigade — can assist in accidents and emergencies', priority: false },
  { name: 'National Emergency', number: '112', desc: 'Single emergency number covering police, fire and medical', priority: true },
  { name: 'AIIMS Emergency', number: '011-26588500', desc: 'All India Institute of Medical Sciences, Delhi', priority: false },
];

const HOSPITALS_NEARBY = [
  { name: 'City Emergency Hospital', distance: '0.8 km', eta: '4 min', address: 'Sector 14, Central District', available: true, beds: 12 },
  { name: 'Apollo Emergency Care', distance: '1.4 km', eta: '6 min', address: 'Ring Road, East Block', available: true, beds: 8 },
  { name: 'Government Medical Center', distance: '2.1 km', eta: '9 min', address: 'Civil Lines', available: true, beds: 24 },
  { name: 'Max Super Speciality', distance: '3.2 km', eta: '13 min', address: 'Saket, South Delhi', available: false, beds: 0 },
];

const FIRST_AID = [
  { condition: 'Heart Attack', steps: ['Call 108 immediately','Have them sit/lie down comfortably','Loosen tight clothing','Give aspirin if available & not allergic','Stay with them until help arrives'] },
  { condition: 'Stroke (FAST)', steps: ['F — Face drooping?','A — Arm weakness?','S — Speech difficulty?','T — Time to call 108 NOW','Do not give food or water'] },
  { condition: 'Severe Bleeding', steps: ['Call 108','Apply firm pressure with clean cloth','Keep pressure on — do not remove cloth','Elevate the injured area if possible','Do not use tourniquet unless trained'] },
  { condition: 'Unconscious Person', steps: ['Check for danger first','Call 108 immediately','Check breathing','If not breathing, begin CPR if trained','Recovery position if breathing'] },
];

export default function AmbulanceFinder() {
  const { lang } = useTheme();
  const [locating, setLocating] = useState(false);
  const [location, setLocation] = useState(null);
  const [selectedFirst, setSelectedFirst] = useState(null);

  const locate = () => {
    setLocating(true);
    navigator.geolocation?.getCurrentPosition(
      pos => { setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }); setLocating(false); },
      () => { setLocation({ lat: 28.6139, lng: 77.2090, fallback: true }); setLocating(false); }
    );
  };

  return (
    <div style={{ padding:'clamp(20px,4vw,40px)',maxWidth:900,margin:'0 auto' }}>
      <div style={{ marginBottom:20 }}>
        <p className="prose-label" style={{ marginBottom:8 }}>Emergency</p>
        <h1 style={{ fontFamily:'var(--font-display)',fontSize:'clamp(1.6rem,4vw,2.2rem)',fontWeight:700,letterSpacing:'-0.02em',marginBottom:8 }}>{t('emergencyAmbulance',lang)}</h1>
        <p style={{ color:'var(--text3)' }}>{t('emergencyDesc',lang)}</p>
      </div>

      {/* Emergency banner */}
      <div style={{ padding:'16px 20px',background:'rgba(240,98,138,0.1)',border:'2px solid rgba(240,98,138,0.3)',borderRadius:16,marginBottom:28,display:'flex',alignItems:'center',gap:16,flexWrap:'wrap' }}>
        <div style={{ width:48,height:48,borderRadius:'50%',background:'rgba(240,98,138,0.2)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0 }}>
          <AlertCircle size={24} color="var(--accent3)" />
        </div>
        <div style={{ flex:1 }}>
          <div style={{ fontFamily:'var(--font-display)',fontWeight:700,color:'var(--accent3)',marginBottom:2 }}>Medical Emergency?</div>
          <p style={{ fontSize:'0.85rem',color:'var(--text3)' }}>Call 108 immediately for a free ambulance anywhere in India. Stay on the line and follow instructions.</p>
        </div>
        <a href="tel:108" className="btn" style={{ background:'var(--accent3)',color:'white',padding:'12px 24px',borderRadius:10,fontFamily:'var(--font-display)',fontWeight:700,fontSize:'1.1rem',flexShrink:0,textDecoration:'none' }}>
          📞 Call 108
        </a>
      </div>

      <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:24 }}>
        {/* Emergency Numbers */}
        <div>
          <h2 style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'1rem',marginBottom:14 }}>Emergency Numbers</h2>
          <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
            {EMERGENCY_NUMBERS.map(e=>(
              <div key={e.number} className="card" style={{ padding:'14px 16px',borderColor:e.priority?'rgba(240,98,138,0.2)':'var(--border)' }}>
                <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',gap:12 }}>
                  <div style={{ flex:1 }}>
                    <div style={{ display:'flex',alignItems:'center',gap:8,marginBottom:3 }}>
                      <span style={{ fontWeight:700,fontSize:'0.9rem' }}>{e.name}</span>
                      {e.priority&&<span style={{ fontSize:'0.68rem',padding:'2px 6px',borderRadius:100,background:'rgba(240,98,138,0.12)',color:'var(--accent3)',fontWeight:700 }}>PRIORITY</span>}
                    </div>
                    <div style={{ fontSize:'0.78rem',color:'var(--text3)',marginBottom:4 }}>{e.desc}</div>
                  </div>
                  <a href={`tel:${e.number}`} style={{ display:'flex',alignItems:'center',gap:6,padding:'8px 14px',borderRadius:8,background:e.priority?'var(--accent3)':'var(--surface2)',color:e.priority?'white':'var(--text)',textDecoration:'none',fontFamily:'var(--font-display)',fontWeight:700,fontSize:'0.95rem',flexShrink:0 }}>
                    <Phone size={14}/>{e.number}
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Nearby hospitals */}
        <div>
          <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14 }}>
            <h2 style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'1rem' }}>Nearest Hospitals</h2>
            <button onClick={locate} disabled={locating} className="btn btn-ghost" style={{ fontSize:'0.8rem',gap:6 }}>
              <Navigation size={13}/>{locating?'Locating...':location?'Located ✓':'Get location'}
            </button>
          </div>
          <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
            {HOSPITALS_NEARBY.map(h=>(
              <div key={h.name} className="card" style={{ padding:'14px 16px',borderColor:h.available?'rgba(91,211,199,0.2)':'var(--border)',opacity:h.available?1:0.7 }}>
                <div style={{ display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:8 }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:600,fontSize:'0.88rem',marginBottom:3 }}>{h.name}</div>
                    <div style={{ display:'flex',gap:10,fontSize:'0.75rem',color:'var(--text3)',marginBottom:4 }}>
                      <span><MapPin size={10}/> {h.distance}</span>
                      <span><Clock size={10}/> ETA {h.eta}</span>
                    </div>
                    <div style={{ fontSize:'0.72rem',color:'var(--text3)' }}>{h.address}</div>
                  </div>
                  <div style={{ textAlign:'right',flexShrink:0 }}>
                    {h.available ? (
                      <span style={{ fontSize:'0.72rem',padding:'2px 8px',borderRadius:100,background:'rgba(91,211,199,0.15)',color:'#5bd3c7',fontWeight:600 }}>{h.beds} beds free</span>
                    ) : (
                      <span style={{ fontSize:'0.72rem',padding:'2px 8px',borderRadius:100,background:'rgba(240,98,138,0.12)',color:'var(--accent3)',fontWeight:600 }}>Full</span>
                    )}
                    <div style={{ marginTop:6 }}>
                      <a href={`https://maps.google.com/?q=${encodeURIComponent(h.name)}`} target="_blank" rel="noreferrer" style={{ fontSize:'0.75rem',color:'var(--accent)',textDecoration:'none' }}>Directions →</a>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* First Aid */}
      <div style={{ marginTop:32 }}>
        <h2 style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'1rem',marginBottom:14 }}>Quick First Aid Guide</h2>
        <div style={{ display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))',gap:12 }}>
          {FIRST_AID.map(f=>(
            <div key={f.condition} className="card" style={{ cursor:'pointer',borderColor:selectedFirst===f.condition?'rgba(240,98,138,0.3)':'var(--border)',transition:'all 0.15s' }} onClick={()=>setSelectedFirst(selectedFirst===f.condition?null:f.condition)}>
              <div style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'0.88rem',color:'var(--accent3)',marginBottom:selectedFirst===f.condition?10:0 }}>{f.condition}</div>
              {selectedFirst===f.condition&&(
                <ol style={{ paddingLeft:16,margin:0 }}>
                  {f.steps.map((s,i)=><li key={i} style={{ fontSize:'0.8rem',color:'var(--text2)',marginBottom:5,lineHeight:1.5 }}>{s}</li>)}
                </ol>
              )}
              {selectedFirst!==f.condition&&<div style={{ fontSize:'0.75rem',color:'var(--text3)',marginTop:4 }}>Tap to see steps</div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
