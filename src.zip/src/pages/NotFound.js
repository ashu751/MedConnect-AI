import React from 'react';
import { Link } from 'react-router-dom';
import { Activity, ArrowLeft, Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center',
      justifyContent: 'center', padding: 24, flexDirection: 'column', textAlign: 'center',
      position: 'relative', overflow: 'hidden'
    }}>
      <div className="gradient-orb" style={{ width: 500, height: 500, background: 'radial-gradient(circle, rgba(124,106,247,0.1) 0%, transparent 70%)', top: -150, left: '50%', transform: 'translateX(-50%)' }} />

      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 48 }}>
          <div style={{ width: 40, height: 40, borderRadius: 11, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 20px rgba(124,106,247,0.4)' }}>
            <Activity size={20} color="white" />
          </div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.2rem' }}>MedConnect</span>
        </div>

        {/* 404 */}
        <div style={{
          fontFamily: 'var(--font-display)', fontSize: 'clamp(6rem, 20vw, 10rem)', fontWeight: 800,
          lineHeight: 1, letterSpacing: '-0.04em',
          background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          marginBottom: 16
        }}>404</div>

        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.4rem, 4vw, 2rem)', fontWeight: 700, marginBottom: 12 }}>
          Page not found
        </h1>
        <p style={{ color: 'var(--text3)', fontSize: '1rem', marginBottom: 40, maxWidth: 380, lineHeight: 1.6 }}>
          The page you're looking for doesn't exist or has been moved.
        </p>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
          <button onClick={() => window.history.back()} className="btn btn-secondary" style={{ gap: 8 }}>
            <ArrowLeft size={16} /> Go back
          </button>
          <Link to="/" className="btn btn-primary" style={{ gap: 8 }}>
            <Home size={16} /> Home
          </Link>
        </div>
      </div>
    </div>
  );
}
