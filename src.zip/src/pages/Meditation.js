import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Wind, Brain, Heart } from 'lucide-react';

const SESSIONS = [
  { id: 'breath', title: 'Breathing Focus', duration: 300, color: '#5bd3c7', icon: Wind, desc: 'Follow the breath — in, hold, out. Clears the mind in minutes.', phases: [{ label: 'Inhale', secs: 4 },{ label: 'Hold', secs: 4 },{ label: 'Exhale', secs: 6 },{ label: 'Rest', secs: 2 }] },
  { id: 'relax', title: 'Body Scan', duration: 600, color: '#7c6af7', icon: Brain, desc: 'Progressively relax each muscle group from head to toe.', phases: [{ label: 'Inhale', secs: 4 },{ label: 'Hold', secs: 2 },{ label: 'Exhale', secs: 8 },{ label: 'Rest', secs: 2 }] },
  { id: 'love', title: 'Loving Kindness', duration: 480, color: '#f0628a', icon: Heart, desc: 'Cultivate compassion for yourself and others.', phases: [{ label: 'Breathe In', secs: 5 },{ label: 'Hold', secs: 3 },{ label: 'Breathe Out', secs: 7 },{ label: 'Pause', secs: 1 }] },
];

const CUES = {
  breath: ['Sit comfortably. Close your eyes gently.','Focus on the sensation of breathing.','Notice the air entering your nostrils.','Let each breath be natural and easy.','If your mind wanders, gently return to the breath.','You are calm. You are present.'],
  relax: ['Find a comfortable position. Let your body settle.','Bring awareness to the top of your head.','Slowly scan down — forehead, jaw, shoulders.','Feel each area soften and release tension.','Continue down through your chest and abdomen.','Your whole body is heavy, warm, and relaxed.'],
  love: ['Place a hand gently over your heart.','Think of someone who makes you smile.','Silently wish them happiness and peace.','Now extend that warmth to yourself.','You deserve kindness. You are enough.','Let compassion fill every breath you take.'],
};

export default function Meditation() {
  const { lang } = useTheme();
  const [selected, setSelected] = useState(null);
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [phaseIdx, setPhaseIdx] = useState(0);
  const [phaseSecs, setPhaseSecs] = useState(0);
  const [cueIdx, setCueIdx] = useState(0);
  const [completed, setCompleted] = useState(false);
  const timerRef = useRef(null);

  const session = selected ? SESSIONS.find(s => s.id === selected) : null;

  useEffect(() => {
    if (!running || !session) return;
    timerRef.current = setInterval(() => {
      setElapsed(prev => {
        const next = prev + 1;
        if (next >= session.duration) { clearInterval(timerRef.current); setRunning(false); setCompleted(true); return session.duration; }
        return next;
      });
      setPhaseSecs(prev => {
        const phase = session.phases[phaseIdx];
        if (prev + 1 >= phase.secs) {
          setPhaseIdx(pi => (pi + 1) % session.phases.length);
          setCueIdx(ci => Math.min(ci + 1, CUES[selected].length - 1));
          return 0;
        }
        return prev + 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, [running, phaseIdx, session, selected]);

  const toggle = () => setRunning(r => !r);
  const reset = () => { clearInterval(timerRef.current); setRunning(false); setElapsed(0); setPhaseIdx(0); setPhaseSecs(0); setCueIdx(0); setCompleted(false); };

  const fmt = (s) => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
  const pct = session ? (elapsed / session.duration) * 100 : 0;
  const breathPct = session ? (phaseSecs / session.phases[phaseIdx]?.secs) * 100 : 0;
  const r = 60;
  const circ = 2 * Math.PI * r;

  if (!selected) return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 800, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Mental Wellness</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('guidedMeditation',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('meditationDesc',lang)}</p>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {SESSIONS.map(s => (
          <div key={s.id} className="card" style={{ cursor: 'pointer', borderColor: `${s.color}20`, transition: 'all 0.2s' }}
            onClick={() => { setSelected(s.id); reset(); }}
            onMouseEnter={e => e.currentTarget.style.borderColor = s.color + '50'}
            onMouseLeave={e => e.currentTarget.style.borderColor = s.color + '20'}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ width: 48, height: 48, borderRadius: 12, background: `${s.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <s.icon size={22} color={s.color} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem', marginBottom: 4 }}>{s.title}</div>
                <div style={{ color: 'var(--text3)', fontSize: '0.85rem' }}>{s.desc}</div>
              </div>
              <div style={{ textAlign: 'right', flexShrink: 0 }}>
                <div style={{ fontFamily: 'var(--font-mono)', color: s.color, fontWeight: 600 }}>{fmt(s.duration)}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text3)' }}>duration</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 600, margin: '0 auto', textAlign: 'center' }}>
      <button onClick={() => { reset(); setSelected(null); }} className="btn btn-ghost" style={{ marginBottom: 24, fontSize: '0.85rem' }}>← Back to sessions</button>
      <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.4rem', marginBottom: 8 }}>{session.title}</h2>

      {completed ? (
        <div style={{ marginTop: 32 }}>
          <div style={{ fontSize: '3rem', marginBottom: 16 }}>🎉</div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.3rem', color: session.color, marginBottom: 8 }}>Session Complete!</h3>
          <p style={{ color: 'var(--text3)', marginBottom: 24 }}>You completed {fmt(session.duration)} of meditation. Take a moment to notice how you feel.</p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <button onClick={reset} className="btn btn-primary"><RotateCcw size={15} /> Repeat</button>
            <button onClick={() => { reset(); setSelected(null); }} className="btn btn-secondary">Try another</button>
          </div>
        </div>
      ) : (
        <>
          {/* Circular timer */}
          <div style={{ position: 'relative', width: 180, height: 180, margin: '32px auto' }}>
            <svg width="180" height="180" style={{ position: 'absolute', top: 0, left: 0, transform: 'rotate(-90deg)' }}>
              <circle cx="90" cy="90" r={r} fill="none" stroke="var(--surface2)" strokeWidth="8" />
              <circle cx="90" cy="90" r={r} fill="none" stroke={session.color} strokeWidth="8" strokeLinecap="round"
                strokeDasharray={circ} strokeDashoffset={circ - (pct / 100) * circ} style={{ transition: 'stroke-dashoffset 1s linear' }} />
            </svg>
            <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.8rem', fontWeight: 700, color: session.color }}>{fmt(session.duration - elapsed)}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text3)' }}>remaining</div>
            </div>
          </div>

          {/* Breath animation */}
          {running && (
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: '0.9rem', fontWeight: 600, color: session.color, marginBottom: 8 }}>{session.phases[phaseIdx].label}</div>
              <div style={{ width: 80, height: 80, borderRadius: '50%', background: `${session.color}20`, border: `2px solid ${session.color}40`, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'center',
                transform: `scale(${0.7 + (breathPct / 100) * 0.6})`, transition: 'transform 1s linear', boxShadow: `0 0 ${20 + breathPct/5}px ${session.color}30` }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: session.color, opacity: 0.6 }} />
              </div>
            </div>
          )}

          {/* Cue text */}
          <div style={{ minHeight: 52, marginBottom: 24 }}>
            <p style={{ color: 'var(--text2)', fontSize: '1rem', lineHeight: 1.6, fontStyle: 'italic' }}>"{CUES[selected][cueIdx]}"</p>
          </div>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <button onClick={toggle} className="btn btn-primary" style={{ padding: '12px 28px' }}>
              {running ? <><Pause size={16} /> Pause</> : <><Play size={16} /> {elapsed === 0 ? 'Begin' : 'Resume'}</>}
            </button>
            <button onClick={reset} className="btn btn-ghost"><RotateCcw size={15} /></button>
          </div>
        </>
      )}
    </div>
  );
}
