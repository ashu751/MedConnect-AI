import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import React, { useState, useEffect } from 'react';
import { Flame, Award, Calendar, Plus, CheckCircle, RotateCcw } from 'lucide-react';

const STORAGE_KEY = 'mc_streaks';
const BADGE_THRESHOLDS = [3, 7, 14, 21, 30, 60, 100];

const DEFAULT_HABITS = [
  { id: 'water', name: 'Drink 8 glasses of water', icon: '💧', color: '#5bd3c7' },
  { id: 'exercise', name: 'Exercise 30 minutes', icon: '🏃', color: '#f5a623' },
  { id: 'sleep', name: 'Sleep 8 hours', icon: '😴', color: '#7c6af7' },
  { id: 'meditate', name: 'Meditate', icon: '🧘', color: '#f0628a' },
  { id: 'noJunk', name: 'No junk food', icon: '🥗', color: '#9fe87a' },
];

function getStreak(history) {
  if (!history || history.length === 0) return 0;
  const sorted = [...history].sort((a,b) => new Date(b) - new Date(a));
  let streak = 0;
  let current = new Date(); current.setHours(0,0,0,0);
  for (const d of sorted) {
    const date = new Date(d); date.setHours(0,0,0,0);
    const diff = Math.round((current - date) / 86400000);
    if (diff === 0 || diff === 1) { streak++; current = date; } else break;
  }
  return streak;
}

function getBadge(streak) {
  const earned = BADGE_THRESHOLDS.filter(t => streak >= t);
  return earned.length ? earned[earned.length - 1] : null;
}

export default function StreakTracker() {
  const { lang } = useTheme();
  const [data, setData] = useState(() => JSON.parse(localStorage.getItem(STORAGE_KEY) || JSON.stringify(DEFAULT_HABITS.reduce((a,h) => ({...a,[h.id]:{...h,history:[]}}),{}))));
  const [customName, setCustomName] = useState('');
  const [customIcon, setCustomIcon] = useState('⭐');

  const save = (d) => { setData(d); localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); };

  const markToday = (id) => {
    const today = new Date().toDateString();
    const habit = data[id];
    if (habit.history.includes(today)) return;
    save({ ...data, [id]: { ...habit, history: [today, ...habit.history] }});
  };

  const addCustom = () => {
    if (!customName.trim()) return;
    const id = 'custom_' + Date.now();
    save({ ...data, [id]: { id, name: customName.trim(), icon: customIcon, color: '#7c6af7', history: [] }});
    setCustomName(''); setCustomIcon('⭐');
  };

  const remove = (id) => {
    const next = {...data}; delete next[id]; save(next);
  };

  const habits = Object.values(data);
  const today = new Date().toDateString();
  const doneToday = habits.filter(h => h.history.includes(today)).length;

  return (
    <div style={{ padding: 'clamp(20px,4vw,40px)', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <p className="prose-label" style={{ marginBottom: 8 }}>Consistency</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>{t('streakTrackerTitle',lang)}</h1>
        <p style={{ color: 'var(--text3)' }}>{t('streakTrackerDesc',lang)}</p>
      </div>

      {/* Today summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 28 }}>
        <div className="card" style={{ padding: 16, textAlign: 'center' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>Done today</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 800, color: '#f5a623' }}>{doneToday}/{habits.length}</div>
        </div>
        <div className="card" style={{ padding: 16, textAlign: 'center' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>Best streak</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 800, color: '#f0628a' }}>
            {Math.max(...habits.map(h => getStreak(h.history)), 0)} <span style={{ fontSize: '1.2rem' }}>🔥</span>
          </div>
        </div>
        <div className="card" style={{ padding: 16, textAlign: 'center' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>Habits tracked</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 800, color: 'var(--accent)' }}>{habits.length}</div>
        </div>
      </div>

      {/* Habits grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(260px,1fr))', gap: 16, marginBottom: 24 }}>
        {habits.map(h => {
          const streak = getStreak(h.history);
          const badge = getBadge(streak);
          const doneNow = h.history.includes(today);
          return (
            <div key={h.id} className="card" style={{ borderColor: doneNow ? `${h.color}30` : 'var(--border)', transition: 'all 0.2s' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: '1.4rem' }}>{h.icon}</span>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{h.name}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
                      <Flame size={13} color={streak > 0 ? '#f5a623' : 'var(--text3)'} />
                      <span style={{ fontSize: '0.78rem', color: streak > 0 ? '#f5a623' : 'var(--text3)', fontWeight: 700 }}>{streak} day streak</span>
                    </div>
                  </div>
                </div>
                <button onClick={() => remove(h.id)} style={{ background:'none',border:'none',color:'var(--text3)',cursor:'pointer',padding:4,fontSize:'0.75rem' }}>✕</button>
              </div>

              {badge && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 100, background: `${h.color}15`, border: `1px solid ${h.color}25`, marginBottom: 10, width: 'fit-content' }}>
                  <Award size={12} color={h.color} />
                  <span style={{ fontSize: '0.7rem', color: h.color, fontWeight: 700 }}>{badge}-day badge! 🏆</span>
                </div>
              )}

              {/* Last 7 days */}
              <div style={{ display: 'flex', gap: 4, marginBottom: 12 }}>
                {Array.from({length:7},(_,i)=>{
                  const d = new Date(); d.setDate(d.getDate() - (6-i));
                  const done = h.history.includes(d.toDateString());
                  return <div key={i} title={d.toDateString()} style={{ flex:1,height:24,borderRadius:4,background:done?h.color:'var(--surface2)',opacity:done?1:0.4,transition:'all 0.2s' }} />;
                })}
              </div>

              <button onClick={() => markToday(h.id)} disabled={doneNow} className={doneNow ? 'btn' : 'btn btn-secondary'} style={{ width:'100%',justifyContent:'center',fontSize:'0.85rem',padding:'8px',background:doneNow?`${h.color}12`:'',color:doneNow?h.color:'',border:doneNow?`1px solid ${h.color}25`:'' }}>
                {doneNow ? <><CheckCircle size={14}/> Done today!</> : 'Mark as done today'}
              </button>
            </div>
          );
        })}
      </div>

      {/* Add custom */}
      <div className="card">
        <h3 style={{ fontFamily:'var(--font-display)',fontWeight:700,fontSize:'0.9rem',marginBottom:14 }}>Add Custom Habit</h3>
        <div style={{ display:'flex',gap:10 }}>
          <input value={customIcon} onChange={e=>setCustomIcon(e.target.value)} style={{ width:56,textAlign:'center',fontSize:'1.2rem' }} />
          <input value={customName} onChange={e=>setCustomName(e.target.value)} placeholder="Habit name..." style={{ flex:1 }} onKeyDown={e=>e.key==='Enter'&&addCustom()} />
          <button onClick={addCustom} disabled={!customName.trim()} className="btn btn-primary" style={{ flexShrink:0 }}><Plus size={15}/>Add</button>
        </div>
      </div>
    </div>
  );
}
