import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { t } from '../utils/translations';
import {
  LayoutDashboard, Stethoscope, Brain, MapPin, BarChart3,
  LogOut, Menu, X, ChevronRight, Activity, ScanLine,
  Pill, TrendingUp, Target, Shield, Calendar, Phone,
  Flame, Apple, Wind, BookOpen, BarChart, FileText,
  Sun, Moon, Globe, Bell, ChevronDown
} from 'lucide-react';

const buildNav = (lang) => [
  { label: t('overview', lang), items: [
    { path: '/dashboard', icon: LayoutDashboard, labelKey: 'dashboard', color: '#7c6af7' },
  ]},
  { label: t('aiTools', lang), items: [
    { path: '/medical-ai', icon: Stethoscope, labelKey: 'aiDoctor', color: '#5bd3c7' },
    { path: '/prescription', icon: ScanLine, labelKey: 'rxScanner', color: '#5bd3c7' },
    { path: '/symptoms', icon: TrendingUp, labelKey: 'symptomTracker', color: '#f5a623' },
  ]},
  { label: t('myHealth', lang), items: [
    { path: '/medicines', icon: Pill, labelKey: 'medicineReminder', color: '#f0628a' },
    { path: '/bmi', icon: Activity, labelKey: 'bmiCalculator', color: '#5bd3c7' },
    { path: '/goals', icon: Target, labelKey: 'healthGoals', color: '#9fe87a' },
    { path: '/vaccines', icon: Shield, labelKey: 'vaccination', color: '#7c6af7' },
    { path: '/streaks', icon: Flame, labelKey: 'streakTracker', color: '#f5a623' },
    { path: '/calories', icon: Apple, labelKey: 'calorieWater', color: '#9fe87a' },
  ]},
  { label: t('mentalWellnessNav', lang), items: [
    { path: '/mental-health', icon: Brain, labelKey: 'mentalHealth', color: '#f0628a' },
    { path: '/meditation', icon: Wind, labelKey: 'meditation', color: '#5bd3c7' },
    { path: '/journal', icon: BookOpen, labelKey: 'journal', color: '#7c6af7' },
    { path: '/stress-test', icon: BarChart, labelKey: 'stressTest', color: '#f5a623' },
  ]},
  { label: t('hospitalsNav', lang), items: [
    { path: '/hospitals', icon: MapPin, labelKey: 'hospitals', color: '#f5a623' },
    { path: '/appointment', icon: Calendar, labelKey: 'appointment', color: '#5bd3c7' },
    { path: '/ambulance', icon: Phone, labelKey: 'emergency', color: '#f0628a' },
  ]},
  { label: t('analyticsNav', lang), items: [
    { path: '/analytics', icon: BarChart3, labelKey: 'analytics', color: '#7c6af7' },
    { path: '/report', icon: FileText, labelKey: 'healthReport', color: '#5bd3c7' },
  ]},
];

function useNotifications() {
  const [notifs, setNotifs] = useState([]);
  useEffect(() => {
    const meds = JSON.parse(localStorage.getItem('mc_medicine_reminders') || '[]');
    const today = new Date().toDateString();
    const taken = JSON.parse(localStorage.getItem('mc_taken_' + today) || '{}');
    const due = meds.filter(m => !taken[m.id]);
    if (due.length > 0) setNotifs([{ id: 1, text: `${due.length} medicine${due.length > 1 ? 's' : ''} to take`, link: '/medicines' }]);
  }, []);
  return notifs;
}

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const { theme, toggleTheme, lang, toggleLang } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsedSections, setCollapsedSections] = useState({});
  const notifs = useNotifications();

  const handleLogout = () => { logout(); navigate('/'); };
  const toggleSection = (label) => setCollapsedSections(s => ({ ...s, [label]: !s[label] }));
  const navSections = buildNav(lang);

  const SidebarContent = ({ mobile = false }) => (
    <aside style={{
      width: collapsed && !mobile ? 72 : 260, minHeight: '100vh',
      background: 'var(--bg2)', borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column', transition: 'width 0.25s', flexShrink: 0,
      ...(mobile ? { position: 'fixed', inset: '0 auto 0 0', zIndex: 100, width: 280 } : {})
    }}>
      {/* Logo */}
      <div style={{ padding: '20px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, boxShadow: '0 0 14px rgba(124,106,247,0.4)' }}>
          <Activity size={16} color="white" />
        </div>
        {(!collapsed || mobile) && <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.05rem' }}>MedConnect</span>}
        {!mobile && (
          <button onClick={() => setCollapsed(!collapsed)} className="btn btn-ghost" style={{ marginLeft: 'auto', padding: 5 }}>
            <ChevronRight size={15} style={{ transform: collapsed ? 'rotate(0)' : 'rotate(180deg)', transition: 'transform 0.2s' }} />
          </button>
        )}
        {mobile && <button onClick={() => setMobileOpen(false)} className="btn btn-ghost" style={{ marginLeft: 'auto', padding: 5 }}><X size={17} /></button>}
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '12px 10px', overflowY: 'auto' }}>
        {navSections.map(section => (
          <div key={section.label} style={{ marginBottom: 4 }}>
            {(!collapsed || mobile) && (
              <button onClick={() => toggleSection(section.label)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', padding: '5px 10px', background: 'none', border: 'none', color: 'var(--text3)', fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', cursor: 'pointer', fontFamily: 'var(--font-mono)' }}>
                {section.label}
                <ChevronDown size={11} style={{ transform: collapsedSections[section.label] ? 'rotate(-90deg)' : 'rotate(0)', transition: 'transform 0.2s' }} />
              </button>
            )}
            {!collapsedSections[section.label] && section.items.map(item => {
              const active = location.pathname === item.path;
              return (
                <Link key={item.path} to={item.path} onClick={() => setMobileOpen(false)} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '8px 10px', borderRadius: 8, marginBottom: 2,
                  background: active ? `${item.color}15` : 'transparent',
                  border: active ? `1px solid ${item.color}25` : '1px solid transparent',
                  color: active ? item.color : 'var(--text2)',
                  fontWeight: active ? 600 : 400, fontSize: '0.85rem',
                  transition: 'all 0.15s', whiteSpace: 'nowrap', overflow: 'hidden'
                }}>
                  <item.icon size={16} style={{ flexShrink: 0 }} />
                  {(!collapsed || mobile) && <span>{t(item.labelKey, lang)}</span>}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Bottom */}
      <div style={{ padding: '12px 10px', borderTop: '1px solid var(--border)' }}>
        {(!collapsed || mobile) && (
          <>
            <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
              <button onClick={toggleTheme} className="btn btn-ghost" style={{ flex: 1, justifyContent: 'center', padding: '7px', borderRadius: 8, border: '1px solid var(--border2)', fontSize: '0.78rem', gap: 5 }}>
                {theme === 'dark' ? <><Sun size={13} /> {t('light', lang)}</> : <><Moon size={13} /> {t('dark', lang)}</>}
              </button>
              <button onClick={toggleLang} className="btn btn-ghost" style={{ flex: 1, justifyContent: 'center', padding: '7px', borderRadius: 8, border: '1px solid var(--border2)', fontSize: '0.78rem', gap: 5 }}>
                <Globe size={13} /> {lang === 'en' ? 'हिंदी' : 'English'}
              </button>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, padding: '8px 10px', background: 'var(--surface)', borderRadius: 8 }}>
              <div style={{ width: 30, height: 30, borderRadius: 7, background: 'linear-gradient(135deg,var(--accent),var(--accent2))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.85rem', flexShrink: 0, color: 'white' }}>
                {user?.name?.charAt(0).toUpperCase()}
              </div>
              <div style={{ overflow: 'hidden' }}>
                <div style={{ fontWeight: 600, fontSize: '0.82rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.name}</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.email}</div>
              </div>
            </div>
          </>
        )}
        <button onClick={handleLogout} className="btn btn-ghost" style={{ width: '100%', justifyContent: collapsed && !mobile ? 'center' : 'flex-start', padding: '8px 10px', borderRadius: 8, color: 'var(--accent3)', fontSize: '0.85rem' }}>
          <LogOut size={16} style={{ flexShrink: 0 }} />
          {(!collapsed || mobile) && <span>{t('signOut', lang)}</span>}
        </button>
      </div>
    </aside>
  );

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg)' }}>
      <div className="desktop-sidebar"><SidebarContent /></div>
      {mobileOpen && (
        <>
          <div onClick={() => setMobileOpen(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 99 }} />
          <SidebarContent mobile />
        </>
      )}
      <main style={{ flex: 1, minWidth: 0, overflow: 'auto' }}>
        <div className="mobile-topbar" style={{ display: 'none', padding: '12px 16px', borderBottom: '1px solid var(--border)', alignItems: 'center', gap: 12, background: 'var(--bg2)', position: 'sticky', top: 0, zIndex: 10 }}>
          <button onClick={() => setMobileOpen(true)} className="btn btn-ghost" style={{ padding: 7 }}><Menu size={20} /></button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 26, height: 26, borderRadius: 7, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Activity size={13} color="white" /></div>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '0.95rem' }}>MedConnect</span>
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <button onClick={toggleTheme} className="btn btn-ghost" style={{ padding: 7 }}>{theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}</button>
            <button onClick={toggleLang} className="btn btn-ghost" style={{ padding: 7, fontSize: '0.78rem' }}>{lang === 'en' ? 'हि' : 'En'}</button>
            {notifs.length > 0 && (
              <Link to="/medicines" style={{ position: 'relative', display: 'flex', alignItems: 'center', padding: 7, borderRadius: 6, color: 'var(--text2)' }}>
                <Bell size={16} />
                <div style={{ position: 'absolute', top: 4, right: 4, width: 8, height: 8, borderRadius: '50%', background: 'var(--accent3)' }} />
              </Link>
            )}
          </div>
        </div>
        <div key={location.pathname} className="page-enter" style={{ minHeight: '100vh' }}>
          {children}
        </div>
      </main>
      <style>{`
        @media (max-width: 768px) {
          .desktop-sidebar { display: none !important; }
          .mobile-topbar { display: flex !important; }
        }
      `}</style>
    </div>
  );
}
