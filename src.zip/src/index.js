import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// Feature 16: Push notifications via browser Notification API
if ('Notification' in window && 'serviceWorker' in navigator) {
  // Request permission on load (after user interaction would be better, but this is a demo)
  setTimeout(() => {
    if (Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, 3000);

  // Schedule medicine reminders
  function checkMedicineReminders() {
    if (Notification.permission !== 'granted') return;
    const meds = JSON.parse(localStorage.getItem('mc_medicine_reminders') || '[]');
    const today = new Date().toDateString();
    const taken = JSON.parse(localStorage.getItem('mc_taken_' + today) || '{}');
    const now = new Date();
    const currentTime = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    meds.forEach(med => {
      if (!taken[med.id] && med.time === currentTime) {
        new Notification('💊 Medicine Reminder — MedConnect', {
          body: `Time to take ${med.name} ${med.dose} (${med.freq})`,
          icon: '/favicon.ico',
          tag: `med-${med.id}`,
        });
      }
    });
  }

  // Check every minute
  setInterval(checkMedicineReminders, 60000);
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<React.StrictMode><App /></React.StrictMode>);
