import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import MedicalAI from './pages/MedicalAI';
import MentalHealth from './pages/MentalHealth';
import HospitalFinder from './pages/HospitalFinder';
import HealthAnalytics from './pages/HealthAnalytics';
import PrescriptionScanner from './pages/PrescriptionScanner';
import SymptomTracker from './pages/SymptomTracker';
import MedicineReminder from './pages/MedicineReminder';
import BMICalculator from './pages/BMICalculator';
import HealthGoals from './pages/HealthGoals';
import VaccinationTracker from './pages/VaccinationTracker';
import AppointmentBooking from './pages/AppointmentBooking';
import AmbulanceFinder from './pages/AmbulanceFinder';
import HealthReport from './pages/HealthReport';
import StreakTracker from './pages/StreakTracker';
import CalorieTracker from './pages/CalorieTracker';
import Meditation from './pages/Meditation';
import Journal from './pages/Journal';
import StressTest from './pages/StressTest';
import NotFound from './pages/NotFound';
import Layout from './components/Layout';

function PrivateRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
      <div className="spinner" />
    </div>
  );
  return user ? children : <Navigate to="/login" />;
}

function AppRoutes() {
  const { user } = useAuth();
  const wrap = (Component) => (
    <PrivateRoute><Layout><Component /></Layout></PrivateRoute>
  );
  return (
    <Routes>
      <Route path="/" element={user ? <Navigate to="/dashboard" /> : <LandingPage />} />
      <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <AuthPage />} />
      <Route path="/dashboard" element={wrap(Dashboard)} />
      <Route path="/medical-ai" element={wrap(MedicalAI)} />
      <Route path="/prescription" element={wrap(PrescriptionScanner)} />
      <Route path="/symptoms" element={wrap(SymptomTracker)} />
      <Route path="/medicines" element={wrap(MedicineReminder)} />
      <Route path="/bmi" element={wrap(BMICalculator)} />
      <Route path="/goals" element={wrap(HealthGoals)} />
      <Route path="/vaccines" element={wrap(VaccinationTracker)} />
      <Route path="/mental-health" element={wrap(MentalHealth)} />
      <Route path="/meditation" element={wrap(Meditation)} />
      <Route path="/journal" element={wrap(Journal)} />
      <Route path="/stress-test" element={wrap(StressTest)} />
      <Route path="/hospitals" element={wrap(HospitalFinder)} />
      <Route path="/appointment" element={wrap(AppointmentBooking)} />
      <Route path="/ambulance" element={wrap(AmbulanceFinder)} />
      <Route path="/analytics" element={wrap(HealthAnalytics)} />
      <Route path="/report" element={wrap(HealthReport)} />
      <Route path="/streaks" element={wrap(StreakTracker)} />
      <Route path="/calories" element={wrap(CalorieTracker)} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
