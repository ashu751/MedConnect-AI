// Simple SHA-256 password hashing using Web Crypto API (built into all modern browsers)
// No external dependencies needed

export async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'mc_salt_2024'); // salted
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyPassword(password, hash) {
  const hashed = await hashPassword(password);
  return hashed === hash;
}
