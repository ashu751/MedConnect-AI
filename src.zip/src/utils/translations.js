export const T = {
  en: {
    // Nav sections
    overview: 'Overview', aiTools: 'AI Tools', myHealth: 'My Health',
    mentalWellnessNav: 'Mental Wellness', hospitalsNav: 'Hospitals & Emergency', analyticsNav: 'Analytics',
    // Nav items
    dashboard: 'Dashboard', aiDoctor: 'AI Doctor', rxScanner: 'Rx Scanner',
    symptomTracker: 'Symptom Tracker', medicineReminder: 'Medicine Reminder',
    bmiCalculator: 'BMI Calculator', healthGoals: 'Health Goals', vaccination: 'Vaccination',
    streakTracker: 'Streak Tracker', calorieWater: 'Calorie & Water',
    mentalHealth: 'Mental Health', meditation: 'Meditation', journal: 'Journal',
    stressTest: 'Stress Test', hospitals: 'Hospital Finder', appointment: 'Book Appointment',
    emergency: 'Emergency / 108', analytics: 'Analytics', healthReport: 'Health Report',
    signOut: 'Sign out', light: 'Light', dark: 'Dark',
    // Dashboard
    welcomeBack: 'Welcome back', healthOverview: "Here's your health overview for today.",
    tipOfDay: 'Tip of the Day', healthScore: 'Health Score', mentalWellness: 'Mental Wellness',
    consultations: 'AI Consultations', memberSince: 'Member Since', days: 'days', day: 'day',
    sessions: 'sessions', session: 'session', getStarted: 'Get started with MedConnect',
    getStartedDesc: 'You have 18+ health tools available. Start by logging your mood, scanning a prescription, or asking the AI Doctor a question.',
    start: 'Start', logDataToStart: 'Log health data to start', logDataImprove: 'Log data to improve',
    trackFirstMood: 'Track your first mood', askFirstQuestion: 'Ask your first question', keepGoing: 'Keep going!',
    welcome: 'Welcome! 🎉', joinedOn: 'Joined', goodShape: 'Good shape', stable: 'Stable',
    // AI Doctor
    aiMedicalAssistant: 'AI Medical Assistant', newChat: 'New chat', demoMode: 'Demo Mode',
    describeSymptoms: 'Describe your symptoms or ask a health question...',
    disclaimer: 'AI responses are for informational purposes only. Always consult a healthcare professional for medical decisions.',
    // Prescription Scanner
    prescriptionScanner: 'Prescription Scanner', uploadPrescription: 'Drop prescription image here',
    uploadDesc: 'or click to browse — JPG, PNG, WEBP up to 10MB', analyzeWithAI: 'Analyze with AI',
    analysisResult: 'Analysis Result', newScan: 'New scan', tipsForBestResults: 'Tips for best results',
    imageReady: 'Image ready for analysis', uploadDifferent: 'Upload different image',
    // Symptom Tracker
    symptomPatternTracker: 'Symptom Pattern Tracker', symptomTrackerDesc: 'Log symptoms over time — AI detects recurring patterns.',
    recurringPatterns: 'Recurring Patterns Detected', logSymptom: 'Log a Symptom',
    chooseSymptom: 'Choose symptom', selectFromList: '— Select from list —',
    customSymptom: 'Or type a custom symptom...', severity: 'Severity',
    mild: 'Mild', moderate: 'Moderate', severe: 'Severe',
    notes: 'Notes (optional)', additionalContext: 'Any additional context...',
    history: 'History', entries: 'entries', noSymptomsYet: 'No symptoms logged yet.',
    addFirstEntry: 'Add your first entry to start tracking.',
    // Medicine Reminder
    medicineReminderTitle: 'Medicine Reminder', medicineReminderDesc: 'Track your medications, dosages, and get interaction warnings.',
    interactionWarning: 'Interaction Warning', activeMedications: 'active medication',
    addMedicine: 'Add Medicine', newMedication: 'New Medication', medicineName: 'Medicine Name',
    dosage: 'Dosage', frequency: 'Frequency', reminderTime: 'Reminder Time',
    startDate: 'Start Date', duration: 'Duration (days)', saveMedicine: 'Save Medicine',
    noMedicinesYet: 'No medicines added yet. Add your first medication above.',
    markTaken: 'Mark as taken', takenToday: 'Taken today', completed: 'Completed',
    // BMI Calculator
    bmiCalculatorTitle: 'BMI Calculator', bmiDesc: 'Calculate your Body Mass Index with a visual gauge.',
    metric: 'metric', imperial: 'imperial', heightCm: 'Height (cm)', weightKg: 'Weight (kg)',
    feet: 'Feet', inches: 'Inches', weightLbs: 'Weight (lbs)', age: 'Age (optional)',
    gender: 'Gender (optional)', calculateBMI: 'Calculate BMI', bmiReference: 'BMI Reference',
    underweight: 'Underweight', normalWeight: 'Normal weight', overweight: 'Overweight', obese: 'Obese',
    yourBMI: 'Your BMI', idealWeightRange: 'Ideal Weight Range', healthInsight: 'Health Insight',
    // Health Goals
    healthGoalsTitle: 'Health Goals', healthGoalsDesc: 'Set daily health targets and track your progress.',
    doneToday: 'Done today', completion: 'Completion', activeGoals: 'Active Goals',
    quickAdd: 'Quick Add', custom: 'Custom', goalName: 'Goal name...', target: 'Target',
    addCustomGoal: 'Add Custom Goal', noGoalsYet: 'No goals yet. Add some from the quick-add options above!',
    markAsDone: 'Mark as done today', tracking: 'tracking',
    // Vaccination
    vaccinationRecords: 'Vaccination Records', vaccinationDesc: 'Track your immunization history and get reminders.',
    standardSchedule: 'Standard Schedule', myRecords: 'My Records', logVaccination: 'Log Vaccination',
    dateReceived: 'Date received', doseNumber: 'Dose #', nextDue: 'Next due (opt.)',
    provider: 'Provider', noRecordsYet: 'No records yet. Log your vaccinations from the schedule.',
    saveRecord: 'Save Record',
    // Streak Tracker
    streakTrackerTitle: 'Streak Tracker', streakTrackerDesc: 'Build healthy habits with daily streaks and milestone badges.',
    bestStreak: 'Best streak', habitsTracked: 'Habits tracked', addCustomHabit: 'Add Custom Habit',
    habitName: 'Habit name...', dayStreak: 'day streak', doneToday2: 'Done today!',
    // Calorie Tracker
    calorieTrackerTitle: 'Calorie & Water Tracker', calorieTrackerDesc: 'Log your meals and water intake. Resets daily.',
    calories: 'Calories', protein: 'Protein', carbs: 'Carbs', fat: 'Fat', water: 'Water',
    dailyCalorieGoal: 'Daily calorie goal', overGoalBy: 'Over goal by', logFood: 'Log Food',
    searchFoods: 'Search Indian foods...', customFood: 'Custom food', foodName: 'Food name',
    addCustom: 'Add custom', todaysLog: "Today's Log", noFoodLogged: 'No food logged yet today.',
    glassOfWater: '+ Glass', reset: 'Reset', waterIntake: 'Water intake',
    // Mental Health
    mentalHealthTitle: 'Mental Health Companion', moodTracker: 'Daily Mood Tracker',
    howAreYouFeeling: 'How are you feeling today?', logMood: 'Log Mood', moodHistory: 'Mood History',
    noMoodLogged: 'No mood entries yet.', breathingExercise: 'Breathing Exercise',
    aiSupport: 'AI Support Chat',
    // Meditation
    guidedMeditation: 'Guided Meditation', meditationDesc: 'Choose a session. Find a quiet space and sit comfortably.',
    duration: 'duration', sessionComplete: 'Session Complete!', repeat: 'Repeat', tryAnother: 'Try another',
    begin: 'Begin', pause: 'Pause', resume: 'Resume', backToSessions: '← Back to sessions',
    // Journal
    dailyJournal: 'Daily Journal', journalDesc: 'Write freely — AI analyzes the sentiment and gives you a supportive reflection.',
    todaysEntry: "Today's Entry", entryTitle: 'Entry title (optional)...', howAreYou: 'How are you feeling today?...',
    saveAndAnalyze: 'Save & Analyze', analyzing: 'Analyzing...', pastEntries: 'Past Entries',
    noEntriesYet: 'No entries yet. Write your first journal entry!', aiInsight: 'AI Insight',
    // Stress Test
    stressLevelTest: 'Stress Level Test', stressTestDesc: 'Based on the Perceived Stress Scale (PSS-10).',
    questionOf: 'Question', of: 'of', answered: 'answered', seeResults: 'See Results',
    retakeTest: 'Retake Test', outOf: 'out of', personalizedTips: 'Personalized Tips',
    lowStress: 'Low Stress', moderateStress: 'Moderate Stress', highStress: 'High Stress',
    never: 'Never', almostNever: 'Almost Never', sometimes: 'Sometimes', fairlyOften: 'Fairly Often', veryOften: 'Very Often',
    inTheLastMonth: 'In the last month,',
    // Hospital Finder
    hospitalFinder: 'Hospital Finder', hospitalFinderDesc: 'Find nearby hospitals and clinics with real-time data.',
    findNearbyHospitals: 'Find Nearby Hospitals', detectLocation: 'Detect My Location',
    detecting: 'Detecting...', openNow: 'Open Now', closed: 'Closed', getDirections: 'Get Directions',
    // Appointment
    bookAppointment: 'Book Appointment', bookAppointmentDesc: 'Find a doctor, pick a slot, and book your consultation.',
    chooseSpecialty: 'Choose Specialty', chooseDoctor: 'Choose Doctor', scheduleDateAndTime: 'Choose Date & Time',
    patientDetails: 'Patient Details', fullName: 'Full Name', phone: 'Phone',
    reasonForVisit: 'Reason for visit', bookingSummary: 'Booking Summary', confirmAppointment: 'Confirm Appointment',
    appointmentConfirmed: 'Appointment Confirmed!', bookAnother: 'Book Another', yourAppointments: 'Your Appointments',
    // Ambulance
    emergencyAmbulance: 'Emergency & Ambulance', emergencyDesc: 'Quick access to emergency numbers and first aid.',
    medicalEmergency: 'Medical Emergency?', callAmbulance: 'Call 108', emergencyNumbers: 'Emergency Numbers',
    nearestHospitals: 'Nearest Hospitals', getLocation: 'Get location', located: 'Located ✓',
    quickFirstAid: 'Quick First Aid Guide', tapToSeeSteps: 'Tap to see steps', bedsFree: 'beds free', full: 'Full',
    // Health Report
    healthReportTitle: 'Health Report', healthReportDesc: 'Generate a complete health summary for your doctor.',
    reportContents: 'Report Contents', downloadReport: 'Download HTML Report', print: 'Print',
    generating: 'Generating...',
    // Common
    save: 'Save', cancel: 'Cancel', add: 'Add', back: '← Back', loading: 'Loading...',
    noData: 'No data yet', analyze2: 'Analyze', submit: 'Submit', optional: 'optional',
    today: 'Today', yesterday: 'Yesterday', priority: 'PRIORITY', directions: 'Directions →',
    inLastMonth: 'In the last month,',
  },

  hi: {
    // Nav sections
    overview: 'अवलोकन', aiTools: 'AI टूल्स', myHealth: 'मेरा स्वास्थ्य',
    mentalWellnessNav: 'मानसिक स्वास्थ्य', hospitalsNav: 'अस्पताल और आपातकाल', analyticsNav: 'विश्लेषण',
    // Nav items
    dashboard: 'डैशबोर्ड', aiDoctor: 'AI डॉक्टर', rxScanner: 'Rx स्कैनर',
    symptomTracker: 'लक्षण ट्रैकर', medicineReminder: 'दवा रिमाइंडर',
    bmiCalculator: 'BMI कैलकुलेटर', healthGoals: 'स्वास्थ्य लक्ष्य', vaccination: 'टीकाकरण',
    streakTracker: 'स्ट्रीक ट्रैकर', calorieWater: 'कैलोरी और पानी',
    mentalHealth: 'मानसिक स्वास्थ्य', meditation: 'ध्यान', journal: 'डायरी',
    stressTest: 'तनाव परीक्षण', hospitals: 'अस्पताल खोजें', appointment: 'अपॉइंटमेंट',
    emergency: 'आपातकाल / 108', analytics: 'विश्लेषण', healthReport: 'स्वास्थ्य रिपोर्ट',
    signOut: 'साइन आउट', light: 'लाइट', dark: 'डार्क',
    // Dashboard
    welcomeBack: 'वापसी पर स्वागत है', healthOverview: 'आज का आपका स्वास्थ्य अवलोकन।',
    tipOfDay: 'आज की टिप', healthScore: 'स्वास्थ्य स्कोर', mentalWellness: 'मानसिक स्वास्थ्य',
    consultations: 'AI परामर्श', memberSince: 'सदस्य', days: 'दिन', day: 'दिन',
    sessions: 'सत्र', session: 'सत्र', getStarted: 'MedConnect शुरू करें',
    getStartedDesc: 'आपके पास 18+ स्वास्थ्य उपकरण हैं। मूड ट्रैक करें, प्रिस्क्रिप्शन स्कैन करें, या AI डॉक्टर से पूछें।',
    start: 'शुरू करें', logDataToStart: 'स्वास्थ्य डेटा लॉग करें', logDataImprove: 'डेटा लॉग करें',
    trackFirstMood: 'पहला मूड ट्रैक करें', askFirstQuestion: 'पहला सवाल पूछें', keepGoing: 'जारी रखें!',
    welcome: 'स्वागत है! 🎉', joinedOn: 'जुड़े', goodShape: 'अच्छी स्थिति', stable: 'स्थिर',
    // AI Doctor
    aiMedicalAssistant: 'AI चिकित्सा सहायक', newChat: 'नई चैट', demoMode: 'डेमो मोड',
    describeSymptoms: 'अपने लक्षण बताएं या स्वास्थ्य प्रश्न पूछें...',
    disclaimer: 'AI उत्तर केवल जानकारी के लिए हैं। चिकित्सा निर्णयों के लिए डॉक्टर से मिलें।',
    // Prescription Scanner
    prescriptionScanner: 'प्रिस्क्रिप्शन स्कैनर', uploadPrescription: 'प्रिस्क्रिप्शन की फोटो यहाँ डालें',
    uploadDesc: 'या ब्राउज़ करें — JPG, PNG, WEBP 10MB तक', analyzeWithAI: 'AI से विश्लेषण करें',
    analysisResult: 'विश्लेषण परिणाम', newScan: 'नया स्कैन', tipsForBestResults: 'बेहतर परिणाम के लिए टिप्स',
    imageReady: 'फोटो विश्लेषण के लिए तैयार', uploadDifferent: 'अलग फोटो अपलोड करें',
    // Symptom Tracker
    symptomPatternTracker: 'लक्षण पैटर्न ट्रैकर', symptomTrackerDesc: 'समय के साथ लक्षण लॉग करें — AI पैटर्न पहचानता है।',
    recurringPatterns: 'बार-बार आने वाले लक्षण मिले', logSymptom: 'लक्षण लॉग करें',
    chooseSymptom: 'लक्षण चुनें', selectFromList: '— सूची से चुनें —',
    customSymptom: 'या अपना लक्षण टाइप करें...', severity: 'गंभीरता',
    mild: 'हल्का', moderate: 'मध्यम', severe: 'गंभीर',
    notes: 'नोट्स (वैकल्पिक)', additionalContext: 'अतिरिक्त जानकारी...',
    history: 'इतिहास', entries: 'प्रविष्टियाँ', noSymptomsYet: 'अभी कोई लक्षण लॉग नहीं हुआ।',
    addFirstEntry: 'पहली प्रविष्टि जोड़ें।',
    // Medicine Reminder
    medicineReminderTitle: 'दवा रिमाइंडर', medicineReminderDesc: 'दवाएं, खुराक, और इंटरेक्शन चेतावनी ट्रैक करें।',
    interactionWarning: 'इंटरेक्शन चेतावनी', activeMedications: 'सक्रिय दवा',
    addMedicine: 'दवा जोड़ें', newMedication: 'नई दवा', medicineName: 'दवा का नाम',
    dosage: 'खुराक', frequency: 'आवृत्ति', reminderTime: 'रिमाइंडर समय',
    startDate: 'शुरुआत की तारीख', duration: 'अवधि (दिन)', saveMedicine: 'दवा सहेजें',
    noMedicinesYet: 'अभी कोई दवा नहीं जोड़ी। ऊपर से अपनी पहली दवा जोड़ें।',
    markTaken: 'ली हुई बताएं', takenToday: 'आज ली गई', completed: 'पूरी हुई',
    // BMI Calculator
    bmiCalculatorTitle: 'BMI कैलकुलेटर', bmiDesc: 'विज़ुअल गेज के साथ बॉडी मास इंडेक्स कैलकुलेट करें।',
    metric: 'मेट्रिक', imperial: 'इम्पीरियल', heightCm: 'ऊंचाई (cm)', weightKg: 'वजन (kg)',
    feet: 'फुट', inches: 'इंच', weightLbs: 'वजन (lbs)', age: 'उम्र (वैकल्पिक)',
    gender: 'लिंग (वैकल्पिक)', calculateBMI: 'BMI कैलकुलेट करें', bmiReference: 'BMI संदर्भ',
    underweight: 'कम वजन', normalWeight: 'सामान्य वजन', overweight: 'अधिक वजन', obese: 'मोटापा',
    yourBMI: 'आपका BMI', idealWeightRange: 'आदर्श वजन सीमा', healthInsight: 'स्वास्थ्य सुझाव',
    // Health Goals
    healthGoalsTitle: 'स्वास्थ्य लक्ष्य', healthGoalsDesc: 'रोज़ के स्वास्थ्य लक्ष्य तय करें और प्रगति ट्रैक करें।',
    doneToday: 'आज पूरे', completion: 'पूर्णता', activeGoals: 'सक्रिय लक्ष्य',
    quickAdd: 'जल्दी जोड़ें', custom: 'कस्टम', goalName: 'लक्ष्य का नाम...', target: 'लक्ष्य',
    addCustomGoal: 'कस्टम लक्ष्य जोड़ें', noGoalsYet: 'अभी कोई लक्ष्य नहीं। ऊपर से जोड़ें!',
    markAsDone: 'आज पूरा किया', tracking: 'ट्रैकिंग',
    // Vaccination
    vaccinationRecords: 'टीकाकरण रिकॉर्ड', vaccinationDesc: 'टीकाकरण इतिहास और रिमाइंडर ट्रैक करें।',
    standardSchedule: 'मानक अनुसूची', myRecords: 'मेरे रिकॉर्ड', logVaccination: 'टीका लॉग करें',
    dateReceived: 'तारीख', doseNumber: 'खुराक #', nextDue: 'अगली तारीख (वैकल्पिक)',
    provider: 'अस्पताल / क्लिनिक', noRecordsYet: 'अभी कोई रिकॉर्ड नहीं।',
    saveRecord: 'रिकॉर्ड सहेजें',
    // Streak Tracker
    streakTrackerTitle: 'स्ट्रीक ट्रैकर', streakTrackerDesc: 'रोज़ की स्ट्रीक और बैज से स्वस्थ आदतें बनाएं।',
    bestStreak: 'सबसे लंबी स्ट्रीक', habitsTracked: 'ट्रैक की गई आदतें', addCustomHabit: 'कस्टम आदत जोड़ें',
    habitName: 'आदत का नाम...', dayStreak: 'दिन की स्ट्रीक', doneToday2: 'आज हो गया! ✓',
    // Calorie Tracker
    calorieTrackerTitle: 'कैलोरी और पानी ट्रैकर', calorieTrackerDesc: 'खाना और पानी लॉग करें। रोज़ रीसेट होता है।',
    calories: 'कैलोरी', protein: 'प्रोटीन', carbs: 'कार्ब्स', fat: 'वसा', water: 'पानी',
    dailyCalorieGoal: 'रोज़ का कैलोरी लक्ष्य', overGoalBy: 'लक्ष्य से अधिक', logFood: 'खाना लॉग करें',
    searchFoods: 'खाना खोजें...', customFood: 'कस्टम खाना', foodName: 'खाने का नाम',
    addCustom: 'कस्टम जोड़ें', todaysLog: 'आज का लॉग', noFoodLogged: 'आज कोई खाना लॉग नहीं हुआ।',
    glassOfWater: '+ गिलास', reset: 'रीसेट', waterIntake: 'पानी का सेवन',
    // Mental Health
    mentalHealthTitle: 'मानसिक स्वास्थ्य साथी', moodTracker: 'रोज़ का मूड ट्रैकर',
    howAreYouFeeling: 'आज आप कैसा महसूस कर रहे हैं?', logMood: 'मूड लॉग करें', moodHistory: 'मूड इतिहास',
    noMoodLogged: 'अभी कोई मूड लॉग नहीं हुआ।', breathingExercise: 'साँस व्यायाम',
    aiSupport: 'AI सपोर्ट चैट',
    // Meditation
    guidedMeditation: 'निर्देशित ध्यान', meditationDesc: 'एक सत्र चुनें। शांत जगह बैठें।',
    duration: 'अवधि', sessionComplete: 'सत्र पूरा हुआ!', repeat: 'दोबारा', tryAnother: 'दूसरा आज़माएं',
    begin: 'शुरू करें', pause: 'रोकें', resume: 'जारी रखें', backToSessions: '← वापस सत्रों पर',
    // Journal
    dailyJournal: 'दैनिक डायरी', journalDesc: 'स्वतंत्र रूप से लिखें — AI भावना का विश्लेषण करता है।',
    todaysEntry: 'आज की प्रविष्टि', entryTitle: 'शीर्षक (वैकल्पिक)...', howAreYou: 'आज आप कैसा महसूस कर रहे हैं?...',
    saveAndAnalyze: 'सहेजें और विश्लेषण करें', analyzing: 'विश्लेषण हो रहा है...', pastEntries: 'पिछली प्रविष्टियाँ',
    noEntriesYet: 'अभी कोई प्रविष्टि नहीं। पहली डायरी लिखें!', aiInsight: 'AI सुझाव',
    // Stress Test
    stressLevelTest: 'तनाव स्तर परीक्षण', stressTestDesc: 'PSS-10 पर आधारित — एक मान्यता प्राप्त मनोवैज्ञानिक परीक्षण।',
    questionOf: 'प्रश्न', of: 'में से', answered: 'उत्तर दिए', seeResults: 'परिणाम देखें',
    retakeTest: 'दोबारा परीक्षण दें', outOf: 'में से', personalizedTips: 'व्यक्तिगत सुझाव',
    lowStress: 'कम तनाव', moderateStress: 'मध्यम तनाव', highStress: 'अधिक तनाव',
    never: 'कभी नहीं', almostNever: 'लगभग कभी नहीं', sometimes: 'कभी-कभी', fairlyOften: 'अक्सर', veryOften: 'बहुत अक्सर',
    inTheLastMonth: 'पिछले महीने में,',
    // Hospital Finder
    hospitalFinder: 'अस्पताल खोजें', hospitalFinderDesc: 'नज़दीकी अस्पताल और क्लीनिक खोजें।',
    findNearbyHospitals: 'नज़दीकी अस्पताल खोजें', detectLocation: 'मेरी लोकेशन पता करें',
    detecting: 'पता कर रहे हैं...', openNow: 'अभी खुला', closed: 'बंद', getDirections: 'रास्ता देखें',
    // Appointment
    bookAppointment: 'अपॉइंटमेंट बुक करें', bookAppointmentDesc: 'डॉक्टर खोजें, स्लॉट चुनें, अपॉइंटमेंट लें।',
    chooseSpecialty: 'विशेषता चुनें', chooseDoctor: 'डॉक्टर चुनें', scheduleDateAndTime: 'तारीख और समय चुनें',
    patientDetails: 'मरीज़ की जानकारी', fullName: 'पूरा नाम', phone: 'फोन',
    reasonForVisit: 'मिलने का कारण', bookingSummary: 'बुकिंग सारांश', confirmAppointment: 'अपॉइंटमेंट कन्फर्म करें',
    appointmentConfirmed: 'अपॉइंटमेंट कन्फर्म हो गई!', bookAnother: 'और बुक करें', yourAppointments: 'आपकी अपॉइंटमेंट',
    // Ambulance
    emergencyAmbulance: 'आपातकाल और एम्बुलेंस', emergencyDesc: 'आपातकालीन नंबर और प्राथमिक चिकित्सा।',
    medicalEmergency: 'मेडिकल इमरजेंसी?', callAmbulance: '📞 108 कॉल करें', emergencyNumbers: 'आपातकालीन नंबर',
    nearestHospitals: 'नज़दीकी अस्पताल', getLocation: 'लोकेशन पाएं', located: 'मिल गई ✓',
    quickFirstAid: 'प्राथमिक चिकित्सा गाइड', tapToSeeSteps: 'टैप करें', bedsFree: 'बेड खाली', full: 'भरा',
    // Health Report
    healthReportTitle: 'स्वास्थ्य रिपोर्ट', healthReportDesc: 'डॉक्टर के लिए पूरी स्वास्थ्य रिपोर्ट बनाएं।',
    reportContents: 'रिपोर्ट में शामिल', downloadReport: 'HTML रिपोर्ट डाउनलोड करें', print: 'प्रिंट करें',
    generating: 'बन रहा है...',
    // Common
    save: 'सहेजें', cancel: 'रद्द करें', add: 'जोड़ें', back: '← वापस', loading: 'लोड हो रहा है...',
    noData: 'अभी कोई डेटा नहीं', analyze2: 'विश्लेषण करें', submit: 'जमा करें', optional: 'वैकल्पिक',
    today: 'आज', yesterday: 'कल', priority: 'प्राथमिकता', directions: 'रास्ता →',
    inLastMonth: 'पिछले महीने में,',
  }
};

export function t(key, lang = 'en') {
  return T[lang]?.[key] || T['en'][key] || key;
}
