import React, { createContext, useContext, useState, useEffect } from 'react';
import { hashPassword, verifyPassword } from '../utils/crypto';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('mc_user');
    if (stored) setUser(JSON.parse(stored));
    setLoading(false);
  }, []);

  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validatePassword = (password) => password.length >= 8;
  const validateName = (name) => name.trim().length >= 2;

  const login = async (email, password) => {
    if (!validateEmail(email)) return { error: 'Please enter a valid email address' };
    if (!password) return { error: 'Password is required' };
    const users = JSON.parse(localStorage.getItem('mc_users') || '[]');
    const found = users.find(u => u.email === email);
    if (!found) return { error: 'No account found with this email' };
    const match = await verifyPassword(password, found.passwordHash);
    if (!match) return { error: 'Incorrect password' };
    const userData = { ...found };
    delete userData.passwordHash;
    setUser(userData);
    localStorage.setItem('mc_user', JSON.stringify(userData));
    return { success: true };
  };

  const signup = async (name, email, password) => {
    if (!validateName(name)) return { error: 'Name must be at least 2 characters' };
    if (!validateEmail(email)) return { error: 'Please enter a valid email address' };
    if (!validatePassword(password)) return { error: 'Password must be at least 8 characters' };
    const users = JSON.parse(localStorage.getItem('mc_users') || '[]');
    if (users.find(u => u.email === email)) return { error: 'An account with this email already exists' };
    const passwordHash = await hashPassword(password);
    const newUser = {
      id: Date.now(),
      name: name.trim(),
      email,
      passwordHash,
      healthScore: 0,
      mentalScore: 0,
      consultations: 0,
      checkupDays: 0,
      joinDate: new Date().toISOString(),
      moodHistory: [],
      symptoms: [],
      healthLogs: [],
    };
    users.push(newUser);
    localStorage.setItem('mc_users', JSON.stringify(users));
    const userData = { ...newUser };
    delete userData.passwordHash;
    setUser(userData);
    localStorage.setItem('mc_user', JSON.stringify(userData));
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('mc_user');
  };

  const updateUser = (updates) => {
    const updated = { ...user, ...updates };
    setUser(updated);
    localStorage.setItem('mc_user', JSON.stringify(updated));
    const users = JSON.parse(localStorage.getItem('mc_users') || '[]');
    const idx = users.findIndex(u => u.id === updated.id);
    if (idx !== -1) {
      users[idx] = { ...users[idx], ...updates };
      localStorage.setItem('mc_users', JSON.stringify(users));
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
