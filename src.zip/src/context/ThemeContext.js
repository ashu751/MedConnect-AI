import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => localStorage.getItem('mc_theme') || 'dark');
  const [lang, setLang] = useState(() => localStorage.getItem('mc_lang') || 'en');

  useEffect(() => {
    localStorage.setItem('mc_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('mc_lang', lang);
  }, [lang]);

  const toggleTheme = () => setTheme(t => t === 'dark' ? 'light' : 'dark');
  const toggleLang = () => setLang(l => l === 'en' ? 'hi' : 'en');

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, lang, setLang, toggleLang }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
