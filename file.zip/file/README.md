# MedConnect — Intelligent Health Platform

A fully functional, production-ready React health app with AI features powered by Google Gemini.

---

## 🚀 Quick Start

### 1. Install & Run
```bash
cd medconnect
npm install --legacy-peer-deps
npm start
```
Opens at **http://localhost:3000**

### 2. Add API Keys (for full functionality)
```bash
cp .env.example .env
# Edit .env with your keys
```

---

## 🔑 API Keys Setup

### Gemini AI (FREE) — Powers AI Doctor & Mental Health Chat
1. Go to https://aistudio.google.com/app/apikey
2. Click "Create API Key" → Free, no credit card needed
3. Add to `.env`: `REACT_APP_GEMINI_API_KEY=your_key_here`
4. Restart dev server: `npm start`

### Google Maps (for Hospital Finder real data)
1. Go to https://console.cloud.google.com
2. Create project → Enable **Maps JavaScript API** + **Places API**
3. Create credentials → API Key
4. Add to `.env`: `REACT_APP_GOOGLE_MAPS_API_KEY=your_key_here`

> **Without API keys:** The app runs in demo mode — all features work with realistic sample data.

---

## ✅ Features

### 🩺 AI Medical Assistant
- Real-time symptom analysis via Gemini 1.5 Flash
- Evidence-based health insights
- Smart follow-up questions
- Quick prompt suggestions
- Demo mode with realistic AI responses

### 🧠 Mental Health Companion
- Daily mood tracker with emoji scale + notes
- Persistent mood history (last 30 days)
- AI-powered emotional support chat (Gemini)
- 4-7-8 Breathing exercise with animated visual
- Mood history log

### 🏥 Hospital Finder
- GPS-based location detection
- Real nearby hospitals via Google Places API
- Distance sorting + open/closed status
- One-click Google Maps directions
- Dark-themed map with custom markers
- Demo mode with 6 realistic nearby hospitals

### 📊 Health Analytics
- Weekly health score trend (Area chart)
- Sleep tracking (Bar chart)
- 30-day health trend (Line chart)
- Wellness radar chart (6 dimensions)
- Manual health data logging (weight, BP, heart rate)
- Persistent log history

---

## 🏗️ Project Structure
```
medconnect/
├── public/index.html         # Google Fonts (Syne + DM Sans + DM Mono)
├── src/
│   ├── context/
│   │   └── AuthContext.js    # Auth state + localStorage users
│   ├── components/
│   │   └── Layout.js         # Sidebar + mobile nav
│   ├── pages/
│   │   ├── LandingPage.js    # Hero + features + CTA
│   │   ├── AuthPage.js       # Login / Signup
│   │   ├── Dashboard.js      # Overview + quick access
│   │   ├── MedicalAI.js      # Gemini AI chat
│   │   ├── MentalHealth.js   # Mood + chat + breathing
│   │   ├── HospitalFinder.js # Maps + nearby hospitals
│   │   └── HealthAnalytics.js# Charts + health logging
│   ├── index.css             # Dark theme design system
│   ├── index.js
│   └── App.js                # Routing
├── .env.example
└── package.json
```

---

## 🌐 Deployment

### Netlify (Recommended — Free)
1. Build: `npm run build`
2. Go to https://netlify.com → "Add new site" → "Deploy manually"
3. Drag the `build/` folder into Netlify
4. Add environment variables in Netlify: Site settings → Environment variables
5. Redeploy

### Vercel (Also Free)
```bash
npm install -g vercel
vercel
```
Add env vars in Vercel dashboard after deploying.

### GitHub Pages
```bash
# Add to package.json: "homepage": "https://yourusername.github.io/medconnect"
npm install gh-pages --save-dev
# Add to scripts: "predeploy": "npm run build", "deploy": "gh-pages -d build"
npm run deploy
```

---

## 🎨 Design System

- **Fonts:** Syne (display/headings) + DM Sans (body) + DM Mono (code/labels)
- **Theme:** Deep dark (`#080812`) with purple/teal/pink accents
- **Colors:**
  - Accent Purple: `#7c6af7`
  - Teal: `#5bd3c7`
  - Pink: `#f0628a`
  - Amber: `#f5a623`
- **Border radius:** 16px cards, 8px inputs, 100px pills

---

## ⚠️ Disclaimer
This app is for informational and demonstration purposes only. AI responses do not constitute medical advice. Always consult a qualified healthcare professional.
